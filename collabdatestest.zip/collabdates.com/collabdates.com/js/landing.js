// Nav and menus

var topPosition = 0;

window.addEventListener("DOMContentLoaded", function() {
    topPosition = $(window).scrollTop();
    showNavbarShade(topPosition);
});

$(window).on('scroll', function() {
    var newPostion = $(this).scrollTop();
    if ((topPosition == 0 && newPostion != 0) || (topPosition != 0 && newPostion == 0)) showNavbarShade(newPostion);
    topPosition = newPostion;
});

function openSideMenu() {
    $('body').toggleClass('noscroll');
    $('#side_nav').css('right', '0');
    $('#side_menu_blur').fadeIn(500);
}

function closeSideMenu() {
    $('#side_nav').css('right', '-300px');
    $('#side_menu_blur').fadeOut(500);
    $('body').toggleClass('noscroll');
}

function showAnnouncement(content) {
    $('#announcement-content').html(content);
    $('#announcement').css('display', 'block');
    $('#announcement').css('height', '30px');
    $('#top_nav').css('top', '30px');
    $('.margin-nav').css('margin-top', '80px');
    $('.padding-nav').css('padding-top', '80px');
}

function hideAnnouncement() {
    $('#announcement').css('height', '0');
    $('#top_nav').css('top', '0');
    $('.margin-nav').css('margin-top', '50px');
    $('.padding-nav').css('padding-top', '50px');
    setTimeout(() => $('#announcement').css('display', 'none'), 250);
}

function showNavbarShade(scrollPosition) {
    if (scrollPosition == 0) {
        $('#top_nav').removeClass('top-nav-shadow');
        if (TransparentNav) $('#top_nav').addClass('transparent');
    } else {
        $('#top_nav').addClass('top-nav-shadow');
        if (TransparentNav) $('#top_nav').removeClass('transparent');
    }
}

function toggleTheme() {
    $('body').toggleClass('light-theme');
    $('body').toggleClass('dark-theme');
    var theme = $('body').hasClass('light-theme') ? 'light' : 'dark';
    setCookie('theme', theme);
    return false;
}

(function() {
    'use strict'

    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    var forms = document.querySelectorAll('.needs-validation')

    // Loop over them and prevent submission
    Array.prototype.slice.call(forms)
        .forEach(function(form) {
            form.addEventListener('submit', function(event) {
                if (!form.checkValidity()) {
                    event.preventDefault()
                    event.stopPropagation()
                }

                form.classList.add('was-validated')
            }, false)
        })
})()