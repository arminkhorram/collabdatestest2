$(window).on('load', function() {
    $('button').addClass('transition');
    $('.button').addClass('transition');
});

var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl, {
        trigger: 'hover'
    });
});

function copyToClipboard(element, value) {
    navigator.clipboard.writeText(value);

    element.setAttribute('data-bs-original-title', 'Copied!');
    const tooltip = bootstrap.Tooltip.getInstance(element);
    tooltip.show();

    setTimeout(() => {
        element.setAttribute('data-bs-original-title', 'Copy');
        tooltip.hide();
    }, 1000);

    return false;
}

// Cookies

window.addEventListener("DOMContentLoaded", function() {
    var visit = getCookie('visit');
    $.post('/data/PageView', {
        url: window.location.href,
        visitId: visit
    }, function(newVisit, status) {
        if (status != 'success') return;
        if (newVisit != null && visit != newVisit) setCookie('visit', newVisit, 365 * 10);
    });
});

function setCookie(name, value, days) {
    var expires = '';
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        expires = '; expires=' + date.toUTCString();
    }
    document.cookie = name + '=' + (value || '') + expires + '; path=/';
}

function getCookie(name) {
    const nameEq = name + '=';
    const ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        const c = ca[i];
        const j = c.indexOf(nameEq);
        if (j !== -1) return c.substring(j + nameEq.length, c.length);
    }
    return null;
}

function eraseCookie(name) {
    document.cookie = name + '=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
}

// Animations

function isScrolledIntoView(elem, full = true) {
    var is_visible;

    var docViewTop = $(window).scrollTop();
    var docViewBottom = docViewTop + $(window).height();

    var elemTop = $(elem).offset().top;
    var elemBottom = elemTop + $(elem).height();

    if (full) is_visible = elemTop >= docViewTop && elemBottom <= docViewBottom;
    else is_visible = (elemTop <= docViewTop && elemBottom >= docViewTop) || (elemTop <= docViewBottom && elemBottom >= docViewBottom);

    return is_visible;
}

function numberWithCommas(x) {
    return Math.round(x).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}