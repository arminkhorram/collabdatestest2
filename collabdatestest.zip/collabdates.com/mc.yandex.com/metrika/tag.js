(function() {
    var n;

    function aa(a) {
        var b = 0;
        return function() {
            return b < a.length ? {
                done: !1,
                value: a[b++]
            } : {
                done: !0
            }
        }
    }

    function q(a) {
        var b = "undefined" != typeof Symbol && Symbol.iterator && a[Symbol.iterator];
        if (b) return b.call(a);
        if ("number" == typeof a.length) return {
            next: aa(a)
        };
        throw Error(String(a) + " is not an iterable or ArrayLike");
    }

    function ba(a) {
        for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
        return c
    }

    function ca(a) {
        return a instanceof Array ? a : ba(q(a))
    }
    var da = "function" == typeof Object.create ? Object.create : function(a) {
            function b() {}
            b.prototype = a;
            return new b
        },
        ea;
    if ("function" == typeof Object.setPrototypeOf) ea = Object.setPrototypeOf;
    else {
        var fa;
        a: {
            var ha = {
                    a: !0
                },
                ia = {};
            try {
                ia.__proto__ = ha;
                fa = ia.a;
                break a
            } catch (a) {}
            fa = !1
        }
        ea = fa ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    var ja = ea;

    function ka(a, b) {
        a.prototype = da(b.prototype);
        a.prototype.constructor = a;
        if (ja) ja(a, b);
        else
            for (var c in b)
                if ("prototype" != c)
                    if (Object.defineProperties) {
                        var d = Object.getOwnPropertyDescriptor(b, c);
                        d && Object.defineProperty(a, c, d)
                    } else a[c] = b[c];
        a.Li = b.prototype
    }

    function la() {
        for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
        return b
    }
    var na = {
        construct: "Metrika2",
        callbackPostfix: "2",
        version: "14pwap7gbnl70a58u0m6s2b47zyz",
        host: "mc.yandex.com"
    };

    function oa(a, b) {
        return b(a)
    }

    function pa(a) {
        return function(b) {
            return function(c) {
                return a(b, c)
            }
        }
    }

    function qa(a) {
        return function(b) {
            return function(c) {
                return a(c, b)
            }
        }
    }
    var ra = pa(function(a, b) {
            return a === b
        }),
        sa = pa(function(a, b) {
            a(b);
            return b
        }),
        ta = pa(oa);

    function u() {}
    var ua = [];

    function va(a, b) {
        if (!b || "function" !== typeof b) return !1;
        try {
            var c = "" + b
        } catch (h) {
            return !1
        }
        var d = c.length;
        if (d > 35 + a.length) return !1;
        for (var e = d - 13, f = 0, g = 8; g < d; g += 1) {
            f = "[native code]" [f] === c[g] || 7 === f && "-" === c[g] ? f + 1 : 0;
            if (12 === f) return !0;
            if (!f && g > e) break
        }
        return !1
    }

    function wa(a, b) {
        var c = va(a, b);
        b && !c && ua.push([a, b]);
        return c
    }

    function xa(a, b) {
        return wa(b, a) && a
    }

    function ya(a, b) {
        for (var c = 0; c < b.length; c += 1)
            if (b[c] === a) return c;
        return -1
    }
    var za;

    function Aa(a) {
        if (za) return za;
        var b = !1;
        try {
            b = [].indexOf && 0 === [void 0].indexOf(void 0)
        } catch (d) {}
        var c = a.Array && a.Array.prototype && xa(a.Array.prototype.indexOf, "indexOf");
        return za = a = b && c ? function(d, e) {
            return c.call(e, d)
        } : ya
    }
    var Ba = Aa(window),
        Ca = qa(Ba);

    function v(a) {
        return a
    }

    function Da(a, b) {
        return b
    }

    function Ea(a) {
        return !a
    }
    var Fa = xa(Array.from, "from");

    function Ga(a) {
        for (var b = a.length, c = [], d = 0; d < b; d += 1) c.push(a[d]);
        return c
    }

    function Ha(a) {
        if (Fa) try {
            return Fa(a)
        } catch (b) {}
        return Ga(a)
    }

    function x(a, b) {
        var c = [],
            d = [];
        var e = b ? b : v;
        return function() {
            var f = Ha(arguments),
                g = e.apply(null, ca(f)),
                h = Ba(g, d);
            if (-1 !== h) return c[h];
            f = a.apply(null, ca(f));
            c.push(f);
            d.push(g);
            return f
        }
    }
    var Ia = /\./g;

    function y(a) {
        return "string" === typeof a
    }
    var Ja = xa(String.prototype.indexOf, "indexOf");

    function Ka(a, b) {
        for (var c = 0, d = a.length - b.length, e = 0; e < a.length; e += 1) {
            c = a[e] === b[c] ? c + 1 : 0;
            if (c === b.length) return e - b.length + 1;
            if (!c && e > d) break
        }
        return -1
    }
    var La = Ja ? function(a, b) {
        return Ja.call(a, b)
    } : Ka;

    function Ma(a, b) {
        return La(a, b)
    }

    function Na(a, b) {
        return !(!a || -1 === La(a, b))
    }

    function Oa(a) {
        return "" + a
    }

    function Pa(a) {
        return a.replace(/\^/g, "\\^").replace(/\$/g, "\\$").replace(Ia, "\\.").replace(/\[/g, "\\[").replace(/\]/g, "\\]").replace(/\|/g, "\\|").replace(/\(/g, "\\(").replace(/\)/g, "\\)").replace(/\?/g, "\\?").replace(/\*/g, "\\*").replace(/\+/g, "\\+").replace(/\{/g, "\\{").replace(/\}/g, "\\}")
    }
    var Qa = ra(null);

    function A(a) {
        return "function" === typeof a
    }
    var B = ra(void 0);

    function Ra(a) {
        return B(a) || Qa(a)
    }

    function Sa(a) {
        return !Qa(a) && !B(a) && "[object Object]" === Object.prototype.toString.call(a)
    }

    function Ta(a, b, c) {
        b = void 0 === b ? [] : b;
        c = c || {};
        var d = b.length,
            e = a;
        A(e) && (e = "d", c[e] = a);
        var f;
        d ? 1 === d ? f = c[e](b[0]) : 2 === d ? f = c[e](b[0], b[1]) : 3 === d ? f = c[e](b[0], b[1], b[2]) : 4 === d && (f = c[e](b[0], b[1], b[2], b[3])) : f = c[e]();
        return f
    }
    var Ua = xa(Function.prototype.bind, "bind");

    function Va() {
        var a = Ha(arguments);
        a = q(a);
        var b = a.next().value,
            c = a.next().value,
            d = ba(a);
        return function() {
            var e = [].concat(ca(d), ca(Ha(arguments)));
            if (Function.prototype.call) return Function.prototype.call.apply(b, [c].concat(ca(e)));
            if (c) {
                for (var f = "_b"; c[f];) f += "_" + f.length;
                c[f] = b;
                e = c[f] && Ta(f, e, c);
                delete c[f];
                return e
            }
            return Ta(b, e)
        }
    }
    var C = Ua ? function() {
        var a = Ha(arguments),
            b = q(a);
        a = b.next().value;
        var c = b.next().value;
        b = ba(b);
        return Ua.apply(a, [c].concat(b))
    } : Va;

    function D(a, b) {
        return C.apply(null, [b, null].concat(ca(a)))
    }

    function E(a, b) {
        return C(b, null, a)
    }

    function Wa(a, b) {
        return C(b[a], b)
    }

    function Xa(a) {
        return Wa("test", a)
    }
    var Ya = xa(Array.prototype.reduce, "reduce");

    function Za(a, b, c) {
        for (var d = 0, e = c.length; d < e;) b = a(b, c[d], d), d += 1;
        return b
    }
    var F = Ya ? function(a, b, c) {
        return Ya.call(c, a, b)
    } : Za;

    function $a(a, b) {
        return D([a, b], F)
    }

    function G() {
        var a = Ha(arguments),
            b = a.shift();
        return function() {
            var c = b.apply(null, arguments);
            return F(oa, c, a)
        }
    }
    var ab = pa(D),
        bb = pa(Wa),
        cb = Object.prototype.hasOwnProperty;

    function H(a, b) {
        return Ra(a) ? !1 : cb.call(a, b)
    }

    function I(a, b) {
        return a ? F(function(c, d) {
            if (Ra(c)) return c;
            try {
                return c[d]
            } catch (e) {}
            return null
        }, a, b.split(".")) : null
    }
    var db = qa(I),
        eb = db("length");

    function fb(a) {
        var b = void 0 === b ? {} : b;
        if (!a || 1 > a.length) return b;
        F(function(c, d, e) {
            if (e === a.length - 1) return c;
            e === a.length - 2 ? c[d] = a[e + 1] : H(c, d) || (c[d] = {});
            return c[d]
        }, b, a);
        return b
    }

    function gb(a, b) {
        var c = I(b, a),
            d = I(b, "constructor.prototype." + a) || c;
        try {
            if (d && d.apply) return function() {
                return d.apply(b, arguments)
            }
        } catch (e) {
            return c
        }
        return d
    }

    function hb(a, b, c) {
        return c ? a : b
    }
    var ib = D([1, null], hb),
        jb = D([1, 0], hb),
        kb = Boolean,
        lb = xa(Array.prototype.filter, "filter");

    function mb(a, b) {
        return Za(function(c, d, e) {
            a(d, e) && c.push(d);
            return c
        }, [], b)
    }
    var nb = lb ? function(a, b) {
            return lb.call(b, a)
        } : mb,
        ob = E(kb, nb),
        pb = pa(nb),
        qb = xa(Array.prototype.includes, "includes");

    function rb(a, b) {
        return 1 <= mb(ra(a), b).length
    }
    var J = qb ? function(a, b, c) {
            return qb.call(b, a, c)
        } : rb,
        sb = qa(J);

    function tb(a) {
        return "[object Array]" === Object.prototype.toString.call(a)
    }
    var ub = xa(Array.isArray, "isArray"),
        K = ub ? function(a) {
            return ub(a)
        } : tb;

    function vb(a) {
        return a ? K(a) ? a : Fa ? Fa(a) : "number" === typeof a.length && 0 <= a.length ? Ga(a) : [] : []
    }
    var wb = x(Aa),
        xb = db("0");

    function yb(a) {
        return a.splice(0, a.length)
    }
    var zb = x(function(a) {
        var b = I(a, "navigator") || {};
        a = I(b, "userAgent") || "";
        b = I(b, "vendor") || "";
        return {
            ef: -1 < La(b, "Apple"),
            Xf: a
        }
    });

    function Ab(a, b) {
        return -1 !== (I(b, "navigator.userAgent") || "").toLowerCase().search(a)
    }
    var Bb = x(db("navigator.userAgent")),
        Cb = /Firefox\/([0-9]+)/i,
        Db = x(function(a) {
            var b = I(a, "document.documentElement.style"),
                c = I(a, "InstallTrigger");
            a = Ab(Cb, a);
            Cb.lastIndex = 0;
            return !(!(b && "MozAppearance" in b) || Ra(c)) || a
        });

    function Eb() {
        var a = Array.prototype.map;
        if (!Db(window)) return !0;
        try {
            a.call({
                0: !0,
                length: -Math.pow(2, 32) + 1
            }, function() {
                throw 1;
            })
        } catch (b) {
            return !1
        }
        return !0
    }
    var Fb = xa(Array.prototype.map, "map");

    function Gb(a, b) {
        return F(function(c, d, e) {
            c.push(a(d, e));
            return c
        }, [], b)
    }
    var L = Fb && Eb() ? function(a, b) {
            return b && 0 < b.length ? Fb.call(b, a) : []
        } : Gb,
        Hb = xa(Array.prototype.flatMap, "flatMap");

    function Ib(a, b) {
        return F(function(c, d, e) {
            d = a(d, e);
            return c.concat(K(d) ? d : [d])
        }, [], b)
    }
    var Jb = Hb ? function(a, b) {
            return Hb.call(b, a)
        } : Ib,
        Kb = pa(L),
        Lb = qa(L),
        Mb = xa(Array.prototype.some, "some");

    function Nb(a, b) {
        for (var c = 0; c < b.length; c += 1)
            if (c in b && a.call(b, b[c], c)) return !0;
        return !1
    }
    var Ob = Mb ? function(a, b) {
            return Mb.call(b, a)
        } : Nb,
        Pb = xa(Array.prototype.every, "every");

    function Qb(a, b) {
        return F(function(c, d, e) {
            return c ? !!a(d, e) : !1
        }, !0, b)
    }
    var Rb = Pb ? function(a, b) {
        return Pb.call(b, a)
    } : Qb;

    function Sb(a, b) {
        return a.isFinite(b) && !a.isNaN(b) && "[object Number]" === Object.prototype.toString.call(b)
    }

    function Tb(a) {
        try {
            return parseInt(a, 10)
        } catch (b) {
            return null
        }
    }
    var Ub = qa(parseInt),
        Vb = Ub(10),
        Wb = Ub(2);

    function Xb(a, b) {
        return Qa(b) || B(b) || Sb(a, b) || y(b) || !!b === b
    }
    var Yb = xa(Object.keys, "keys");

    function Zb(a) {
        var b = [],
            c;
        for (c in a) H(a, c) && b.push(c);
        return b
    }
    var $b = xa(Object.entries, "entries");

    function ac(a) {
        return B(a) ? [] : Za(function(b, c) {
            b.push([c, a[c]]);
            return b
        }, [], Zb(a))
    }
    var bc = $b ? function(a) {
            return a ? $b(a) : []
        } : ac,
        cc = Yb ? function(a) {
            return Yb(a)
        } : Zb,
        dc = xa(Object.values, "values"),
        ec = G(ac, E(db("1"), Gb)),
        fc = dc ? function(a) {
            return dc(a)
        } : ec;

    function gc() {
        var a = Ha(arguments),
            b = q(a);
        a = b.next().value;
        for (b = ba(b); b.length;) {
            var c = b.shift(),
                d;
            for (d in c) H(c, d) && (a[d] = c[d]);
            H(c, "toString") && (a.toString = c.toString)
        }
        return a
    }
    var M = Object.assign || gc,
        hc = pa(function(a, b) {
            return M({}, a, b)
        }),
        ic = x(G(db("String.fromCharCode"), E("fromCharCode", wa), Ea)),
        jc = x(G(Bb, Xa(/ipad|iphone|ipod/i))),
        kc = x(function(a) {
            return I(a, "navigator.platform") || ""
        }),
        lc = x(function(a) {
            a = zb(a);
            var b = a.Xf;
            return a.ef && !b.match("CriOS")
        }),
        mc = Xa(/Android.*Version\/[0-9][0-9.]*\sChrome\/[0-9][0-9.]|Android.*Version\/[0-9][0-9.]*\s(?:Mobile\s)?Safari\/[0-9][0-9.]*\sChrome\/[0-9][0-9.]*|; wv\).*Chrome\/[0-9][0-9.]*\sMobile/),
        nc = Xa(/; wv\)/),
        oc = x(function(a) {
            a =
                Bb(a);
            return nc(a) || mc(a)
        }),
        pc = /Chrome\/(\d+)\./,
        qc = x(function(a) {
            return (a = (I(a, "navigator.userAgent") || "").match(pc)) && a.length ? 76 <= Vb(a[1]) : !1
        }),
        rc = x(function(a) {
            a = (Bb(a) || "").toLowerCase();
            return Na(a, "android") && Na(a, "mobile")
        }),
        sc = "other none unknown wifi ethernet bluetooth cellular wimax mixed".split(" "),
        tc = x(function(a) {
            var b = I(a, "navigator.connection.type");
            if (B(b)) return null;
            a = wb(a)(b, sc);
            return -1 === a ? b : "" + a
        }),
        uc = x(G(db("document.addEventListener"), Ea)),
        vc = x(function(a) {
            var b = I(a, "navigator") || {};
            return F(function(c, d) {
                return c || I(b, d)
            }, "", ["language", "userLanguage", "browserLanguage", "systemLanguage"])
        }),
        wc = x(function(a) {
            var b = I(a, "navigator") || {};
            a = vc(a);
            y(a) || (a = "", b = I(b, "languages.0"), y(b) && (a = b));
            return a.toLowerCase().split("-")[0]
        }),
        xc = x(function(a) {
            return (I(a, "top") || a) !== a
        }),
        yc = x(db("top.contentWindow")),
        zc = x(function(a) {
            var b = !1;
            try {
                b = a.navigator.javaEnabled()
            } catch (c) {}
            return b
        }),
        Ac = x(function(a) {
            var b = "__webdriver_evaluate __selenium_evaluate __webdriver_script_function __webdriver_script_func __webdriver_script_fn __fxdriver_evaluate __driver_unwrapped __webdriver_unwrapped __driver_evaluate __selenium_unwrapped __fxdriver_unwrapped".split(" "),
                c = I(a, "external");
            c = I(c, "toString") ? "" + c.toString() : "";
            c = -1 !== La(c, "Sequentum");
            var d = I(a, "document.documentElement"),
                e = ["selenium", "webdriver", "driver"];
            return !!(Ob(E(a, I), ["_selenium", "callSelenium", "_Selenium_IDE_Recorder"]) || Ob(E(I(a, "document"), I), b) || c || d && Ob(C(d.getAttribute, d), e))
        }),
        Bc = x(function(a) {
            return !!(Ob(E(a, I), ["_phantom", "__nightmare", "callPhantom"]) || /(PhantomJS)|(HeadlessChrome)/.test(Bb(a)) || I(a, "navigator.webdriver") || I(a, "isChrome") && !I(a, "chrome"))
        }),
        Dc = x(function(a) {
            return !(!I(a,
                "ia_document.shareURL") || !I(a, "ia_document.referrer"))
        });

    function Ec(a) {
        return J("prerender", L(E(I(a, "document"), I), ["webkitVisibilityState", "visibilityState"]))
    }
    var Fc = x(function(a) {
            var b = Bb(a) || "",
                c = b.match(/Mac OS X ([0-9]+)_([0-9]+)/);
            c = c ? [+c[1], +c[2]] : [0, 0];
            b = b.match(/iPhone OS ([1-9]+)_([0-9]+)/);
            return 14 <= (b ? +b[1] : 0) ? !0 : (jc(a) || 10 < c[0] || 10 === c[0] && 13 <= c[1]) && lc(a)
        }),
        Gc = /Edg\/(\d+)\./;

    function Hc(a) {
        return (a = Bb(a)) && (a = a.match(Gc)) && 1 < a.length ? 79 <= Vb(a[1]) : !1
    }

    function Ic(a) {
        return Db(a) && (a = Bb(a).match(Cb)) && a.length ? 68 <= +a[1] : !1
    }
    var Jc = x(function(a) {
            return Fc(a) || Ic(a) || Hc(a)
        }),
        Kc = na.construct,
        Lc = na.host,
        Mc = uc(window),
        Nc = {
            fg: 24226447,
            $f: 26302566,
            ig: 51533966,
            ii: 65446441,
            La: "https:",
            eb: "1570",
            fc: Kc,
            eg: Mc ? 512 : 2048,
            cg: Mc ? 512 : 2048,
            dg: Mc ? 100 : 400,
            ji: 100,
            gg: "noindex"
        },
        Oc = ra("1");

    function Pc(a, b, c, d) {
        var e = {};
        return Sa(a) ? a : (e.id = a, e.type = c, e.defer = d, e.params = b, e)
    }

    function Qc(a) {
        return F(function(b, c) {
            var d = q(c),
                e = d.next().value,
                f = d.next().value;
            d = f.Va;
            f = a[f.da];
            b[e] = d ? d(f) : f;
            return b
        }, {}, bc(Rc))
    }
    var N = x(function(a) {
        return a.id + ":" + a.ca
    });

    function Sc(a) {
        a = a.Ya = a.Ya || {};
        var b = a._metrika = a._metrika || {};
        return {
            sa: function(c, d) {
                H(b, c) || (b[c] = d);
                return this
            },
            D: function(c, d) {
                b[c] = d;
                return this
            },
            C: function(c, d) {
                var e = b[c];
                return H(b, c) || B(d) ? e : d
            }
        }
    }
    var O = x(Sc),
        Tc = setTimeout;

    function Uc() {}

    function Vc(a, b) {
        return function() {
            a.apply(b, arguments)
        }
    }

    function Wc(a) {
        if (!(this instanceof Wc)) throw new TypeError("Promises must be constructed via new");
        if ("function" !== typeof a) throw new TypeError("not a function");
        this.Ka = 0;
        this.Fe = !1;
        this.Qa = void 0;
        this.Ab = [];
        Xc(a, this)
    }

    function Yc(a, b) {
        for (; 3 === a.Ka;) a = a.Qa;
        0 === a.Ka ? a.Ab.push(b) : (a.Fe = !0, Wc.Ge(function() {
            var c = 1 === a.Ka ? b.vh : b.Ah;
            if (null === c)(1 === a.Ka ? Zc : $c)(b.promise, a.Qa);
            else {
                try {
                    var d = c(a.Qa)
                } catch (e) {
                    $c(b.promise, e);
                    return
                }
                Zc(b.promise, d)
            }
        }))
    }

    function Zc(a, b) {
        try {
            if (b === a) throw new TypeError("A promise cannot be resolved with itself.");
            if (b && ("object" === typeof b || "function" === typeof b)) {
                var c = b.then;
                if (b instanceof Wc) {
                    a.Ka = 3;
                    a.Qa = b;
                    ad(a);
                    return
                }
                if ("function" === typeof c) {
                    Xc(Vc(c, b), a);
                    return
                }
            }
            a.Ka = 1;
            a.Qa = b;
            ad(a)
        } catch (d) {
            $c(a, d)
        }
    }

    function $c(a, b) {
        a.Ka = 2;
        a.Qa = b;
        ad(a)
    }

    function ad(a) {
        2 === a.Ka && 0 === a.Ab.length && Wc.Ge(function() {
            a.Fe || Wc.jg(a.Qa)
        });
        for (var b = 0, c = a.Ab.length; b < c; b++) Yc(a, a.Ab[b]);
        a.Ab = null
    }

    function bd(a, b, c) {
        this.vh = "function" === typeof a ? a : null;
        this.Ah = "function" === typeof b ? b : null;
        this.promise = c
    }

    function Xc(a, b) {
        var c = !1;
        try {
            a(function(d) {
                c || (c = !0, Zc(b, d))
            }, function(d) {
                c || (c = !0, $c(b, d))
            })
        } catch (d) {
            c || (c = !0, $c(b, d))
        }
    }
    Wc.prototype["catch"] = function(a) {
        return this.then(null, a)
    };
    Wc.prototype.then = function(a, b) {
        var c = new this.constructor(Uc);
        Yc(this, new bd(a, b, c));
        return c
    };
    Wc.prototype["finally"] = function(a) {
        var b = this.constructor;
        return this.then(function(c) {
            return b.resolve(a()).then(function() {
                return c
            })
        }, function(c) {
            return b.resolve(a()).then(function() {
                return b.reject(c)
            })
        })
    };
    Wc.all = function(a) {
        return new Wc(function(b, c) {
            function d(h, k) {
                try {
                    if (k && ("object" === typeof k || "function" === typeof k)) {
                        var l = k.then;
                        if ("function" === typeof l) {
                            l.call(k, function(m) {
                                d(h, m)
                            }, c);
                            return
                        }
                    }
                    e[h] = k;
                    0 === --f && b(e)
                } catch (m) {
                    c(m)
                }
            }
            if (!a || "undefined" === typeof a.length) return c(new TypeError("Promise.all accepts an array"));
            var e = Array.prototype.slice.call(a);
            if (0 === e.length) return b([]);
            for (var f = e.length, g = 0; g < e.length; g++) d(g, e[g])
        })
    };
    Wc.resolve = function(a) {
        return a && "object" === typeof a && a.constructor === Wc ? a : new Wc(function(b) {
            b(a)
        })
    };
    Wc.reject = function(a) {
        return new Wc(function(b, c) {
            c(a)
        })
    };
    Wc.race = function(a) {
        return new Wc(function(b, c) {
            if (!a || "undefined" === typeof a.length) return c(new TypeError("Promise.race accepts an array"));
            for (var d = 0, e = a.length; d < e; d++) Wc.resolve(a[d]).then(b, c)
        })
    };
    Wc.Ge = "function" === typeof setImmediate && function(a) {
        setImmediate(a)
    } || function(a) {
        Tc(a, 0)
    };
    Wc.jg = function(a) {
        "undefined" !== typeof console && console && console.warn("Possible Unhandled Promise Rejection:", a)
    };
    var Q = window.Promise,
        cd = xa(Q, "Promise"),
        dd = xa(I(Q, "resolve"), "resolve"),
        ed = xa(I(Q, "reject"), "reject"),
        fd = xa(I(Q, "all"), "all");
    if (cd && dd && ed && fd) {
        var gd = function(a) {
            return new Promise(a)
        };
        gd.resolve = C(dd, Q);
        gd.reject = C(ed, Q);
        gd.all = C(fd, Q);
        Q = gd
    } else Q = Wc;
    var hd = ["http.0.st..rt.", "network error occurred", "send beacon", "Content Security Policy", "DOM Exception 18"],
        id;

    function jd(a) {
        this.message = a
    }
    var S = function(a) {
        return function(b, c) {
            c = void 0 === c ? !1 : c;
            if (id) var d = new id(b);
            else wa("Error", a.Error) ? (id = a.Error, d = new a.Error(b)) : (id = jd, d = new id(b));
            c && (d.unk = !0);
            return d
        }
    }(window);

    function kd(a) {
        return S("http." + a.status + ".st." + a.statusText + ".rt." + ("" + a.responseText).substring(0, 50))
    }
    var ld = Xa(RegExp("^http."));

    function md(a) {
        throw a;
    }

    function nd(a, b) {
        for (var c = "", d = 0; d < b.length; d += 1) c += "" + (d ? a : "") + b[d];
        return c
    }
    var od = xa(Array.prototype.join, "join"),
        T = od ? function(a, b) {
            return od.call(b, a)
        } : nd,
        pd = pa(T),
        qd = x(function(a) {
            a = !(!a.addEventListener || !a.removeEventListener);
            return {
                Ph: a,
                F: a ? "addEventListener" : "attachEvent",
                ga: a ? "removeEventListener" : "detachEvent"
            }
        });

    function rd(a, b, c, d, e, f) {
        a = qd(a);
        var g = a.F,
            h = a.ga;
        f = f ? h : g;
        if (b[f])
            if (a.Ph)
                if (e) b[f](c, d, e);
                else b[f](c, d);
        else b[f]("on" + c, d)
    }
    var sd = x(function(a) {
            var b = !1;
            if (!a.addEventListener) return b;
            try {
                var c = Object.defineProperty({}, "passive", {
                    get: function() {
                        b = !0;
                        return 1
                    }
                });
                a.addEventListener("test", u, c)
            } catch (d) {}
            return b
        }),
        td = pa(function(a, b) {
            if (null !== b) return a ? M({
                capture: !0,
                passive: !0
            }, b || {}) : !!b
        }),
        ud = x(function(a) {
            var b = sd(a),
                c = td(b),
                d = {};
            return M(d, {
                F: function(e, f, g, h) {
                    L(function(k) {
                        var l = c(h);
                        rd(a, e, k, g, l, !1)
                    }, f);
                    return C(d.Xb, d, e, f, g, h)
                },
                Xb: function(e, f, g, h) {
                    L(function(k) {
                        var l = c(h);
                        rd(a, e, k, g, l, !0)
                    }, f)
                }
            })
        });

    function vd(a) {
        return I(a, "performance") || I(a, "webkitPerformance")
    }

    function wd(a) {
        a = vd(a);
        var b = I(a, "timing.navigationStart"),
            c = I(a, "now");
        c && (c = C(c, a));
        return [b, c]
    }

    function xd(a, b) {
        var c = q(b || wd(a)),
            d = c.next().value;
        c = c.next().value;
        return !isNaN(d) && A(c) ? Math.round(c() + d) : a.Date.now ? a.Date.now() : (new a.Date).getTime()
    }

    function yd(a) {
        return (10 > a ? "0" : "") + a
    }

    function zd(a) {
        var b = ud(a),
            c = wd(a),
            d = {
                l: a,
                ye: 0,
                Hc: c,
                hh: xd(a, c)
            },
            e = q(c);
        c = e.next().value;
        e = e.next().value;
        c && e || b.F(a, ["beforeunload", "unload"], function() {
            0 === d.ye && (d.ye = xd(a, d.Hc))
        });
        return ta(d)
    }

    function Ad(a) {
        var b = a.ye;
        return 0 !== b ? b : xd(a.l, a.Hc)
    }

    function Bd(a) {
        return Math.floor(Ad(a) / 1E3 / 60)
    }

    function Cd(a) {
        return Math.round(Ad(a) / 1E3)
    }

    function Dd(a) {
        var b = q(a.Hc),
            c = b.next().value;
        b = b.next().value;
        a = c && b ? b() : Ad(a) - a.hh;
        return Math.round(a)
    }
    var Ed = x(zd);

    function Fd(a) {
        a = Ed(a);
        return Math.round(a(Dd) / 50)
    }

    function Gd(a) {
        return a.qe || a.Ta.length <= a.za
    }

    function Id(a) {
        a.za = a.Ta.length
    }

    function Jd(a) {
        a.qe = !0
    }

    function Kd(a) {
        a.qe = !1
    }

    function Ld(a) {
        Gd(a) && md(S("i"));
        var b = a.Nd(a.Ta[a.za]);
        a.za += 1;
        return b
    }
    var Md = pa(function(a, b) {
        for (var c = []; !Gd(b);) {
            var d = Ld(b);
            a(d, function(e) {
                return e(b)
            });
            c.push(d)
        }
        return c
    });

    function Nd(a) {
        return function(b) {
            for (var c; b.Ta.length && !Gd(b);) c = b.Ta.pop(), c = b.Nd(c, b.Ta), a(b);
            return c
        }
    }

    function Od(a, b) {
        return function(c) {
            var d = Ed(a),
                e = d(Ad);
            return Nd(function(f) {
                d(Ad) - e >= b && Jd(f)
            })(c)
        }
    }

    function Pd(a, b) {
        return function(c) {
            var d = Ed(a),
                e = d(Ad);
            return Md(function(f, g) {
                d(Ad) - e >= b && g(Jd)
            })(c)
        }
    }

    function Qd(a) {
        for (var b = !0, c = {}; !Gd(a) && b; c = {
                Vd: void 0
            }) b = !1, c.Vd = function() {
            b = !0;
            a.za += 1
        }, a.Nd(a.Ta[a.za], function(d) {
            return function() {
                (0, d.Vd)()
            }
        }(c)), b || (a.za += 1, c.Vd = E(a, Qd))
    }

    function Rd(a, b) {
        return ta({
            Ta: a,
            Nd: b || v,
            qe: !1,
            za: 0
        })
    }

    function Sd(a, b, c) {
        c = void 0 === c ? !1 : c;
        return new Q(function(d, e) {
            function f(k, l) {
                l();
                d()
            }
            var g = a.slice();
            g.push({
                R: f,
                ta: f
            });
            var h = Rd(g, function(k, l) {
                var m = c ? k.R : k.ta;
                if (m) try {
                    m(b, l)
                } catch (p) {
                    h(Id), e(p)
                } else l()
            });
            h(Qd)
        })
    }

    function Td(a) {
        try {
            return encodeURIComponent(a)
        } catch (b) {}
        a = T("", nb(function(b) {
            return 55296 >= b.charCodeAt(0)
        }, a.split("")));
        return encodeURIComponent(a)
    }

    function Ud(a) {
        var b = "";
        try {
            b = decodeURIComponent(a)
        } catch (c) {}
        return b
    }

    function Vd(a) {
        return a ? G(Kb(function(b) {
            var c = q(b.split("="));
            b = c.next().value;
            c = c.next().value;
            return [b, Ra(c) ? void 0 : Ud(c)]
        }), $a(function(b, c) {
            var d = q(c),
                e = d.next().value;
            d = d.next().value;
            b[e] = d;
            return b
        }, {}))(a.split("&")) : {}
    }

    function Wd(a) {
        return a ? G(bc, $a(function(b, c) {
            var d = q(c),
                e = d.next().value;
            d = d.next().value;
            B(d) || Ra(d) || b.push(e + "=" + Td(d));
            return b
        }, []), pd("&"))(a) : ""
    }

    function Xd(a, b, c) {
        var d = B(c);
        B(b) && d ? (d = 1, b = 1073741824) : d ? d = 1 : (d = b, b = c);
        return a.Math.floor(a.Math.random() * (b - d)) + d
    }

    function Yd(a, b, c) {
        return function() {
            var d = O(arguments[0]),
                e = c ? "global" : "m1570",
                f = d.C(e, {}),
                g = I(f, a);
            g || (g = x(b), f[a] = g, d.D(e, f));
            return g.apply(null, arguments)
        }
    }
    var Zd = sb([26812653]),
        $d = x(G(db("id"), Zd), N),
        ae = "hash host hostname href pathname port protocol search".split(" ");

    function U(a) {
        return F(function(b, c) {
            var d = I(a, "location." + c);
            b[c] = d ? "" + d : "";
            return b
        }, {}, ae)
    }
    var be = "ru by kz az kg lv md tj tm uz ee fr lt com co.il com.ge com.am com.tr com.ru".split(" "),
        ce = /(?:^|\.)(?:(ya\.ru)|(?:yandex)\.(\w+|com?\.\w+))$/;

    function de(a) {
        if (a = a.match(ce)) {
            var b = q(a);
            b.next();
            a = b.next().value;
            if (b = b.next().value) return J(b, be) ? b : !1;
            if (a) return be[0]
        }
        return !1
    }
    var ee = x(function(a) {
            return (a ? a.replace(/^www\./, "") : "").toLowerCase()
        }),
        fe = x(function(a) {
            a = U(a).hostname;
            var b = !1;
            a && (b = -1 !== a.search(ce));
            return b
        }),
        ge = G(U, db("protocol"), ra("https:")),
        he = x(function(a) {
            return qc(a) && ge(a) ? "SameSite=None;Secure;" : ""
        }),
        ie = /^\s+|\s+$/g,
        je = xa(String.prototype.trim, "trim");

    function ke(a, b) {
        if (a) {
            var c = je ? je.call(a) : ("" + a).replace(ie, "");
            return b && c.length > b ? c.substring(0, b) : c
        }
        return ""
    }
    var le = pa(function(a, b) {
            return b.replace(a, "")
        }),
        me = le(/\s/g),
        ne = le(/\D/g),
        oe = le(/\d/g),
        pe = ["metrika_enabled"],
        qe = [];

    function re(a, b) {
        var c = se;
        return !qe.length || J(b, pe) ? !0 : F(function(d, e) {
            return d && e(a, c, b)
        }, !0, qe)
    }

    function te(a) {
        try {
            var b = a.document.cookie;
            if (!Ra(b)) {
                var c = {};
                L(function(d) {
                    var e = q(d.split("="));
                    d = e.next().value;
                    e = e.next().value;
                    c[ke(d)] = ke(Ud(e))
                }, (b || "").split(";"));
                return c
            }
        } catch (d) {}
        return null
    }
    var ue = Yd("gsc", te);

    function se(a, b) {
        var c = ue(a);
        return c ? c[b] || null : null
    }
    var ve = /:\d+$/;

    function we(a, b, c, d, e, f, g) {
        g = void 0 === g ? !1 : g;
        if (re(a, b)) {
            var h = b + "=" + encodeURIComponent(c) + ";";
            h += "" + he(a);
            if (d) {
                var k = new Date;
                k.setTime(k.getTime() + 6E4 * d);
                h += "expires=" + k.toUTCString() + ";"
            }
            e && (d = e.replace(ve, ""), h += "domain=" + d + ";");
            try {
                a.document.cookie = h + ("path=" + (f || "/")), g || (ue(a)[b] = c)
            } catch (l) {}
        }
    }

    function xe(a, b) {
        we(a, "metrika_enabled", "1", 0, b, void 0, !0);
        var c = te(a);
        (c = c && c.metrika_enabled) && we(a, "metrika_enabled", "", -100, b, void 0, !0);
        return !!c
    }
    var ye = x(function(a) {
        var b = (U(a).host || "").split(".");
        return 1 === b.length ? b[0] : F(function(c, d, e) {
            e += 1;
            2 <= e && !c && (e = T(".", b.slice(-e)), xe(a, e) && (c = e));
            return c
        }, "", b)
    });

    function ze(a, b, c) {
        b = void 0 === b ? "_ym_" : b;
        c = void 0 === c ? "" : c;
        var d = ye(a),
            e = 1 === (d || "").split(".").length ? d : "." + d,
            f = c ? "_" + c : "";
        return {
            kc: function(g, h, k) {
                we(a, "" + b + g + f, "", -100, h || e, k, !1);
                return this
            },
            C: function(g) {
                return se(a, "" + b + g + f)
            },
            D: function(g, h, k, l, m) {
                we(a, "" + b + g + f, h, k, l || e, m);
                return this
            }
        }
    }
    var Ae = x(ze),
        Be = x(function(a) {
            var b = Ae(a),
                c = "1" === b.C("debug"),
                d = -1 < Ma(U(a).href, "_ym_debug=1") || -1 < Ma(U(a).href, "_ym_debug=2"),
                e = a._ym_debug;
            !e && !d || c || (a = U(a), b.D("debug", "1", void 0, a.host));
            return !!(c || e || d)
        });

    function Ce() {
        return {}
    }

    function De() {
        return []
    }
    var Ee = Yd("debuggerEvents", De, !0);

    function Fe(a, b) {
        if (Be(a)) {
            var c = b.counterKey;
            if (c) {
                var d = q(c.split(":"));
                c = d.next().value;
                d = d.next().value;
                c = Zd(Tb(c));
                if ("1" === d || c) return
            }
            c = Ee(a);
            1E3 === c.length && c.shift();
            c.push(b)
        }
    }

    function Ge(a, b, c) {
        var d = Xd(a),
            e = c.ea,
            f = c.ba,
            g = c.$a,
            h = c.ab;
        c = c.Vc;
        var k = {},
            l = {},
            m = {};
        Fe(a, (m.name = "request", m.data = (l.url = b, l.requestId = d, l.senderParams = (k.rBody = f, k.debugStack = e, k.rHeaders = g, k.rQuery = h, k.verb = c, k), l), m));
        return d
    }
    var He = xa(Array.prototype.find, "find");

    function Ie(a, b) {
        for (var c = 0; c < b.length; c += 1)
            if (a.call(b, b[c], c)) return b[c]
    }
    var Je = He ? function(a, b) {
            return He.call(b, a)
        } : Ie,
        Ke = pa(function(a, b) {
            var c = b || {};
            return {
                l: E(c, v),
                C: function(d, e) {
                    var f = c[d];
                    return B(f) && !B(e) ? e : f
                },
                D: function(d, e) {
                    c[d] = e;
                    return this
                },
                Tb: function(d, e) {
                    return "" === e || Ra(e) ? this : this.D(d, e)
                },
                Ha: E(c, a)
            }
        }),
        Le = Ke(function(a) {
            var b = "";
            a = F(function(c, d) {
                var e = q(d),
                    f = e.next().value;
                e = e.next().value;
                e = "" + f + ":" + e;
                "t" === f ? b = e : c.push(e);
                return c
            }, [], bc(a));
            b && a.push(b);
            return T(":", a)
        });

    function Me(a, b, c) {
        var d = M({}, b.H);
        a = Ed(a);
        b.K && (d["browser-info"] = Le(b.K.l()).D("st", a(Cd)).Ha());
        !d.t && (b = b.Ia) && (b.D("ti", c), d.t = b.Ha());
        return d
    }

    function Ne(a, b, c, d, e, f) {
        e = void 0 === e ? 0 : e;
        f = void 0 === f ? 0 : f;
        var g = M({
                ea: []
            }, d.N),
            h = q(b[f]),
            k = h.next().value;
        h = h.next().value;
        var l = c[e];
        if ((!g.$a || !g.$a["Content-Type"]) && g.ba) {
            var m = {};
            g.$a = M({}, g.$a, (m["Content-Type"] = "application/x-www-form-urlencoded", m));
            g.ba = "site-info=" + Td(g.ba)
        }
        g.Vc = g.ba ? "POST" : "GET";
        g.ab = Me(a, d, k);
        g.ra = (d.ma || {}).ra;
        g.ea.push(k);
        M(d.N, g);
        k = "" + l + (d.Jc && d.Jc.th ? "/1" : "");
        var p = 0;
        p = Ge(a, k, g);
        return h(k, g).then(function(r) {
            var t = p,
                w = {},
                z = {};
            Fe(a, (z.name = "requestSuccess", z.data =
                (w.body = r, w.requestId = t, w), z));
            return {
                Ga: r,
                Ae: e
            }
        })["catch"](function(r) {
            var t = p,
                w = {},
                z = {};
            Fe(a, (z.name = "requestFail", z.data = (w.error = r, w.requestId = t, w), z));
            t = f + 1 >= b.length;
            w = e + 1 >= c.length;
            t && w && md(r);
            return Ne(a, b, c, d, !w && t ? e + 1 : e, t ? 0 : f + 1)
        })
    }

    function Oe(a, b) {
        return function(c, d) {
            return Ne(a, b, d, c)
        }
    }

    function Pe(a, b) {
        L(G(v, Wa("push", a)), b);
        return a
    }

    function Qe(a, b) {
        return b ? a(b) : a()
    }
    var Re = G(v, Qe),
        Se = {
            id: "id",
            Ce: "ut",
            ca: "type",
            Rd: "ldc",
            Ua: "nck",
            rc: "url",
            Tg: "referrer"
        },
        Te = /^\d+$/,
        Ue = {
            id: function(a) {
                a = "" + (a || "0");
                Te.test(a) || (a = "0");
                try {
                    var b = Vb(a)
                } catch (c) {
                    b = 0
                }
                return b
            },
            ca: function(a) {
                return "" + (a || 0 === a ? a : "0")
            },
            Ua: kb,
            Ce: kb
        };
    Se.jd = "defer";
    Ue.jd = kb;
    Se.O = "params";
    Ue.O = function(a) {
        return Sa(a) || K(a) ? a : null
    };
    Se.Be = "userParams";
    Se.Vf = "triggerEvent";
    Ue.Vf = kb;
    Se.Hf = "sendTitle";
    Ue.Hf = function(a) {
        return !!a || B(a)
    };
    Se.we = "trackHash";
    Ue.we = kb;
    Se.Uf = "trackLinks";
    Se.Hg = "enableAll";
    var Rc = F(function(a, b) {
        var c = q(b),
            d = c.next().value;
        c = c.next().value;
        a[d] = {
            da: c,
            Va: Ue[d]
        };
        return a
    }, {}, bc(Se));

    function Ve(a) {
        M(Rc, a)
    }

    function We(a) {
        return F(function(b, c) {
            var d = q(c),
                e = d.next().value;
            d = d.next().value;
            b[Rc[e].da] = d;
            return b
        }, {}, bc(a))
    }

    function Xe(a, b, c) {
        for (var d = [b, c], e = -1E4, f = 0; f < a.length; f += 1) {
            var g = q(a[f]),
                h = g.next().value;
            g = g.next().value;
            if (c === g && h === b) return;
            if (c < g && c >= e) {
                a.splice(f, 0, d);
                return
            }
            e = g
        }
        a.push(d)
    }

    function Ye(a, b, c, d) {
        a[b] || (a[b] = []);
        c && !Ra(d) && Xe(a[b], c, d)
    }
    var $e = {},
        af = ($e.w = [
            [function(a, b) {
                return {
                    R: function(c, d) {
                        var e = c.H,
                            f = {};
                        e = (f["page-url"] = e && e["page-url"] || "", f.charset = "utf-8", f);
                        "0" !== b.ca && (e["cnt-class"] = b.ca);
                        c.K || (c.K = Le());
                        f = c.K;
                        e = {
                            ma: {
                                ra: "watch/" + b.id
                            },
                            N: M(void 0 === c.N ? {} : c.N, {
                                cb: !!f.C("pv") && !f.C("ar") && !f.C("wh")
                            }),
                            H: M(c.H || {}, e)
                        };
                        M(c, e);
                        d()
                    }
                }
            }, 1]
        ], $e),
        bf = E(af, Ye);

    function cf(a, b, c) {
        var d = Oe(a, b);
        return function(e) {
            return Sd(c, e, !0).then(function() {
                var f = e.ma || {},
                    g = void 0 === f.$e ? "" : f.$e,
                    h = void 0 === f.ra ? "" : f.ra;
                f = L(function(k) {
                    return Nc.La + "//" + ("" + g + k || Lc) + "/" + h
                }, void 0 === f.af ? [Lc] : f.af);
                return d(e, f)
            }).then(function(f) {
                var g = f.Ga;
                f = f.Ae;
                e.zf = g;
                e.Gi = f;
                return Sd(c, e).then(E(g, v))
            })
        }
    }

    function df(a) {
        return function(b, c, d) {
            return function(e, f) {
                var g = L(G(xb, ab([b, f]), Qe), af[a] || []);
                g = Pe(g, d);
                return cf(b, c, g)(e)
            }
        }
    }
    var ef = df("w"),
        ff = ["webkitvisibilitychange", "visibilitychange"];

    function gf(a) {
        return {
            R: function(b, c) {
                var d = a.document,
                    e = b.K;
                if (e && Ec(a)) {
                    var f = ud(a),
                        g = function(h) {
                            Ec(a) || (f.Xb(d, ff, g), c());
                            return h
                        };
                    f.F(d, ff, g);
                    e.D("pr", "1")
                } else c()
            }
        }
    }

    function hf(a) {
        var b = "";
        K(a) ? b = T(".", a) : y(a) && (b = a);
        return S("err.kn(" + Nc.eb + ")" + b)
    }

    function jf() {
        var a = Ha(arguments);
        md(hf(a))
    }
    var kf = Xa(RegExp("^err.kn")),
        lf = [];

    function mf(a, b, c) {
        var d = "u.a.e",
            e = "";
        c && ("object" === typeof c ? (c.unk && md(c), d = c.message, e = "string" === typeof c.stack && c.stack.replace(/\n/g, "\\n") || "n.s.e.s") : d = "" + c);
        kf(d) || Ob(E(d, Na), hd) || ld(d) && .1 <= a.Math.random() || L(G(v, ab(["jserrs", d, b, e]), Qe), lf)
    }

    function V(a, b, c, d, e) {
        var f = c || md;
        return function() {
            var g = d;
            try {
                g = f.apply(e || null, arguments)
            } catch (h) {
                mf(a, b, h)
            }
            return g
        }
    }

    function W(a, b, c) {
        return function() {
            return V(arguments[0], a, b, c).apply(this, arguments)
        }
    }
    var nf = Ke(function(a) {
        a = bc(a);
        return T("", L(function(b) {
            var c = q(b);
            b = c.next().value;
            c = c.next().value;
            return Qa(c) ? "" : b + "(" + c + ")"
        }, a))
    });

    function of (a, b, c) {
        c = void 0 === c ? null : c;
        a.Ia || (a.Ia = nf());
        b && a.Ia.Tb(b, c);
        return a.Ia
    }
    var pf = "A B BIG BODY BUTTON DD DIV DL DT EM FIELDSET FORM H1 H2 H3 H4 H5 H6 HR I IMG INPUT LI OL P PRE SELECT SMALL SPAN STRONG SUB SUP TABLE TBODY TD TEXTAREA TFOOT TH THEAD TR U UL ABBR AREA BLOCKQUOTE CAPTION CENTER CITE CODE CANVAS DFN EMBED FONT INS KBD LEGEND LABEL MAP OBJECT Q S SAMP STRIKE TT ARTICLE AUDIO ASIDE FOOTER HEADER MENU METER NAV PROGRESS SECTION TIME VIDEO NOINDEX NOBR MAIN svg circle clippath ellipse defs foreignobject g glyph glyphref image line lineargradient marker mask path pattern polygon polyline radialgradient rect set text textpath title".split(" "),
        qf = [],
        rf = /^\s*(data|javascript):/i,
        sf = new RegExp(T("", ["\\.(" + T("|", "3gp 7z aac ac3 acs ai avi ape apk asf bmp bz2 cab cdr crc32 css csv cue divx dmg djvu? doc(x|m|b)? emf eps exe flac? flv iso swf gif t?gz jpe?g? js m3u8? m4a mp(3|4|e?g?) m4v md5 mkv mov msi ods og(g|m|v) psd rar rss rtf sea sfv sit sha1 svg tar tif?f torrent ts txt vob wave? wma wmv wmf webm ppt(x|m|b)? xls(x|m|b)? pdf phps png xpi g?zip".split(" ")) + ")$"]), "i"),
        tf = {},
        uf = (tf.hit = "h", tf.params = "p", tf.reachGoal = "g", tf.userParams = "up",
            tf.trackHash = "th", tf.accurateTrackBounce = "atb", tf.notBounce = "nb", tf.addFileExtension = "fe", tf.extLink = "el", tf.file = "fc", tf.trackLinks = "tl", tf.destruct = "d", tf.setUserID = "ui", tf.getClientID = "ci", tf.clickmap = "cm", tf.enableAll = "ea", tf),
        vf = G(N, x(function() {
            var a = 0;
            return function() {
                return a += 1
            }
        }), Qe),
        wf = {
            mc: function(a) {
                a = Sc(a).C("mt", {});
                a = bc(a);
                return a.length ? F(function(b, c, d) {
                    var e = q(c);
                    c = e.next().value;
                    e = e.next().value;
                    return "" + b + (d ? "-" : "") + c + "-" + e
                }, "", a) : null
            },
            clc: function(a) {
                var b = O(a).C("cls", {
                        ec: 0,
                        x: 0,
                        y: 0
                    }),
                    c = b.ec,
                    d = b.x;
                b = b.y;
                return c ? c + "-" + a.Math.floor(d / c) + "-" + a.Math.floor(b / c) : c + "-" + d + "-" + b
            },
            rqnt: function(a, b, c) {
                a = c.H;
                return !a || a.nohit ? null : vf(b)
            }
        };

    function xf(a, b) {
        if (!b) return null;
        try {
            return a.JSON.parse(b)
        } catch (c) {
            return null
        }
    }

    function yf(a, b) {
        try {
            return a.JSON.stringify(b, null, void 0)
        } catch (c) {
            return null
        }
    }

    function zf(a) {
        try {
            return a.localStorage
        } catch (b) {}
        return null
    }

    function Af(a, b) {
        var c = zf(a);
        try {
            c.removeItem(b)
        } catch (d) {}
    }

    function Bf(a, b) {
        var c = zf(a);
        try {
            return xf(a, c.getItem(b))
        } catch (d) {}
        return null
    }

    function Cf(a, b, c) {
        var d = zf(a);
        a = yf(a, c);
        if (!Qa(a)) try {
            d.setItem(b, a)
        } catch (e) {}
    }
    var Df = x(function(a) {
        Cf(a, "_ymBRC", "1");
        var b = "1" !== Bf(a, "_ymBRC");
        b || Af(a, "_ymBRC");
        return b
    });

    function Ef(a, b, c) {
        var d = "" + (void 0 === c ? "_ym" : c) + (void 0 === b ? "" : b);
        d && (d += "_");
        return {
            Jd: Df(a),
            C: function(e, f) {
                var g = Bf(a, "" + d + e);
                return Qa(g) && !B(f) ? f : g
            },
            D: function(e, f) {
                Cf(a, "" + d + e, f);
                return this
            },
            kc: function(e) {
                Af(a, "" + d + e);
                return this
            }
        }
    }
    var Ff = x(Ef),
        Gf = x(Ef, function(a, b, c) {
            return "" + b + c
        });

    function Hf(a) {
        if (Ra(a)) return !1;
        a = a.nodeType;
        return 3 === a || 8 === a
    }

    function If(a) {
        return a ? a.innerText || "" : ""
    }
    var Jf = x(db("document.documentElement")),
        Kf = x(function(a) {
            a = I(a, "document") || {};
            return ("" + (a.characterSet || a.charset || "")).toLowerCase()
        }),
        Lf = x(G(db("document"), E("createElement", gb)));

    function Mf(a) {
        var b = a && a.parentNode;
        b && b.removeChild(a)
    }

    function Nf(a) {
        var b;
        try {
            if (b = a.target || a.srcElement) !b.ownerDocument && b.documentElement ? b = b.documentElement : b.ownerDocument !== document && (b = null)
        } catch (c) {}
        return b
    }

    function Of(a, b) {
        try {
            return (new RegExp("(?:^|\\s)" + a + "(?:\\s|$)")).test(b.className)
        } catch (c) {
            return !1
        }
    }
    var Pf = x(function(a) {
        var b = I(a, "Element.prototype");
        return b ? (a = Je(function(c) {
            var d = b[c];
            return !!d && wa(c, d)
        }, ["matches", "webkitMatchesSelector", "mozMatchesSelector", "msMatchesSelector", "oMatchesSelector"])) ? b[a] : null : null
    });

    function Qf(a) {
        a = I(a, "document");
        try {
            return a.getElementsByTagName("body")[0]
        } catch (b) {
            return null
        }
    }

    function Rf(a) {
        var b = I(a, "document") || {},
            c = b.documentElement;
        return "CSS1Compat" === b.compatMode ? c : Qf(a) || c
    }

    function Sf(a) {
        var b = I(a, "visualViewport.width"),
            c = I(a, "visualViewport.height");
        a = I(a, "visualViewport.scale");
        return Ra(b) || Ra(c) ? null : [Math.floor(b), Math.floor(c), a]
    }

    function Tf(a) {
        var b = Sf(a);
        if (b) {
            var c = q(b);
            b = c.next().value;
            var d = c.next().value;
            c = c.next().value;
            return [a.Math.round(b * c), a.Math.round(d * c)]
        }
        b = Rf(a);
        return [I(b, "clientWidth") || a.innerWidth, I(b, "clientHeight") || a.innerHeight]
    }

    function Uf(a) {
        var b = Qf(a),
            c = I(a, "document");
        return {
            x: a.pageXOffset || c.documentElement && c.documentElement.scrollLeft || b && b.scrollLeft || 0,
            y: a.pageYOffset || c.documentElement && c.documentElement.scrollTop || b && b.scrollTop || 0
        }
    }

    function Vf(a) {
        try {
            return a.getBoundingClientRect && a.getBoundingClientRect()
        } catch (b) {
            return a = b, "object" === typeof a && null !== a && 16389 === (a.mf && a.mf & 65535) ? {
                top: 0,
                bottom: 0,
                left: 0,
                width: 0,
                height: 0,
                right: 0
            } : null
        }
    }

    function Wf(a, b, c) {
        c = gb("dispatchEvent", c || a.document);
        var d = null,
            e = I(a, "Event.prototype.constructor");
        if (e && (wa("(Event|Object|constructor)", e) || uc(a) && "[object Event]" === "" + e)) try {
            d = new a.Event(b)
        } catch (f) {
            if ((a = gb("createEvent", I(a, "document"))) && A(a)) {
                try {
                    d = a(b)
                } catch (g) {}
                d && d.initEvent && d.initEvent(b, !1, !1)
            }
        }
        d && c(d)
    }

    function Xf(a, b) {
        var c = a.document.getElementsByTagName("form");
        return Aa(a)(b, vb(c))
    }

    function Yf(a) {
        if (a) try {
            var b = a.nodeName;
            if (y(b)) return b;
            b = a.tagName;
            if (y(b)) return b
        } catch (c) {}
    }
    var Zf = ra("INPUT"),
        $f = G(Yf, Zf),
        ag = ra("TEXTAREA"),
        bg = G(Yf, ag),
        cg = ra("SELECT"),
        dg = G(Yf, cg),
        eg = G(db("type"), Xa(/^(checkbox|radio)$/)),
        fg = G(Yf, Xa(/^INPUT|SELECT|TEXTAREA$/)),
        gg = G(Yf, Xa(/^INPUT|SELECT|TEXTAREA|BUTTON$/)),
        hg = "INPUT CHECKBOX RADIO TEXTAREA SELECT PROGRESS".split(" "),
        ig = ["submit", "image", "hidden"];

    function jg(a) {
        return $f(a) && !Ob(ra(a.type), ig) ? eg(a) ? !a.checked : !a.value : bg(a) ? !a.value : dg(a) ? 0 > a.selectedIndex : !0
    }
    var kg = /\/$/;

    function lg(a) {
        var b = O(a),
            c = b.C("hitId");
        c || (c = Xd(a), b.D("hitId", c));
        return c
    }

    function mg(a, b) {
        var c = Ff(a),
            d = Ae(a),
            e = b.Rd || "uid";
        return [c.C(e), d.C(e)]
    }
    var ng = Yd("r", function(a, b) {
        var c = q(mg(a, b)),
            d = c.next().value;
        return !c.next().value && d
    });

    function og(a, b) {
        return !b.Ua && ng(a, b)
    }

    function pg(a, b) {
        var c = b.Rd,
            d = c || "uid";
        c = c ? a.location.hostname : void 0;
        var e = Ae(a),
            f = Ff(a),
            g = Ed(a)(Cd),
            h = q(mg(a, b)),
            k = h.next().value;
        h = h.next().value;
        var l = e.C("d");
        ng(a, b);
        var m = !1;
        !h && k && (h = k, m = !0);
        if (!h) h = T("", [g, Xd(a, 1E6, 999999999)]), m = !0;
        else if (!l || 15768E3 < g - Vb(l)) m = !0;
        m && !b.Ua && (e.D(d, h, 525600, c), e.D("d", "" + g, 525600, c));
        f.D(d, h);
        return h
    }

    function qg(a, b, c) {
        return gb("setTimeout", a)(b, c)
    }

    function rg(a, b) {
        return gb("clearTimeout", a)(b)
    }

    function X(a, b, c, d) {
        return qg(a, V(a, "d.err." + (d || "def"), b), c)
    }

    function sg(a, b) {
        return a.setInterval(V(a, "i.err.t.h", b), 200)
    }

    function tg(a, b) {
        return a.clearInterval(b)
    }

    function ug(a, b) {
        return function(c) {
            return c(a, b)
        }
    }
    var vg = pa(function(a, b) {
            return ta(function(c, d) {
                return b(c, function(e) {
                    try {
                        d(a(e))
                    } catch (f) {
                        c(f)
                    }
                })
            })
        }),
        wg = pa(function(a, b) {
            return ta(function(c, d) {
                return b(c, function(e) {
                    try {
                        a(e)(ug(c, d))
                    } catch (f) {
                        c(f)
                    }
                })
            })
        });

    function xg(a) {
        var b = [],
            c = !1;
        return ta(function(d, e) {
            function f(g) {
                b.push(g) === a.length && d(b)
            }
            L(function(g) {
                g(ug(f, function(h) {
                    if (!c) try {
                        e(h), c = !0
                    } catch (k) {
                        f(k)
                    }
                }))
            }, a)
        })
    }

    function yg(a) {
        var b = [],
            c = 0;
        return ta(function(d, e) {
            L(function(f, g) {
                f(ug(d, function(h) {
                    try {
                        b[g] = h, c += 1, c === a.length && e(b)
                    } catch (k) {
                        d(k)
                    }
                }))
            }, a)
        })
    }

    function zg(a) {
        return ta(function(b, c) {
            a.then(c, b)
        })
    }

    function Ag(a) {
        return ta(function(b, c) {
            c(a)
        })
    }

    function Bg(a, b) {
        function c(e) {
            I(b, d) ? e() : X(a, E(e, c), 100)
        }
        b = void 0 === b ? a : b;
        var d = (b.nodeType ? "contentWindow." : "") + "document.body";
        return ta(function(e, f) {
            c(f)
        })
    }

    function Cg(a) {
        var b = [],
            c = {
                Di: b
            };
        c.F = G(Wa("push", b), E(c, v));
        c.ga = G(qa(Aa(a))(b), qa(Wa("splice", b))(1), E(c, v));
        c.$ = G(v, qa(Qe), Lb(b));
        return c
    }

    function Dg(a) {
        var b = {};
        return {
            F: function(c, d) {
                L(function(e) {
                    I(b, e) || (b[e] = Cg(a));
                    b[e].F(d)
                }, c);
                return this
            },
            ga: function(c, d) {
                L(function(e) {
                    I(b, e) && b[e].ga(d)
                }, c);
                return this
            },
            $: function(c, d) {
                return I(b, c) ? V(a, "e." + c, b[c].$, [])(d) : []
            }
        }
    }
    var Eg = x(function() {
            return {
                Fa: {},
                pending: {},
                children: {}
            }
        }),
        Fg = db("postMessage");

    function Gg(a, b) {
        return function(c, d) {
            var e = {
                jc: Ed(a)(Ad),
                key: a.Math.random(),
                dir: 0
            };
            c.length && (e.jc = Vb(c[0]), e.key = parseFloat(c[1]), e.dir = Vb(c[2]));
            M(d, b);
            var f = {};
            f = (f.data = d, f.__yminfo = T(":", ["__yminfo", e.jc, e.key, e.dir]), f);
            return {
                meta: e,
                Of: yf(a, f) || ""
            }
        }
    }
    var Hg = W("s.f", function(a, b, c, d, e) {
        b = b(d);
        var f = Eg(a),
            g = T(":", [b.meta.jc, b.meta.key]);
        if (Fg(c)) {
            f.pending[g] = e;
            try {
                c.postMessage(b.Of, "*")
            } catch (h) {
                delete f.pending[g];
                return
            }
            X(a, function() {
                delete f.pending[g]
            }, 5E3, "if.s")
        }
    });

    function Ig(a) {
        if (wa("MutationObserver", a.MutationObserver)) {
            var b = Eg(a).children,
                c = new a.MutationObserver(function() {
                    L(function(d) {
                        I(b[d], "window.window") || delete b[d]
                    }, cc(b))
                });
            Bg(a)(ug(u, function() {
                c.observe(a.document.body, {
                    subtree: !0,
                    childList: !0
                })
            }))
        }
    }

    function Jg(a, b) {
        var c = Eg(a);
        b.F(["initToParent"], function(d) {
            var e = q(d);
            d = e.next().value;
            e = e.next().value;
            window.window && (c.children[e.counterId] = {
                info: e,
                window: d.source
            })
        }).F(["initToChild"], function(d) {
            var e = q(d);
            d = e.next().value;
            e = e.next().value;
            d.source === a.parent && b.$("parentConnect", [d, e])
        }).F(["parentConnect"], function(d) {
            var e = q(d);
            d = e.next().value;
            e = e.next().value;
            e.counterId && (c.Fa[e.counterId] = {
                info: e,
                window: d.source
            })
        })
    }
    var Kg = W("s.fh", function(a, b, c, d, e, f) {
            var g = null,
                h = null,
                k = Eg(a),
                l = null;
            try {
                g = xf(a, f.data), h = g.__yminfo, l = g.data
            } catch (m) {
                return
            }
            if (!Ra(h) && h.substring && "__yminfo" === h.substring(0, 8) && !Ra(l) && (a = h.split(":"), 4 === a.length))
                if (g = b.id, h = q(a), h.next(), b = h.next().value, a = h.next().value, h = h.next().value, !K(l) && l.type && "0" === h && l.counterId) {
                    if (!l.toCounter || l.toCounter == g) {
                        k = null;
                        try {
                            k = f.source
                        } catch (m) {}!Qa(k) && Fg(k) && (f = d.$(l.type, [f, l]), e = L(G(v, hc(e)), f.concat([void 0])), l = c([b, a, l.counterId], e), k.postMessage(l.Of,
                            "*"))
                    }
                } else h === "" + g && K(l) && nb(function(m) {
                    return !(!m.hid || !m.counterId)
                }, l).length === l.length && (c = k.pending[T(":", [b, a])]) && c.apply(null, [f].concat(l))
        }),
        Lg = x(function(a, b) {
            var c = gb("getElementsByTagName", I(a, "document")),
                d = Eg(a),
                e = Fg(a),
                f = Dg(a),
                g = ud(a);
            if (!c || !e) return null;
            c = c.call(a.document, "iframe");
            e = {};
            e = (e.counterId = b.id, e.hid = "" + lg(a), e);
            Jc(a) && (e.duid = pg(a, b));
            Jg(a, f);
            Ig(a);
            var h = Gg(a, e),
                k = D([a, E([], h)], Hg);
            L(function(l) {
                var m = null;
                try {
                    m = l.contentWindow
                } catch (p) {}
                m && k(m, {
                        type: "initToChild"
                    },
                    function(p, r) {
                        f.$("initToParent", [p, r])
                    })
            }, c);
            xc(a) && k(a.parent, {
                type: "initToParent"
            }, function(l, m) {
                f.$("parentConnect", [l, m])
            });
            g.F(a, ["message"], D([a, b, h, f, e], Kg));
            return {
                Z: f,
                Fa: d.Fa,
                children: d.children,
                ke: k
            }
        }, G(Da, N)),
        Mg = x(function(a, b) {
            if (!Jc(a) || !xc(a)) return pg(a, b);
            var c = Lg(a, b);
            return c && c.Fa[b.id] ? c.Fa[b.id].info.duid || pg(a, b) : pg(a, b)
        }, function(a, b) {
            return "" + b.Rd + b.Ua
        }),
        Ng = x(G(Ed, ta(function(a) {
            return -(new a.l.Date).getTimezoneOffset()
        }))),
        Og = G(Ed, ta(function(a) {
            a = new a.l.Date;
            return T("",
                L(yd, [a.getFullYear(), a.getMonth() + 1, a.getDate(), a.getHours(), a.getMinutes(), a.getSeconds()]))
        })),
        Pg = G(Ed, ta(Cd)),
        Qg = x(G(Ed, ta(function(a) {
            return q(a.Hc).next().value
        }))),
        Rg = x(function(a) {
            a = O(a);
            var b = a.C("counterNum", 0) + 1;
            a.D("counterNum", b);
            return b
        }, G(Da, N)),
        Sg = {},
        Tg = (Sg.vf = E(na.version, v), Sg.nt = tc, Sg.fu = function(a, b, c) {
            var d = c.H;
            if (!d) return null;
            b = (I(a, "document.referrer") || "").replace(kg, "");
            c = (d["page-ref"] || "").replace(kg, "");
            d = d["page-url"];
            a = U(a).href !== d;
            b = b !== c;
            c = 0;
            a && b ? c = 3 : b ? c = 1 : a && (c =
                2);
            return c
        }, Sg.en = Kf, Sg.la = vc, Sg.ut = function(a, b, c) {
            var d = c.M;
            c = c.H;
            d = d && d.Ac;
            c && (fe(a) || b.Ce || d) && (c.ut = Nc.gg);
            return null
        }, Sg.v = E(Nc.eb, v), Sg.cn = Rg, Sg.dp = function(a) {
            var b = O(a),
                c = b.C("bt", {});
            if (B(b.C("bt"))) {
                var d = I(a, "navigator.getBattery");
                try {
                    c.p = d && d.call(a.navigator)
                } catch (e) {}
                b.D("bt", c);
                c.p && c.p.then && c.p.then(V(a, "bi:dp.p", function(e) {
                    c.$h = I(e, "charging") && 0 === I(e, "chargingTime")
                }))
            }
            return jb(c.$h)
        }, Sg.ls = x(function(a, b) {
            var c = Gf(a, b.id),
                d = Ed(a),
                e = c.C("lsid");
            return +e ? e : (d = Xd(a, 0, d(Ad)),
                c.D("lsid", d), d)
        }, Da), Sg.hid = lg, Sg.phid = function(a, b) {
            if (!xc(a)) return null;
            var c = Lg(a, b);
            if (!c) return null;
            var d = cc(c.Fa);
            return d.length ? c.Fa[d[0]].info.hid : null
        }, Sg.z = Ng, Sg.i = Og, Sg.et = Pg, Sg.c = G(db("navigator.cookieEnabled"), ib), Sg.rn = G(v, Xd), Sg.rqn = function(a, b, c) {
            c = c.H;
            if (!c || c.nohit) return null;
            b = N(b);
            a = Gf(a, b);
            b = (a.C("reqNum", 0) || 0) + 1;
            a.D("reqNum", b);
            if (a.C("reqNum") === b) return b;
            a.kc("reqNum");
            return null
        }, Sg.u = Mg, Sg.w = function(a) {
            var b = q(Tf(a));
            a = b.next().value;
            b = b.next().value;
            return a + "x" +
                b
        }, Sg.s = function(a) {
            var b = I(a, "screen");
            if (b) {
                a = I(b, "width");
                var c = I(b, "height");
                b = I(b, "colorDepth") || I(b, "pixelDepth");
                return T("x", [a, c, b])
            }
            return null
        }, Sg.sk = db("devicePixelRatio"), Sg.ifr = G(xc, ib), Sg.j = G(zc, ib), Sg.sti = function(a) {
            return xc(a) && yc(a) ? "1" : null
        }, Sg),
        Ug = x(function() {
            return Pe(cc(Tg), cc(wf))
        });

    function Vg(a) {
        return function(b, c) {
            return {
                R: function(d, e) {
                    var f = d.K,
                        g = d.H;
                    f && g && L(function(h) {
                        var k = Tg[h],
                            l = "bi",
                            m = f;
                        k || (k = wf[h], l = "tel", m = of (d));
                        k && (k = W(l + ":" + h, k, null)(b, c, d), m.Tb(h, k))
                    }, a || Ug());
                    e()
                }
            }
        }
    }

    function Wg(a, b) {
        return {
            R: function(c, d) {
                var e = c.K;
                if (e && (!b || b.Hf)) {
                    var f = a.document.title;
                    c.M && c.M.title && (f = c.M.title);
                    var g = gb("getElementsByTagName", a.document);
                    "string" !== typeof f && g && (f = g("title"), f = (f = I(f, "0.innerHtml")) ? f : "");
                    f = f.slice(0, Nc.dg);
                    e.D("t", f)
                }
                d()
            }
        }
    }
    var Xg = x(Ce, N);

    function Yg(a, b, c) {
        if (Jc(a) && xc(a)) {
            var d = Xg(b);
            if (!d.lh) {
                d.lh = !0;
                b = Lg(a, b);
                if (!b) {
                    c();
                    return
                }
                d.ya = [];
                var e = function() {
                    d.ya && (L(Qe, d.ya), d.ya = null)
                };
                X(a, e, 3E3);
                b.Z.F(["initToChild"], e)
            }
            d.ya ? d.ya.push(c) : c()
        } else c()
    }
    var Zg = x(function() {
        return {
            Te: null,
            ya: []
        }
    }, N);

    function $g(a) {
        return (a = a.K) && a.C("pv") && !a.C("ar")
    }

    function ah(a, b, c) {
        var d = a.K;
        d ? $g(a) ? (b.Te = d, c()) : b.ya ? b.ya.push(c) : c() : c()
    }

    function bh(a, b) {
        return {
            R: function(c, d) {
                var e = Zg(b);
                e = D([c, e, d], ah);
                Yg(a, b, e)
            },
            ta: function(c, d) {
                var e = c.K,
                    f = Zg(b);
                if (e) {
                    var g = f.ya;
                    f.Te === e && g && (L(Qe, g), f.ya = null)
                }
                d()
            }
        }
    }
    var ch = /^[a-z][\w.+-]+:/i;

    function dh(a, b) {
        var c = U(a),
            d = c.href,
            e = c.host,
            f = -1;
        if (!y(b) || B(b)) return d;
        c = b.replace(ie, "");
        if (-1 !== c.search(ch)) return c;
        var g = c.charAt(0);
        if ("?" === g && (f = d.search(/\?/), -1 === f) || "#" === g && (f = d.search(/#/), -1 === f)) return d + c;
        if (-1 !== f) return d.substr(0, f) + c;
        if ("/" === g) {
            if (f = La(d, e), -1 !== f) return d.substr(0, f + e.length) + c
        } else return d = d.split("/"), d[d.length - 1] = c, T("/", d);
        return ""
    }

    function eh(a) {
        return {
            R: function(b, c) {
                var d = b.H;
                if (!b.K || !d) return c();
                var e = d["page-ref"],
                    f = d["page-url"];
                e && f !== e ? d["page-ref"] = dh(a, e) : delete d["page-ref"];
                d["page-url"] = dh(a, f).slice(0, Nc.eg);
                return c()
            }
        }
    }
    var fh = [
            [gf, 1],
            [bh, 2],
            [Vg(), 3],
            [Wg, 4]
        ],
        gh = [],
        hh = E(fh, Xe),
        ih = {},
        jh = (ih.h = fh, ih),
        kh = E(jh, Ye);
    hh(eh, -100);

    function lh(a, b, c) {
        b = K(b) ? b : jh[b] || fh;
        var d = L(xb, b);
        L(function(e) {
            return d.unshift(e)
        }, gh);
        return L(G(ab([a, c]), Qe), d)
    }

    function mh(a, b, c, d) {
        return new Q(function(e, f) {
            if (!I(a, "navigator.onLine")) return f();
            var g = {};
            g = M(d.ab, (g["force-urlencoded"] = 1, g));
            g = c + "?" + Wd(g) + (d.ba ? "&" + d.ba : "");
            return 2E3 < g.length ? f(hf("sb.tlq")) : b(g) ? e("") : f()
        })
    }

    function nh(a) {
        var b = I(a, "navigator.sendBeacon");
        return b && wa("sendBeacon", b) ? D([a, C(b, I(a, "navigator"))], mh) : !1
    }

    function oh(a, b) {
        var c = Lf(a);
        if (c) {
            var d = a.document,
                e = c("script");
            e.src = b.src;
            e.type = b.type || "text/javascript";
            e.charset = b.charset || "utf-8";
            e.async = b.async || !0;
            try {
                var f = d.getElementsByTagName("head")[0];
                if (!f) {
                    var g = d.getElementsByTagName("html")[0];
                    f = c("head");
                    g && g.appendChild(f)
                }
                f.insertBefore(e, f.firstChild);
                return e
            } catch (h) {}
        }
    }
    var ph = x(function(a) {
        if (a = Lf(a)) return a("a")
    });

    function qh(a, b) {
        var c = ph(a);
        return c ? (c.href = b, {
            protocol: c.protocol,
            host: c.host,
            port: c.port,
            hostname: c.hostname,
            hash: c.hash,
            search: c.search,
            query: c.search.replace(/^\?/, ""),
            pathname: c.pathname || "/",
            path: (c.pathname || "/") + c.search,
            href: c.href
        }) : {}
    }

    function rh(a) {
        return (a.split(":")[1] || "").replace(/^\/*/, "").replace(/^www\./, "").split("/")[0]
    }

    function sh(a, b) {
        if (!b || !b.length) return a;
        var c = q(a.split("#")),
            d = c.next().value;
        c = ba(c);
        c = (c = T("#", c)) ? "#" + c : "";
        return Na(a, "?") ? d + "&" + b + c : d + "?" + b + c
    }

    function th(a, b, c) {
        (c = Wd(c)) && (a = sh(a, c));
        b.ba && (a = sh(a, b.ba));
        return a
    }

    function uh(a, b) {
        try {
            delete a[b]
        } catch (c) {
            a[b] = void 0
        }
    }

    function vh(a, b, c) {
        return new Q(function(d, e) {
            var f = "_ymjsp" + Xd(a),
                g = {};
            g = M((g.callback = f, g), c.ab);
            var h = D([a, f], uh);
            a[f] = function(l) {
                try {
                    h(), Mf(k), d(l)
                } catch (m) {
                    e(m)
                }
            };
            g.wmode = "5";
            f = {};
            var k = oh(a, (f.src = th(b, c, g), f));
            if (!k) return h(), e(S("jp.s"));
            f = E(k, Mf);
            f = G(f, E(hf(c.ea), e));
            g = qg(a, f, c.Oa || 1E4);
            g = D([a, g], rg);
            k.onload = g;
            k.onerror = G(h, g, f)
        })
    }

    function wh(a, b, c, d) {
        var e = {};
        e = M(d.cb ? (e.wmode = "7", e) : {}, d.ab);
        var f = b || {
                signal: void 0,
                abort: u
            },
            g = a.fetch(sh(c, Wd(e)), {
                method: d.Vc,
                body: d.ba,
                credentials: !1 === d.Wc ? "omit" : "include",
                headers: d.$a,
                signal: f.signal
            }),
            h = E(d.ea, hf);
        return new Q(function(k, l) {
            d.Oa && qg(a, function() {
                try {
                    f.abort()
                } catch (m) {}
                l(h())
            }, d.Oa);
            return g.then(function(m) {
                if (!m.ok) {
                    if (d.Nc) return md(kd(m));
                    jf(d.ea)
                }
                return d.Nc ? m.text() : d.cb ? m.json() : null
            }).then(k)["catch"](E(h(), l))
        })
    }
    var xh = /[^a-z0-9.:-]/;

    function yh(a, b, c, d, e, f, g, h) {
        if (4 === b.readyState)
            if (200 === b.status || e || g(c), e) 200 === b.status ? f(b.responseText) : g(kd(b));
            else {
                e = null;
                if (d) try {
                    (e = xf(a, b.responseText)) || g(c)
                } catch (k) {
                    g(c)
                }
                f(e)
            }
        return h
    }

    function zh(a, b, c) {
        var d = new a.XMLHttpRequest,
            e = c.ba,
            f = {},
            g = M(c.cb ? (f.wmode = "7", f) : {}, c.ab);
        return new Q(function(h, k) {
            d.open(c.Vc || "GET", sh(b, Wd(g)), !0);
            d.withCredentials = !1 !== c.Wc;
            c.Oa && (d.timeout = c.Oa);
            G(bc, Kb(function(m) {
                var p = q(m);
                m = p.next().value;
                p = p.next().value;
                d.setRequestHeader(m, p)
            }))(c.$a);
            var l = D([a, d, hf(c.ea), c.cb, c.Nc, h, k], yh);
            d.onreadystatechange = l;
            try {
                d.send(e)
            } catch (m) {}
        })
    }

    function Ah(a, b, c, d) {
        return new Q(function(e, f) {
            var g = Rf(a),
                h = b("img"),
                k = G(E(h, Mf), E(hf(d.ea), f)),
                l = qg(a, k, d.Oa || 3E3);
            h.onerror = k;
            h.onload = G(E(h, Mf), E(null, e), D([a, l], rg));
            k = M({}, d.ab);
            delete k.wmode;
            h.src = th(c, d, k);
            lc(a) && (M(h.style, {
                position: "absolute",
                visibility: "hidden",
                width: "0px",
                height: "0px"
            }), g.appendChild(h))
        })
    }
    var Bh = {},
        Ch = (Bh.x = {
            id: 2,
            check: function(a) {
                var b;
                if (b = I(a, "XMLHttpRequest"))
                    if (b = "withCredentials" in new a.XMLHttpRequest) {
                        a: {
                            if (xh.test(a.location.host) && a.opera && A(a.opera.version) && (b = a.opera.version(), "string" === typeof b && "12" === b.split(".")[0])) {
                                b = !0;
                                break a
                            }
                            b = !1
                        }
                        b = !b
                    }
                return b ? E(a, zh) : !1
            }
        }, Bh.i = {
            id: 4,
            check: function(a) {
                var b = Lf(a);
                return b ? D([a, b], Ah) : !1
            }
        }, Bh);
    Ch.f = {
        id: 1,
        check: function(a) {
            if (a.fetch) {
                var b = I(a, "AbortController");
                return D([a, b ? new b : void 0], wh)
            }
            return !1
        }
    };
    Ch.b = {
        id: 0,
        check: function(a) {
            return !oc(a) && nh(a)
        }
    };
    Ch.j = {
        id: 3,
        check: function(a) {
            return Lf(a) ? E(a, vh) : !1
        }
    };
    var Dh = {};

    function Eh(a) {
        if (a) return F(function(b, c) {
            var d = Ch[c];
            d && b.push(d);
            return b
        }, [], a)
    }

    function Fh(a) {
        return Dh["*"] ? Eh(Dh["*"]) : a ? Eh(Dh[a]) : void 0
    }
    var Gh = ["b", "f", "x", "j", "i"],
        Hh = ["x"];
    Hh.unshift("f");
    Hh.push("j");
    var Ih = ["i"],
        Jh = ["f", "x"],
        Kh = ["f", "i"],
        Lh = {},
        Mh = (Lh.h = Hh, Lh),
        Nh = x(function(a, b, c) {
            (c = Fh(b) || Eh(c)) || (c = Eh(b ? Mh[b] : Gh));
            b = F(function(d, e) {
                var f = e.check,
                    g = e.id;
                (f = f(a)) && d.push([g, f]);
                return d
            }, [], c || []);
            b.length || jf();
            return b
        }, Da),
        Oh = C(Q.reject, Q, hf()),
        Ph = {},
        Qh = (Ph.h = ef, Ph),
        Rh = W("g.sen", function(a, b, c) {
                var d = Nh(a, b);
                c = c ? lh(a, b, c) : [];
                var e = Qh[b],
                    f = e ? e(a, d, c) : ef(a, d, c);
                return function() {
                    var g = q(Ha(arguments)),
                        h = g.next().value;
                    g = ba(g);
                    h = M(h, {
                        N: M(void 0 === h.N ? {} : h.N, {
                            ea: [b]
                        })
                    });
                    return f.apply(null, [h].concat(g))
                }
            },
            Oh);

    function Sh(a, b) {
        return function(c) {
            var d = c[a];
            d ? (d.yf = !0, d.xf(b)) : c[a] = {
                promise: Q.resolve(b),
                yf: !0,
                xf: u
            }
        }
    }
    var Th = pa(function(a, b) {
            if (!b[a]) {
                var c, d = new Q(function(e) {
                    c = e
                });
                b[a] = {
                    xf: c,
                    promise: d,
                    yf: !1
                }
            }
            return b[a].promise
        }),
        Uh = x(G(Ce, ta));

    function Vh(a, b, c) {
        b = N(b);
        var d = zd(a);
        c = M({
            Ng: d(Ad)
        }, c);
        d = {};
        var e = {};
        Fe(a, (e.counterKey = b, e.name = "counterSettings", e.data = (d.settings = c, d), e));
        return Uh()(Sh(b, c))
    }

    function Wh(a, b) {
        var c = N(a);
        return Uh()(Th(c)).then(b)
    }

    function Xh(a, b) {
        function c(d, e, f) {
            var g = {},
                h = {};
            Fe(a, (h.name = "log", h.counterKey = b, h.data = (g.args = K(e) ? e : [e], g.type = d, g.variables = f, g), h))
        }
        return {
            log: E("log", c),
            error: E("error", c),
            warn: E("warn", c)
        }
    }
    var Yh = x(W("dc.init", function(a, b) {
        return b && Zd(Tb(b.split(":")[0])) ? {
            log: u,
            warn: u,
            error: u
        } : Xh(a, b)
    }), Da);

    function Zh(a, b, c, d) {
        Yh(a, b).log(c, d)
    }

    function $h(a, b, c, d, e) {
        return D([a, N(b), e ? [c + ".p", e] : c, d], Zh)
    }

    function ai(a, b, c) {
        c = c || "as";
        if (a.postMessage && !a.attachEvent) {
            var d = ud(a),
                e = "__ym__promise_" + Xd(a) + "_" + Xd(a),
                f = u;
            f = d.F(a, ["message"], V(a, c, function(g) {
                try {
                    var h = g.data
                } catch (k) {
                    return
                }
                h === e && (f(), g.stopPropagation && g.stopPropagation(), b())
            }));
            a.postMessage(e, "*")
        } else X(a, b, 0, c)
    }
    var bi = W("h.p", function(a, b) {
        var c = Rh(a, "h", b),
            d = b.rc || "" + U(a).href,
            e = b.Tg || a.document.referrer,
            f = {},
            g = {};
        f = {
            K: Le((f.pv = 1, f)),
            H: (g["page-url"] = d, g["page-ref"] = e, g),
            M: {}
        };
        f.M.O = b.O;
        f.M.Be = b.Be;
        b.jd && f.H && (f.H.nohit = "1");
        return c(f, b).then(function(h) {
            if (h) {
                if (!b.jd) {
                    var k = {};
                    $h(a, b, "h", (k.id = b.id, k.url = d, k.ref = e, k), b.O)()
                }
                ai(a, D([a, b, h], Vh))
            }
        })["catch"](V(a, "h.g.s"))
    });

    function ci(a, b, c) {
        try {
            if (A(b)) {
                var d = q(Ha(arguments));
                d.next();
                d.next();
                d.next();
                var e = ba(d);
                b.apply(Ra(c) ? null : c, e)
            }
        } catch (f) {
            qg(a, E(f, md), 0)
        }
    }
    var di = ["yandex_metrika_callback" + na.callbackPostfix, "yandex_metrika_callbacks" + na.callbackPostfix],
        ei = W("cb.i", function(a) {
            var b = q(di),
                c = b.next().value,
                d = b.next().value;
            if (A(a[c])) a[c]();
            "object" === typeof a[d] && L(function(e, f) {
                a[d][f] = null;
                ci(a, e)
            }, a[d]);
            L(function(e) {
                try {
                    delete a[e]
                } catch (f) {
                    a[e] = void 0
                }
            }, di)
        });

    function fi(a, b) {
        var c = O(a).C("counters", {}),
            d = N(b);
        return c[d]
    }

    function gi(a, b, c, d) {
        var e = uf[c];
        return e ? function() {
            var f = Ha(arguments);
            f = d.apply(null, ca(f));
            var g = O(a);
            g.sa("mt", {});
            g = g.C("mt");
            var h = g[e];
            g[e] = h ? h + 1 : 1;
            return f
        } : d
    }
    var hi = [],
        ii = [],
        ji = [],
        ki = [],
        li = [],
        mi = [],
        ni = /^[a-zA-Z0-9'!#$%&*+-/=?^_`{|}~]+$/;

    function oi(a) {
        var b = a.length;
        return 1 > b || 64 < b ? !1 : Rb(function(c) {
            var d = c.length;
            if (1 > d) c = !1;
            else if ('"' === c[0] && '"' === c[d - 1] && 2 < d) a: {
                for (d = 1; d + 2 < c.length; d += 1) {
                    var e = c.charCodeAt(d);
                    if (32 > e || 34 === e || 126 < e) {
                        c = !1;
                        break a
                    }
                    if (92 === e) {
                        if (d + 2 === c.length || 32 > c.charCodeAt(d + 1)) {
                            c = !1;
                            break a
                        }
                        d += 1
                    }
                }
                c = !0
            }
            else c = ni.test(c) ? !0 : !1;
            return c
        }, a.split("."))
    }

    function pi(a) {
        var b = a.length;
        return 5 > b || 100 < b ? void 0 : a
    }

    function qi(a) {
        var b = ke(a).replace(/^\++/gm, "").toLowerCase(),
            c = b.lastIndexOf("@");
        if (-1 === c) return pi(b);
        a = b.substr(0, c);
        c = b.substr(c + 1);
        if (!c || !oi(a)) return pi(b);
        c = c.replace("googlemail.com", "gmail.com");
        de(c) && (c = "yandex.ru");
        "yandex.ru" === c ? a = a.replace(Ia, "-") : "gmail.com" === c && (a = a.replace(Ia, ""));
        b = La(a, "+"); - 1 !== b && (a = a.slice(0, b));
        return pi(a + "@" + c)
    }
    var ri = le(/[^\d+()]/g),
        si = /[a-z\u0430-\u044f\u0451,.]/gi;

    function ti(a, b) {
        var c = ne(b),
            d = c.length;
        if (!(si.test(b) || b.length - d > d || 10 > d || 16 < d)) {
            d = c[0];
            var e = b[1];
            if ("+" !== b[0] || e === d) return d = ri(b), 10 > c.length || 13 < c.length || d.startsWith("+8") ? ke(b) : "8" === d[0] ? "7" + c.slice(1) : "+" === d[0] || Sb(a, +d[0]) ? c : "7" + c
        }
    }
    var ui = x(function(a) {
        return !!I(a, "crypto.subtle.digest") && !!I(a, "TextEncoder") && !!I(a, "FileReader") && !!I(a, "Blob")
    });

    function vi(a, b) {
        return new Q(function(c, d) {
            var e = (new a.TextEncoder).encode(b);
            a.crypto.subtle.digest("SHA-256", e).then(function(f) {
                f = new a.Blob([f], {
                    type: "application/octet-binary"
                });
                var g = new a.FileReader;
                g.onload = function(h) {
                    h = I(h, "target.result") || "";
                    var k = La(h, ","); - 1 !== k ? c(h.substring(k + 1)) : d(S("fpm.i"))
                };
                g.readAsDataURL(f)
            }, d)
        })
    }
    var wi = ["yandex_cid", "yandex_public_id"];

    function xi(a, b, c) {
        c = void 0 === c ? 0 : c;
        b = bc(b);
        b = F(function(d, e) {
            var f = q(e),
                g = f.next().value;
            f = f.next().value;
            var h = Sa(f);
            if (!h && (Sb(a, f) && (f = "" + f), !y(f))) return d;
            if (h) f = xi(a, f, c + 1);
            else if (!c && J(g, wi)) f = Q.resolve(f);
            else {
                "phone_number" === g ? f = ti(a, f) : "email" === g && (f = qi(f));
                if (!f) return d;
                f = vi(a, f)
            }
            d.push(f.then(function(k) {
                return [g, k]
            }));
            return d
        }, [], b);
        return Q.all(b)
    }
    var yi = W("fpm", function(a, b) {
        if (!ge(a)) return u;
        var c = N(b);
        if (!ui(a)) return Zh(a, c, "ns"), u;
        var d = fi(a, b);
        return d ? function(e) {
            return (new Q(function(f, g) {
                return Sa(e) ? cc(e).length ? f(xi(a, e).then(function(h) {
                    if (h && h.length) {
                        var k = {},
                            l = {};
                        d.params((l.__ym = (k.fpp = h, k), l))
                    }
                }, u)) : g(hf("fpm.l")) : g(hf("fpm.o"))
            }))["catch"](V(a, "fpm.en"))
        } : u
    });

    function zi(a, b) {
        return F(function(c, d) {
            var e = q(d),
                f = e.next().value,
                g = e.next().value;
            e = g;
            g = Sa(g);
            if (!g && (Sb(a, e) && (e = "" + e), !y(e))) return c;
            e = g ? zi(a, e) : e;
            eb(e) && c.push([f, e]);
            return c
        }, [], bc(b))
    }

    function Ai(a, b) {
        return function(c) {
            var d = fi(a, b);
            if (d) {
                var e = Yh(a, N(b));
                if (Sa(c))
                    if (eb(cc(c))) {
                        if ((c = zi(a, c)) && eb(c)) {
                            e = {};
                            var f = {};
                            d.params((f.__ym = (e.fpmh = c, e), f))
                        }
                    } else e.log("fpeo");
                else e.log("fpno")
            }
        }
    }

    function Bi(a) {
        a = O(a);
        var b = a.C("dsjf") || ta({});
        a.sa("dsjf", b);
        return b
    }

    function Ci(a, b, c) {
        Bi(a)(function(d) {
            d[b] = M(d[b] || {}, c)
        })
    }

    function Di(a, b) {
        Bi(a)(function(c) {
            delete c[b]
        })
    }

    function Ei(a, b) {
        return function(c) {
            Ci(a, b, c)
        }
    }
    var Fi = pa(function(a, b) {
            var c = {};
            Bi(a)(function(d) {
                c = d[b] || {}
            });
            return c
        }),
        Gi = W("c.c.cc", function(a) {
            var b = O(a),
                c = G(Fi(a), function(d) {
                    var e = {};
                    e = (e.clickmap = !!d.clickmap, e);
                    return M({}, d, e)
                });
            return V(a, "g.c.cc", G(C(b.C, b, "counters", {}), cc, Kb(c)))
        }),
        Hi = W("gt.c.rs", function(a, b) {
            var c = N(b),
                d = b.id,
                e = b.ca,
                f = b.vg,
                g = b.we,
                h = D([a, c], Di),
                k = {};
            Ci(a, c, (k.id = d, k.type = +e, k.clickmap = f, k.trackHash = !!g, k));
            return h
        }),
        Ii = {};

    function Ji(a, b) {
        var c = N(a),
            d = I(b, "__ym.turbo_page"),
            e = I(b, "__ym.turbo_page_id");
        Ii[c] || (Ii[c] = {});
        if (d || e) Ii[c].Uh = d, Ii[c].Vh = e
    }

    function Ki(a) {
        a = N(a);
        return Ii[a] && Ii[a].Uh
    }
    var Li = x(De);

    function Mi(a, b) {
        return {
            R: function(c, d) {
                var e = (c.M || {}).O,
                    f = void 0 === c.N ? {} : c.N;
                if (e && (Ji(b, e), !f.ba && c.K && c.H)) {
                    var g = yf(a, e),
                        h = Li(a),
                        k = c.K.C("pv");
                    if (g && !c.H.nohit) {
                        var l = {},
                            m = {};
                        Fe(a, (m.counterKey = N(b), m.name = "params", m.data = (l.val = e, l), m));
                        k ? encodeURIComponent(g).length > Nc.cg ? h.push([c.K, e]) : c.H["site-info"] = g : (f.ba = g, c.N = f, c.Jc || (c.Jc = {}), c.Jc.th = !0)
                    }
                }
                d()
            },
            ta: function(c, d) {
                var e = Li(a),
                    f = fi(a, b),
                    g = f && f.params;
                g && (f = nb(G(xb, ra(c.K)), e), L(function(h) {
                    var k = q(h);
                    k.next();
                    k = k.next().value;
                    g(k);
                    h =
                        wb(a)(h, e);
                    e.splice(h, 1)
                }, f));
                d()
            }
        }
    }

    function Ni(a, b, c, d, e) {
        var f = D([a, d, e], ci);
        return c.then(f, function(g) {
            f();
            mf(a, b, g)
        })
    }
    var Oi = x(Ce, N);

    function Pi(a) {
        var b = u,
            c = null,
            d = a.length;
        if (0 !== a.length && a[0]) {
            var e = a.slice(-1)[0];
            A(e) && (b = e, d = a.length + -1);
            var f = a.slice(-2)[0];
            A(f) && (b = f, c = e, d = a.length + -2);
            d = a.slice(0, d);
            return {
                Bg: c,
                $b: b,
                O: 1 === d.length ? a[0] : fb(d)
            }
        }
    }
    var Qi = W("pa.int", function(a, b) {
        var c = {};
        return c.params = function() {
            var d = Ha(arguments),
                e = Pi(d);
            if (!e) return null;
            d = e.Bg;
            var f = e.O;
            e = e.$b;
            if (!Sa(f) && !K(f)) return null;
            var g = Rh(a, "1", b),
                h = Oi(b).url,
                k = !$d(b),
                l = "pa",
                m = {};
            m = (m.id = b.id, m);
            var p = f,
                r = "";
            if (r = I(f, "__ym.user_id")) l = "pau", m.uid = r;
            J("__ymu", cc(f)) && (l = "paup");
            p.__ym && (p = M({}, f), p.__ym = F(function(t, w) {
                var z = I(f, "__ym." + w);
                z && (t[w] = z);
                return t
            }, {}, qf), cc(p.__ym).length || delete p.__ym, k = !!cc(p).length);
            p = r ? void 0 : JSON.stringify(p);
            l = $h(a, b, l, m,
                p);
            m = {};
            p = {};
            g = g({
                M: {
                    O: f
                },
                K: Le((m.pa = 1, m.ar = 1, m)),
                H: (p["page-url"] = h || U(a).href, p)
            }, b).then(k ? l : u);
            return Ni(a, "p.s", g, e, d)
        }, c
    });

    function Ri(a, b, c, d, e) {
        return (new Q(function(f, g) {
            var h = cc(c),
                k = G(d.resolve || v, sa(f)),
                l = G(d.reject || v, sa(g));
            d.resolve = k;
            d.reject = l;
            L(function(m) {
                d.xe.push(+m);
                var p = c[m],
                    r = X(a, E(hf(), l), 5100, "is.m"),
                    t = {};
                b(p.window, M(e, (t.toCounter = Vb(m), t)), function(w, z) {
                    rg(a, r);
                    d.Lf.push(m);
                    d.resolve && d.resolve(z)
                })
            }, h)
        }))["catch"](V(a, "if.b"))
    }

    function Si(a, b, c) {
        b = nb(function(d) {
            return !J(c.info.counterId, d.xe)
        }, b);
        L(function(d) {
            if (c.info.counterId) {
                var e = {};
                a((e[c.info.counterId] = c, e), d, d.data)
            }
        }, b)
    }

    function Ti(a, b) {
        var c = Lg(a, b),
            d = [],
            e = [];
        if (!c) return null;
        var f = D([a, c.ke], Ri),
            g = E(f, Si);
        c.Z.F(["initToParent"], function(h) {
            h = q(h);
            h.next();
            h = h.next().value;
            g(d, c.children[h.counterId])
        }).F(["parentConnect"], function(h) {
            h = q(h);
            h.next();
            h = h.next().value;
            g(e, c.Fa[h.counterId])
        });
        return {
            Z: c.Z,
            Hi: function(h, k) {
                return new Q(function(l, m) {
                    c.ke(h, k, function(p, r) {
                        l([p, r])
                    });
                    X(a, E(hf(), m), 5100, "is.o")
                })
            },
            If: function(h) {
                var k = {
                    Lf: [],
                    xe: [],
                    data: h
                };
                d.push(k);
                return f(c.children, k, h)
            },
            Jf: function(h) {
                var k = {
                    Lf: [],
                    xe: [],
                    data: h
                };
                e.push(k);
                return f(c.Fa, k, h)
            }
        }
    }
    var Ui = x(Ti, G(Da, N));

    function Vi(a, b) {
        if (!J(b, L(db("ymetrikaEvent.type"), a))) {
            var c = {},
                d = {};
            a.push((d.ymetrikaEvent = (c.type = b, c), d))
        }
    }

    function Wi(a) {
        a = O(a);
        var b = a.C("dataLayer", []);
        a.D("dataLayer", b);
        return b
    }

    function Xi(a, b, c, d) {
        c = void 0 === c ? u : c;
        d = void 0 === d ? !1 : d;
        var e = Cg(a);
        if (b && A(b.push)) {
            var f = b.push;
            b.push = function() {
                var g = Ha(arguments),
                    h = q(g).next().value;
                d && e.$(h);
                g = f.apply(b, g);
                d || e.$(h);
                return g
            };
            a = {
                qa: e,
                unsubscribe: function() {
                    b.push = f
                }
            };
            c(a);
            L(e.$, b);
            return a
        }
    }

    function Yi(a, b) {
        var c = I(b, "ymetrikaEvent");
        c && a.$(I(c, "type"), c)
    }

    function Zi(a, b, c) {
        c = void 0 === c ? v : c;
        var d = Dg(a);
        c(d);
        var e = E(d, Yi);
        Xi(a, b, function(f) {
            f.qa.F(e)
        });
        return d
    }

    function $i(a, b, c, d) {
        var e = fi(a, c);
        if (e) {
            a = d.data;
            c = "" + c.id;
            var f = d.sended || [];
            d.sended || (d.sended = f);
            J(c, f) || !e.params || d.counter && "" + d.counter !== c || (e.params(a), f.push(c), d.parent && (d = {}, b.Jf((d.type = "params", d.data = a, d))))
        }
    }
    var aj = W("y.p", function(a, b) {
        var c = Ti(a, b);
        if (c) {
            var d = Wi(a),
                e = D([a, c, b], $i);
            Zi(a, d, function(f) {
                f.F(["params"], e)
            });
            c.Z.F(["params"], G(db("1"), e))
        }
    });

    function bj(a, b, c, d) {
        var e = U(a),
            f = e.hostname;
        e = e.href;
        if (b = Oi(b).url) a = qh(a, b), f = a.hostname, e = a.href;
        return [d + "://" + f + "/" + c, e || ""]
    }
    var cj = {
            zi: Xa(/[/&=?#]/)
        },
        dj = W("go.in", function(a, b, c, d) {
            c = void 0 === c ? "goal" : c;
            var e = {};
            return e.reachGoal = function(f, g, h, k) {
                if (!f || cj[c] && cj[c](f)) return null;
                var l = g,
                    m = h || u;
                A(g) && (m = g, l = void 0, k = h);
                g = {};
                var p = $h(a, b, "gr", (g.id = b.id, g.goal = f, g), l),
                    r = "goal" === c;
                g = Rh(a, "g", b);
                var t = q(bj(a, b, f, c));
                h = t.next().value;
                t = t.next().value;
                var w = {},
                    z = {};
                g = g({
                    M: {
                        O: l
                    },
                    K: Le((w.ar = 1, w)),
                    H: (z["page-url"] = h, z["page-ref"] = t, z)
                }, b).then(function() {
                    r && p();
                    var P = {},
                        R = {};
                    Fe(a, (R.counterKey = N(b), R.name = "event", R.data = (P.schema =
                        c, P.name = f, P.params = l, P), R));
                    d && d()
                });
                return Ni(a, "g.s", g, m, k)
            }, e
        }),
        ej = W("guid.int", function(a, b) {
            var c = {};
            return c.getClientID = function(d) {
                var e = pg(a, b);
                d && ci(a, d, null, e);
                return e
            }, c
        }),
        fj;

    function gj(a) {
        return (a = U(a).hash.split("#")[1]) ? a.split("?")[0] : ""
    }

    function hj(a, b) {
        var c = gj(a);
        fj = sg(a, function() {
            var d = gj(a);
            d !== c && (b(), c = d)
        });
        return C(tg, null, a, fj)
    }

    function ij(a, b, c, d) {
        var e = b.ca,
            f = b.Ce,
            g = b.rc,
            h = O(a),
            k = {};
        k = Le((k.wh = 1, k.pv = 1, k));
        var l = I(d, "isTrusted");
        d && !Ra(l) && k.D("ite", jb(l));
        Oc(e) && a.Ya && a.Ya.Direct && k.D("ad", "1");
        f && k.D("ut", "1");
        e = h.C("lastReferrer");
        d = U(a).href;
        f = {};
        g = {
            H: (f["page-url"] = g || d, f["page-ref"] = e, f),
            K: k
        };
        c(g, b)["catch"](V(a, "g.s"));
        h.D("lastReferrer", d)
    }
    var jj = W("th.e", function(a, b) {
        function c() {
            f || (h = H(a, "onhashchange") ? ud(a).F(a, ["hashchange"], g) : hj(a, g))
        }
        var d = Rh(a, "t", b),
            e = Ei(a, N(b)),
            f = !1,
            g = V(a, "h.h.ch", C(ij, null, a, b, d)),
            h = u;
        b.we && (c(), f = !0);
        d = {};
        return d.trackHash = V(a, "tr.hs.h", function(k) {
            k ? c() : h();
            f = !!k;
            k = {};
            e((k.trackHash = f, k))
        }), d.u = h, d
    });

    function kj(a) {
        var b = null;
        try {
            b = a.target || a.srcElement
        } catch (c) {}
        if (b) {
            3 === b.nodeType && (b = b.parentNode);
            for (a = b && b.nodeName && ("" + b.nodeName).toLowerCase(); I(b, "parentNode.nodeName") && ("a" !== a && "area" !== a || !b.href && !b.getAttribute("xlink:href"));) a = (b = b.parentNode) && b.nodeName && ("" + b.nodeName).toLowerCase();
            return b.href ? b : null
        }
        return null
    }

    function lj(a, b) {
        var c = {};
        c = (c.string = !0, c.object = !0, c["boolean"] = b, c)[typeof b] || !1;
        var d = {};
        a((d.trackLinks = c, d))
    }

    function mj(a, b, c) {
        var d = Le();
        void 0 !== c.yc && d.D("ite", jb(c.yc));
        c.wc && d.D("dl", 1);
        c.ob && d.D("ln", 1);
        var e = c.Yf || {},
            f = {};
        d = {
            K: d,
            M: {
                title: e.title || c.title,
                Ac: !!c.Ac,
                O: e.params
            },
            H: (f["page-url"] = c.url, f["page-ref"] = b.rc || U(a).href, f)
        };
        f = "Link";
        c.wc ? f = c.ob ? "Ext link - File" : "File" : c.ob && (f = "Ext link");
        var g = {},
            h = {};
        Fe(a, (h.counterKey = N(b), h.name = "event", h.data = (g.schema = "Link click", g.name = (c.ob ? "external" : "internal") + " url: " + c.url, g), h));
        g = {};
        b = c.sender(d, b).then($h(a, b, "lcl", (g.prefix = f, g.id = b.id,
            g.url = c.url, g), c.Yf));
        Ni(a, "cl.p.s", b, e.callback || u, e.ctx)
    }

    function nj(a, b) {
        if (a.Wh()) {
            var c = kj(b);
            if (c && !Of("ym-disable-tracklink", c)) {
                var d = a.l,
                    e = a.zg,
                    f = a.fb,
                    g = a.sender,
                    h = a.Mg,
                    k = f.rc,
                    l = c.href;
                var m = ke(c.innerHTML && c.innerHTML.replace(/<\/?[^>]+>/gi, ""));
                m || (m = (m = c.querySelector("img")) ? ke(m.getAttribute("title") || m.getAttribute("alt")) : "");
                m = l === m ? "" : m;
                var p = I(b, "isTrusted");
                if (Of("ym-external-link", c)) mj(d, f, {
                    url: l,
                    ob: !0,
                    title: m,
                    yc: p,
                    sender: g
                });
                else {
                    k = k ? qh(d, k).hostname : U(d).hostname;
                    h = RegExp("\\.(" + T("|", L(Pa, h)) + ")$", "i");
                    var r = c.protocol + "//" + c.hostname +
                        c.pathname;
                    h = sf.test(r) || sf.test(l) || h.test(l) || h.test(r);
                    c = c.hostname;
                    ee(k) === ee(c) ? h ? mj(d, f, {
                        url: l,
                        wc: !0,
                        yc: p,
                        title: m,
                        sender: g
                    }) : m && e.D("il", ke(m).slice(0, 100)) : l && rf.test(l) || mj(d, f, {
                        url: l,
                        Ac: !0,
                        ob: !0,
                        wc: h,
                        yc: p,
                        title: m,
                        sender: g
                    })
                }
            }
        }
    }
    var oj = pa(function(a, b) {
            y(b) ? a.push(b) : L(G(v, Wa("push", a)), b)
        }),
        pj = Yd("retryReqs", function(a) {
            var b = Ff(a),
                c = b.C("retryReqs", {}),
                d = Ed(a)(Ad);
            L(function(e) {
                var f = q(e);
                e = f.next().value;
                f = f.next().value;
                (!f || !f.time || f.time + 864E5 < d) && delete c[e]
            }, bc(c));
            b.D("retryReqs", c);
            return c
        }, !0);

    function qj(a) {
        var b = pj(a);
        Ff(a).D("retryReqs", b)
    }

    function rj(a, b) {
        var c = pj(a);
        b.K && !Qa(c) && b.M && (delete c[b.M.Qb], qj(a))
    }

    function sj(a, b) {
        return {
            R: function(c, d) {
                var e = c.K,
                    f = c.Ia,
                    g = c.H,
                    h = void 0 === c.N ? {} : c.N;
                if (e && g) {
                    var k = Ed(a);
                    e.Tb("rqnl", 1);
                    for (var l = pj(a), m = 1; l[m];) m += 1;
                    c.M || (c.M = {});
                    c.M.Qb = m;
                    var p = {};
                    l[m] = (p.protocol = Nc.La, p.host = Lc, p.resource = c.ma.ra, p.postParams = h.ba, p.time = k(Ad), p.counterType = b.ca, p.params = g, p.browserInfo = e.l(), p.counterId = b.id, p.ghid = lg(a), p);
                    f && (l[m].telemetry = f.l());
                    qj(a)
                }
                d()
            },
            ta: function(c, d) {
                rj(a, c);
                d()
            }
        }
    }
    var tj = G(Ma, ra(0)),
        uj = qa(tj),
        vj = [uj("watch"), uj("clmap")],
        wj = W("g.r", function(a) {
            var b = Ed(a),
                c = pj(a),
                d = b(Ad),
                e = lg(a);
            return F(function(f, g) {
                var h = q(g),
                    k = h.next().value;
                (h = h.next().value) && Ob(ta(h.resource), vj) && !h.d && h.ghid && h.ghid !== e && h.time && 500 < d - h.time && h.time + 864E5 > d && 2 >= h.browserInfo.rqnl && (h.d = 1, k = {
                    protocol: h.protocol,
                    host: h.host,
                    ra: h.resource,
                    Eh: h.postParams,
                    O: h.params,
                    pg: h.browserInfo,
                    xi: h.ghid,
                    time: h.time,
                    Qb: Vb(k),
                    yg: h.counterId,
                    ca: h.counterType
                }, h.telemetry && (k.Ia = h.telemetry), f.push(k));
                return f
            }, [], bc(c))
        });

    function xj(a, b, c) {
        function d() {
            t || (r = !0, w = !1, t = !0, f())
        }

        function e() {
            m = !0;
            k(!1);
            b()
        }

        function f() {
            rg(a, l);
            if (m) k(!1);
            else {
                var ma = Math.max(0, c - (w ? z : z + p(Ad) - P));
                ma ? l = X(a, e, ma, "u.t.d.c") : e()
            }
        }

        function g() {
            w = r = t = !0;
            z += p(Ad) - P;
            P = p(Ad);
            f()
        }

        function h() {
            r || t || (z = 0);
            P = p(Ad);
            r = t = !0;
            w = !1;
            f()
        }

        function k(ma) {
            ma = ma ? R.F : R.Xb;
            ma(a, ["blur"], g);
            ma(a, ["focus"], h);
            ma(a.document, ["click", "mousemove", "keydown", "scroll"], d)
        }
        var l = 0,
            m = !1;
        if (uc(a)) return l = X(a, b, c, "u.t.d"), D([a, l], rg);
        var p = Ed(a),
            r = !1,
            t = !1,
            w = !0,
            z = 0,
            P = p(Ad),
            R = ud(a);
        k(!0);
        f();
        return function() {
            rg(a, l);
            k(!1)
        }
    }
    var yj = W("nb.p", function(a, b) {
        function c(z) {
            h() || (z = "number" === typeof z ? z : 15E3, w = xj(a, d(!1), z), l())
        }

        function d(z) {
            return function(P) {
                var R = {};
                P = void 0 === P ? (R.ctx = {}, R.callback = u, R) : P;
                if (z || !r && !g.Jd) {
                    r = !0;
                    l();
                    w && w();
                    var ma = m(Ad);
                    R = (Vb(g.C("lastHit")) || 0) < ma - 18E5;
                    var Cc = .1 > Math.random();
                    g.D("lastHit", ma);
                    ma = {};
                    ma = Le((ma.nb = 1, ma.cl = t, ma.ar = 1, ma));
                    var Hd = Oi(b),
                        Ze = {};
                    ma = {
                        H: (Ze["page-url"] = Hd.url || U(a).href, Ze),
                        K: ma,
                        M: {
                            force: z
                        }
                    };
                    Hd = Yh(a, N(b)).warn;
                    !P.callback && P.ctx && Hd("nbnc");
                    (R = z || R || Cc) || (R = a.location.href,
                        Cc = a.document.referrer, R = !(R && Cc ? rh(R) === rh(Cc) : !R && !Cc));
                    if (R) return R = e(ma, b), Ni(a, "l.o.l", R, P.callback, P.ctx)
                }
                return null
            }
        }
        var e = Rh(a, "n", b),
            f = N(b),
            g = Gf(a, b.id),
            h = E(E(f, Fi(a)), G(Qe, db("accurateTrackBounce"))),
            k = {},
            l = E((k.accurateTrackBounce = !0, k), Ei(a, f)),
            m = Ed(a),
            p = m(Ad),
            r = !1,
            t = 0,
            w;
        Wh(b, function(z) {
            t = z.Ng - p
        });
        b.He && c(b.He);
        f = {};
        f = (f.notBounce = d(!0), f.u = w, f);
        f.accurateTrackBounce = c;
        return f
    });

    function zj(a) {
        return !(!wa("querySelectorAll", I(a, "Element.prototype.querySelectorAll")) || !a.document.querySelectorAll)
    }

    function Aj(a, b) {
        if (!b || !b.querySelectorAll) return [];
        var c = b.querySelectorAll(a);
        return c ? vb(c) : []
    }

    function Bj(a, b) {
        if (b.querySelector) return b.querySelector(a);
        var c = Aj(a, b);
        return c && c.length ? c[0] : null
    }

    function Cj(a, b) {
        var c = Pe([], a),
            d = c.shift();
        if (!d) return [];
        d = b.getElementsByTagName(d);
        return c.length ? Jb(E(c, Cj), vb(d)) : vb(d)
    }

    function Dj(a, b, c) {
        if (zj(a)) return vb(c.querySelectorAll(b));
        var d = Cj(b.split(" "), c);
        return nb(function(e, f) {
            return Aa(a)(e, d) === f
        }, d)
    }

    function Ej(a, b, c) {
        if (!(b && b.Element && b.Element.prototype && b.document && c)) return null;
        if (b.Element.prototype.closest && wa("closest", b.Element.prototype.closest) && c.closest) return c.closest(a);
        var d = Pf(b);
        if (d) {
            for (b = c; b && 1 === b.nodeType && !d.call(b, a);) b = b.parentElement || b.parentNode;
            return b && 1 === b.nodeType ? b : null
        }
        if (zj(b)) {
            for (a = vb((b.document || b.ownerDocument).querySelectorAll(a)); c && 1 === c.nodeType && -1 === Aa(b)(c, a);) c = c.parentElement || c.parentNode;
            return c && 1 === c.nodeType ? c : null
        }
        return null
    }

    function Fj(a, b) {
        return H(b, "isConnected") ? !b.isConnected : Ej("html", a, b) !== a.document.documentElement
    }

    function Gj(a, b) {
        var c = b,
            d = I(a, "document"),
            e = Yf(c);
        if (!c || !c.ownerDocument || "PARAM" === e || c === Qf(a) || c === d.documentElement) return {
            left: 0,
            top: 0
        };
        if (d = Vf(c)) return c = Uf(a), {
            left: Math.round(d.left + c.x),
            top: Math.round(d.top + c.y)
        };
        for (e = d = 0; c;) d += c.offsetLeft, e += c.offsetTop, c = c.offsetParent;
        return {
            left: d,
            top: e
        }
    }

    function Hj(a, b) {
        var c = I(a, "document");
        if (b === Qf(a) || b === c.documentElement) {
            c = Rf(a);
            var d = q(Tf(a)),
                e = d.next().value;
            d = d.next().value;
            return [Math.max(c.scrollWidth, e), Math.max(c.scrollHeight, d)]
        }
        return (c = Vf(b)) ? [c.width, c.height] : [b.offsetWidth, b.offsetHeight]
    }

    function Ij(a, b) {
        var c = Gj(a, b),
            d = c.left;
        c = c.top;
        var e = q(Hj(a, b)),
            f = e.next().value;
        e = e.next().value;
        return [d, c, f, e]
    }

    function Jj(a, b) {
        var c = I(a, "document");
        return b && b !== c.documentElement ? b === Qf(a) ? c.documentElement : I(b, "parentNode") : null
    }

    function Kj(a, b, c) {
        if (a = Jj(a, b)) {
            a = a.childNodes;
            for (var d = b && b.nodeName, e = 0, f = 0; f < a.length; f += 1)
                if (d === (a[f] && a[f].nodeName)) {
                    if (b === a[f]) return e;
                    c && a[f] === c || (e += 1)
                }
        }
        return 0
    }
    var Lj = x(function() {
        for (var a = 59, b = {}, c = 0; c < pf.length; c += 1) b[pf[c]] = String.fromCharCode(a), a += 1;
        return b
    });

    function Mj(a, b, c) {
        for (var d = "", e = Lj(), f = Yf(b) || "*"; b && b.parentNode && !J(f, ["BODY", "HTML"]);) d += e[f] || "*", d += Kj(a, b, c) || "", b = b.parentElement, f = Yf(b) || "*";
        return ke(d, 128)
    }

    function Nj(a) {
        var b = ["ym-disable-keys", "-metrika-nokeys"];
        b = K(b) ? b : [b];
        a = a || document;
        if (a.querySelectorAll) return b = T(", ", L(function(c) {
            return "." + c
        }, b)), vb(a.querySelectorAll(b));
        if (a.getElementsByClassName) return Jb(G(Wa("getElementsByClassName", a), vb), b);
        a = a.getElementsByTagName("*");
        b = "(" + T("|", b) + ")";
        return nb(E(b, Of), vb(a))
    }

    function Oj(a, b) {
        var c = Rf(a),
            d = Uf(a);
        return {
            x: b.pageX || b.clientX + d.x - (c.clientLeft || 0) || 0,
            y: b.pageY || b.clientY + d.y - (c.clientTop || 0) || 0
        }
    }

    function Pj(a) {
        var b = a.which;
        a = a.button;
        return b || void 0 === a ? b : 1 === a || 3 === a ? 1 : 2 === a ? 3 : 4 === a ? 2 : 0
    }

    function Qj(a, b) {
        var c = null;
        try {
            if (c = b.target || b.srcElement) !c.ownerDocument && c.documentElement ? c = c.documentElement : c.ownerDocument !== a.document && (c = null)
        } catch (d) {}
        return c
    }
    var Rj = pa(Of)("(ym-disable-clickmap|ym-clickmap-ignore)");

    function Sj(a, b, c, d, e) {
        if (H(a, "ymDisabledClickmap") || !b || !b.element) return !1;
        a = Yf(b.element);
        if (e && !e(b.element, a) || J(b.button, [2, 3]) && "A" !== a || Ob(ra(a), d)) return !1;
        d = b.element;
        if (b && c) {
            if (50 > b.time - c.time) return !1;
            e = Math.abs(c.position.x - b.position.x);
            a = Math.abs(c.position.y - b.position.y);
            b = b.time - c.time;
            if (c.element === d && 2 > e && 2 > a && 1E3 > b) return !1
        }
        for (; d;) {
            if (Rj(d)) return !1;
            d = d.parentElement
        }
        return !0
    }

    function Tj(a, b, c, d, e) {
        var f = "clmap/" + e.id,
            g = {};
        b = (g["page-url"] = b, g["pointer-click"] = c, g);
        f = {
            K: Le(),
            H: b,
            ma: {
                ra: f
            }
        };
        d(f, e)["catch"](V(a, "c.s.c"))
    }
    var Uj = W("clm.p", function(a, b) {
            if (ic(a)) return u;
            var c = Rh(a, "m", b),
                d = N(b),
                e = Ed(a),
                f = e(Ad),
                g = E(E(d, Fi(a)), G(Qe, db("clickmap"))),
                h, k = null;
            d = V(a, "clm.p.c", function(l) {
                var m = g();
                if (m) {
                    var p = O(a),
                        r = p.C("cls", {
                            ec: 0,
                            x: 0,
                            y: 0
                        });
                    p.D("cls", {
                        ec: r.ec + 1,
                        x: r.x + l.clientX,
                        y: r.y + l.clientY
                    });
                    p = "object" === typeof m ? m : {};
                    r = p.filter;
                    m = p.isTrackHash || !1;
                    var t = L(function(z) {
                        return ("" + z).toUpperCase()
                    }, p.ignoreTags || []);
                    B(h) && (h = p.quota || null);
                    var w = !!p.quota;
                    l = {
                        element: Qj(a, l),
                        position: Oj(a, l),
                        button: Pj(l),
                        time: e(Ad)
                    };
                    p =
                        U(a).href;
                    if (Sj(a, l, k, t, r)) {
                        if (w) {
                            if (!h) return;
                            --h
                        }
                        t = q(Hj(a, l.element));
                        r = t.next().value;
                        t = t.next().value;
                        w = Gj(a, l.element);
                        r = ["rn", Xd(a), "x", Math.floor(65535 * (l.position.x - w.left) / (r || 1)), "y", Math.floor(65535 * (l.position.y - w.top) / (t || 1)), "t", Math.floor((l.time - f) / 100), "p", Mj(a, l.element), "X", l.position.x, "Y", l.position.y];
                        r = T(":", r);
                        m && (r += ":wh:1");
                        Tj(a, p, r, c, b);
                        k = l
                    }
                }
            });
            return ud(a).F(I(a, "document"), ["click"], d)
        }),
        Vj = W("trigger.in", function(a, b) {
            b.Vf && ai(a, D([a, "yacounter" + b.id + "inited"], Wf), "t.i")
        });

    function Wj(a, b) {
        var c = {};
        a((c.clickmap = B(b) ? !0 : b, c))
    }
    var Xj = W("c.m.p", function(a, b) {
        var c = N(b),
            d = {};
        return d.clickmap = E(Ei(a, c), Wj), d
    });

    function Yj(a) {
        a = "" + a;
        for (var b = 2166136261, c = a.length, d = 0; d < c; d += 1) b ^= a.charCodeAt(d), b += (b << 1) + (b << 4) + (b << 7) + (b << 8) + (b << 24);
        return b >>> 0
    }
    var Zj = {},
        ak = {};
    Zj.p = 500;
    var bk = {
        i: "id",
        n: "name",
        h: "href",
        ty: "type"
    };
    ak.h = !0;
    ak.c = !0;
    var ck = {
        p: function(a, b, c) {
            if (b && Fj(a, b) && b._ymp) return b._ymp;
            a = Mj(a, b, c);
            b && (b._ymp = a);
            return a
        },
        c: function(a, b, c) {
            (a = ke(I(b, "textContent"))) && c && (c = c(b), c.length && Ob(G(db("textContent"), ke, ra(a)), c) && (a = ""));
            $f(b) && (a = ke(b.getAttribute && b.getAttribute("value") || a));
            return a
        }
    };

    function dk(a, b, c, d) {
        return F(function(e, f) {
            var g = null;
            f in bk ? g = b.getAttribute && b.getAttribute(bk[f]) : f in ck && (g = "p" === f ? ck[f](a, b, void 0) : "c" === f ? ck[f](a, b, d) : ck[f](a, b));
            g && (g = g.slice(0, Zj[f] || 100), e[f] = ak[f] ? "" + Yj(g) : g);
            return e
        }, {}, c)
    }
    var ek = E("form", Ej),
        fk = x(G(Da, qa(Wh)(db("settings.form_goals"))), Da);

    function gk(a, b, c, d) {
        return fk(a, b).then(G(D([$h(a, b, c, d), u], hb), Qe))
    }

    function hk(a, b, c, d, e, f) {
        var g = Aa(b)(e, d),
            h = -1 !== g;
        if (a || h) h && d.splice(g, 1), a = dk(b, e, ["i", "n", "p"]), a = "?" + Wd(a), d = {}, d = D([b, c, "fg", (d.id = c.id, d.query = a, d)], gk), Ra(f) ? f = void 0 : (e = {}, g = {}, f = (g.__ym = (e.ite = jb(f), e), g)), dj(b, c, "form", d).reachGoal(a, f)
    }

    function ik(a, b, c, d) {
        var e = I(d, "target");
        e && (d = I(d, "isTrusted"), (e = Ej("button,input", a, e)) && "submit" === e.type && (e = ek(a, e))) && (c.push(e), X(a, D([!1, a, b, c, e, d], hk), 300))
    }
    var jk = W("s.f.i", function(a, b) {
        var c = [],
            d = [],
            e = ud(a);
        c.push(e.F(a, ["click"], V(a, "s.f.c", D([a, b, d], ik))));
        c.push(e.F(a, ["submit"], V(a, "s.f.e", function(f) {
            var g = I(f, "target");
            f = I(f, "isTrusted");
            hk(!0, a, b, d, g, f)
        })));
        e = {};
        gk(a, b, "fgi", (e.id = b.id, e));
        return D([Re, c], L)
    });

    function kk(a, b, c, d) {
        return function() {
            if (fi(a, b)) {
                var e = Ha(arguments);
                return d.apply(null, ca(e))
            }
        }
    }
    var lk = "button," + T(",", L(function(a) {
            return 'input[type="' + a + '"]'
        }, ["button", "submit", "reset", "file"])) + ",a",
        mk = E(lk, Aj),
        nk = {},
        ok = (nk.A = "h", nk.BUTTON = "i", nk.DIV = "i", nk.INPUT = "ty", nk);

    function pk(a, b, c) {
        var d = I(c, "target");
        if (d) {
            var e = Ej(lk, a, d);
            e || (d = Ej("div", a, d)) && (Aj(lk + ",div", d).length || (e = d));
            if (e = (d = Yf(e)) && dk(a, e, ob(["p", ok[d], "c"]), mk)) {
                e = "?" + Wd(e);
                d = {};
                d = $h(a, b, "gbn", (d.id = b.id, d.query = e, d));
                c = I(c, "isTrusted");
                if (Ra(c)) c = void 0;
                else {
                    var f = {},
                        g = {};
                    c = (g.__ym = (f.ite = jb(c), f), g)
                }
                dj(a, b, "btn", d).reachGoal(e, c)
            }
        }
    }
    var qk = W("s.f.i", function(a, b) {
            return Wh(b, function(c) {
                if (I(c, "settings.button_goals")) {
                    c = ud(a).F(a, ["click"], V(a, "c.t.c", G(D([a, b], kk(a, b, "", pk)))));
                    var d = {};
                    $h(a, b, "gbi", (d.id = b.id, d))();
                    return c
                }
            })
        }),
        rk = {},
        sk = (rk.transaction_id = "id", rk.item_brand = "brand", rk.index = "position", rk.item_variant = "variant", rk.value = "revenue", rk.item_category = "category", rk.item_list_name = "list", rk),
        tk = {},
        uk = (tk.item_id = "id", tk.item_name = "name", tk.promotion_name = "coupon", tk),
        vk = {},
        wk = (vk.promotion_name = "name", vk),
        xk = {},
        yk = (xk.promotion_name = "name", xk.promotion_id = "id", xk.item_id = "product_id", xk.item_name = "product_name", xk),
        zk = "currencyCode add delete remove purchase checkout detail impressions click promoView promoClick".split(" "),
        Ak = {},
        Bk = (Ak.view_item = {
            event: "detail",
            Aa: uk,
            Ja: "products"
        }, Ak.add_to_cart = {
            event: "add",
            Aa: uk,
            Ja: "products"
        }, Ak.remove_from_cart = {
            event: "remove",
            Aa: uk,
            Ja: "products"
        }, Ak.begin_checkout = {
            event: "checkout",
            Aa: uk,
            Ja: "products"
        }, Ak.purchase = {
            event: "purchase",
            Aa: uk,
            Ja: "products"
        }, Ak.view_item_list = {
            event: "impressions",
            Aa: uk
        }, Ak.select_item = {
            event: "click",
            Ja: "products",
            Aa: uk
        }, Ak.view_promotion = {
            event: "promoView",
            Ja: "promotions",
            Aa: yk
        }, Ak.select_promotion = {
            event: "promoClick",
            Ja: "promotions",
            Aa: yk
        }, Ak);

    function Ck(a, b) {
        var c = {};
        L(function(d) {
            var e = a[d] || sk[d] || d; - 1 !== La(d, "item_category") ? (e = sk.item_category, c[e] = c[e] ? c[e] + ("/" + b[d]) : b[d]) : c[e] = b[d]
        }, cc(b));
        return c
    }

    function Dk(a, b) {
        var c = y(a) ? Bk[a] : a;
        if (c) {
            var d = c.event,
                e = c.Ja,
                f = void 0 === c.Ze ? "items" : c.Ze,
                g = b.purchase || b,
                h = g[f];
            if (h) {
                c = L(E(c.Aa, Ck), h);
                h = {};
                var k = {},
                    l = (k[d] = e ? (h[e] = c, h) : c, k);
                c = cc(g);
                e && 1 < c.length && (l[d].actionField = F(function(m, p) {
                    if (p === f) return m;
                    if ("currency" === p) return l.currencyCode = g.currency, m;
                    m[wk[p] || sk[p] || p] = g[p];
                    return m
                }, {}, c));
                return l
            }
        }
    }
    var Ek = W("dl.w", function(a, b, c) {
        function d() {
            var g = I(a, b);
            (e = K(g) && Xi(a, g, c)) || (f = X(a, d, 1E3, "ec.dl"))
        }
        var e, f = 0;
        d();
        return function() {
            return rg(a, f)
        }
    });

    function Fk(a) {
        var b = I(a, "ecommerce");
        if (Sa(b)) return a = nb(sb(zk), cc(b)), a = F(function(c, d) {
            c[d] = b[d];
            return c
        }, {}, a), 0 === cc(a).length ? void 0 : a
    }

    function Gk(a, b, c, d) {
        if (c) {
            var e = I(d, "ecommerce") || {};
            var f = I(d, "event") || "";
            e = Sa(e) && y(f) ? Dk(f, e) : void 0;
            if (!e) a: {
                e = d;!K(d) && Sb(a, eb(d)) && (e = Ha(e));
                if (K(e)) {
                    var g = q(e);
                    e = g.next().value;
                    f = g.next().value;
                    g = g.next().value;
                    if (y(f) && Sa(g) && "event" === e) {
                        e = Dk(f, g);
                        break a
                    }
                }
                e = void 0
            }
            if (d = e || Fk(d)) e = {}, Fe(a, (e.counterKey = b, e.name = "ecommerce", e.data = d, e)), a = {}, b = {}, c((b.__ym = (a.ecommerce = [d], a), b))
        }
    }

    function Hk(a, b, c) {
        var d;
        a = [Ek(a, b, function(e) {
            d = e;
            e.qa.F(c)
        }), function() {
            d && d.unsubscribe()
        }];
        return D([Re, a], L)
    }
    var Ik = W("p.e", function(a, b) {
        var c = fi(a, b);
        if (c) {
            var d = O(a);
            c = c.params;
            var e = V(a, "h.ee", D([a, N(b), c], Gk));
            return b.od ? (d.D("ecs", 0), Hk(a, b.od, e)) : Wh(b, function(f) {
                if ((f = I(f, "settings.ecommerce")) && y(f)) return d.D("ecs", 1), Hk(a, f, e)
            })
        }
    });

    function Jk(a, b) {
        var c = [],
            d = G(v, Wa("push", c));
        if (A()) {
            var e = (void 0)(b);
            (Ra(e) || e === a.NodeFilter.FILTER_ACCEPT) && d(b)
        } else d(b);
        if (b.childNodes && 0 < b.childNodes.length) {
            e = b.childNodes;
            for (var f = 0, g = e.length; f < g; f += 1) {
                var h = Jk(a, e[f]);
                L(d, h)
            }
        }
        return c
    }

    function Kk(a, b, c, d, e, f) {
        function g(k) {
            return A(d) ? d(k) ? a.NodeFilter.FILTER_ACCEPT : a.NodeFilter.FILTER_REJECT : a.NodeFilter.FILTER_ACCEPT
        }
        e = void 0 === e ? -1 : e;
        f = void 0 === f ? !1 : f;
        var h = g(b);
        if (A(c) && (f || h === a.NodeFilter.FILTER_ACCEPT) && (h && c(b), !Hf(b)))
            for (b = a.document.createTreeWalker(b, e, d ? {
                    acceptNode: g
                } : null, !1); b.nextNode() && !1 !== c(b.currentNode););
    }

    function Lk(a, b, c) {
        if (b) {
            var d = [];
            b && (a.document.documentElement.contains(b) ? Kk(a, b, Wa("push", d)) : Pe(d, Jk(a, b)));
            L(c, d)
        }
    }
    var Mk = x(function(a) {
            a = U(a);
            a = Vd(a.search.substring(1));
            return {
                id: Vb(a["_ym_status-check"] || ""),
                lang: a._ym_lang || "ru"
            }
        }),
        Nk = W("suid.int", function(a, b) {
            var c = {};
            return c.setUserID = function(d, e, f) {
                if (y(d) || Sb(a, d)) {
                    var g = fi(a, b);
                    d = fb(["__ym", "user_id", d]);
                    g.params(d, e || u, f)
                } else Yh(a, N(b)).error("wuid")
            }, c
        }),
        Ok = W("up.int", function(a, b) {
            var c = {};
            return c.userParams = V(a, "up.c", function(d, e, f) {
                    var g = fi(a, b),
                        h = Yh(a, N(b)).warn;
                    g ? Sa(d) ? (h = {}, d = (h.__ymu = d, h), (g = g.params) && g(d, e || u, f)) : h("wup") : h("nci")
                }),
                c
        }),
        Pk = /[\*\.\?\(\)]/g,
        Qk = x(function(a, b, c) {
            try {
                var d = c.replace("\\s", " ").replace(Pk, "");
                b = {};
                Yh(a, "").warn("nnw", (b.name = d, b))
            } catch (e) {}
        }, Da),
        Rk = W("r.nn", function(a) {
            Be(a) && Xi(a, ua, function(b) {
                b.qa.F(function(c) {
                    var d = q(c);
                    c = d.next().value;
                    d = d.next().value;
                    Qk(a, d, c);
                    ua.splice(100)
                })
            })
        }),
        Sk = W("e.a.p", function(a, b) {
            var c = fi(a, b);
            c = D([G(v, ta(!0)), ob(L(E(c, I), ["clickmap", "trackLinks", "accurateTrackBounce"]))], L);
            b.Hg && c();
            var d = {};
            return d.enableAll = c, d
        });

    function Tk(a, b) {
        return {
            R: function(c, d) {
                $g(c) ? d() : Wh(b, function(e) {
                    if (e = I(e, "settings.hittoken")) {
                        var f = {};
                        e = (f.hittoken = e, f);
                        c.H = M(c.H || {}, e)
                    }
                    d()
                })
            }
        }
    }
    var Uk = x(Ce, N),
        Vk = W("fpi", function(a) {
            var b = vd(a);
            if (b && !a.document.hidden) {
                var c = O(a).sa;
                c("fpe", 1);
                var d = ud(a).F(a, ["visibilitychange", "webkitvisibilitychange"], function() {
                    a.document.hidden && (c("fht", b.now()), d())
                })
            }
        }),
        Wk = x(function(a) {
            a = I(a, "console");
            var b = I(a, "log");
            b = va("log", b) ? C(b, a) : u;
            var c = I(a, "warn");
            c = va("warn", c) ? C(c, a) : b;
            var d = I(a, "error");
            a = va("error", d) ? C(d, a) : b;
            return {
                log: b,
                error: a,
                warn: c
            }
        });

    function Xk(a, b, c) {
        var d = !1,
            e = "";
        if (!Sa(b)) return Zh(c, "", "ecomeo"), d;
        var f = b.goods;
        switch (a) {
            case "detail":
            case "add":
            case "remove":
                K(f) && f.length ? (d = Rb(function(g) {
                    return Sa(g) && (y(g.id) || Sb(c, g.id) || y(g.name))
                }, f)) || (e = "ecomgi") : e = "ecomgei";
                break;
            case "purchase":
                Sb(c, b.id) || y(b.id) ? d = !0 : e = "ecompi"
        }
        Zh(c, "", e);
        return d
    }

    function Yk(a, b, c) {
        return function(d) {
            var e = fi(b, c);
            if (e && Xk(a, d, b) && (e = C(e.params, e), (d = Dk({
                    event: a,
                    Ja: "products",
                    Aa: uk,
                    Ze: "goods"
                }, d)) && e)) {
                var f = {},
                    g = {};
                e((g.__ym = (f.ecommerce = [d], f), g))
            }
        }
    }
    var Zk = E("add", Yk),
        $k = E("remove", Yk),
        al = E("detail", Yk),
        bl = E("purchase", Yk),
        cl = "FB_IAB FBAV OKApp GSA/ yandex yango uber EatsKit YKeyboard iOSAppUslugi YangoEats PassportSDK".split(" "),
        dl = x(function(a) {
            var b = zb(a);
            a = b.Xf;
            if (!b.ef) return !1;
            b = Wa("indexOf", a);
            b = Ob(G(b, ra(-1), Ea), cl);
            var c = /CFNetwork\/[0-9][0-9.]*.*Darwin\/[0-9][0-9.]*/.test(a),
                d = /YaBrowser\/[\d.]+/.test(a),
                e = /Mobile/.test(a);
            return b || c || d && e || !/Safari/.test(a) && e
        }),
        el = x(function(a) {
            var b = Bb(a);
            return b ? Na(b, "YangoEats") || oc(a) : !1
        }),
        fl = /\sYptp\/\d\.(\d+)\s/,
        gl = x(function(a) {
            var b;
            a: {
                if ((b = Bb(a)) && (b = fl.exec(b)) && 1 < b.length) {
                    b = Vb(b[1]);
                    break a
                }
                b = 0
            }
            return 50 <= b && 99 >= b || Hc(a) ? !1 : !Fc(a) || dl(a)
        });

    function hl(a, b, c, d, e, f, g, h) {
        var k = c.C(f);
        Ra(k) && (c.D(f, g), e(a, b, c, d), k = c.C(f, g));
        B(h) || h.Tb(f, "" + k);
        return k
    }
    var il = [],
        jl = !1,
        kl = !1;

    function ll(a) {
        if (il.length) {
            var b = il.shift();
            kl ? b() : X(a, b, 100)
        } else jl = !1
    }

    function ml(a, b, c, d) {
        c = void 0 === c ? 1 : c;
        d = void 0 === d ? Pd : d;
        kl = Infinity === c;
        return ta(function(e, f) {
            function g() {
                try {
                    var k = b(d(a, c));
                    h = h.concat(k)
                } catch (l) {
                    return e(l)
                }
                b(Kd);
                if (b(Gd)) return f(h), ll(a);
                kl ? (b(d(a, 1E4)), f(h), ll(a)) : X(a, g, 100)
            }
            var h = [];
            jl ? il.push(g) : (jl = !0, g())
        })
    }
    var nl = xa(String.prototype.repeat, "repeat");

    function ol(a, b) {
        for (var c = "", d = 0; d < b; d += 1) c += a;
        return c
    }
    var pl = nl ? function(a, b) {
            return nl.call(a, b)
        } : ol,
        ql = E(!0, function(a, b, c, d) {
            c = b.length && (c - d.length) / b.length;
            if (0 >= c) return d;
            b = pl(b, c);
            return a ? b + d : d + b
        }),
        rl = W("p.cd", function(a) {
            if (rc(a) || jc(a)) {
                var b = Ff(a);
                if (Ra(b.C("jn"))) {
                    b.D("jn", !1);
                    var c = a.chrome || lc(a) ? function() {} : /./;
                    a = Wk(a);
                    c.toString = function() {
                        b.D("jn", !0);
                        return "Yandex.Metrika counter is initialized"
                    };
                    a.log("%c%s", "color: inherit", c)
                }
            }
        });

    function sl(a, b) {
        return Array.prototype.sort.call(b, a)
    }
    var tl = x(function(a) {
            a = I(a, "navigator.plugins");
            return !!(a && eb(a) && Ob(G(db("name"), Xa(/Chrome PDF Viewer/)), a))
        }),
        ul = pa(function(a, b) {
            return O(b).C(a, null)
        }),
        vl = ["bl", "rt", "mf"],
        wl = {
            "*": "+",
            "-": "/",
            mi: "=",
            "+": "*",
            "/": "-",
            "=": "_"
        };

    function xl(a) {
        return a ? a.replace(/[+/=]/g, function(b) {
            return wl[b] || b
        }) : ""
    }

    function yl(a) {
        var b = "",
            c = 0;
        if (!a) return "";
        for (; a.length % 4;) a += "=";
        do {
            var d = Ma("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", a.charAt(c++)),
                e = Ma("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", a.charAt(c++)),
                f = Ma("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", a.charAt(c++)),
                g = Ma("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", a.charAt(c++));
            if (0 > d || 0 > e || 0 > f || 0 > g) return "";
            var h = d << 18 | e << 12 | f << 6 | g;
            d = h >> 16 & 255;
            e = h >> 8 &
                255;
            h &= 255;
            b = 64 === f ? b + String.fromCharCode(d) : 64 === g ? b + String.fromCharCode(d, e) : b + String.fromCharCode(d, e, h)
        } while (c < a.length);
        return b
    }

    function zl(a, b) {
        b = void 0 === b ? !1 : b;
        for (var c = a.length, d = c - c % 3, e = [], f = 0; f < d; f += 3) {
            var g = (a[f] << 16) + (a[f + 1] << 8) + a[f + 2];
            e.push("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" [g >> 18 & 63], "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" [g >> 12 & 63], "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" [g >> 6 & 63], "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" [g & 63])
        }
        switch (c - d) {
            case 1:
                c = a[d] << 4;
                e.push("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" [c >>
                    6 & 63
                ], "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" [c & 63], "=", "=");
                break;
            case 2:
                c = (a[d] << 10) + (a[d + 1] << 2), e.push("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" [c >> 12 & 63], "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" [c >> 6 & 63], "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" [c & 63], "=")
        }
        e = T("", e);
        return b ? xl(e) : e
    }

    function Al(a) {
        for (var b = "", c = 0; c < a.length;) {
            var d = a.charCodeAt(c);
            128 > d ? (b += String.fromCharCode(d), c++) : 191 < d && 224 > d ? (b += String.fromCharCode((d & 31) << 6 | a.charCodeAt(c + 1) & 63), c += 2) : (b += String.fromCharCode((d & 15) << 12 | (a.charCodeAt(c + 1) & 63) << 6 | a.charCodeAt(c + 2) & 63), c += 3)
        }
        return b
    }

    function Bl(a) {
        for (var b = [], c = 0; c < a.length; c++) {
            var d = a.charCodeAt(c);
            128 > d ? b.push(d) : (127 < d && 2048 > d ? b.push(d >> 6 | 192) : (b.push(d >> 12 | 224), b.push(d >> 6 & 63 | 128)), b.push(d & 63 | 128))
        }
        return b
    }

    function Cl(a) {
        return a ? zl(Bl(a)) : null
    }
    var Dl = x(function(a) {
        return Ab(/tizen/i, a)
    });

    function El(a) {
        if (!Dl(a)) return null;
        a = I(a, "webapis.adinfo.getTIFA");
        if (A(a)) try {
            return Cl(a())
        } catch (b) {}
        return null
    }

    function Fl(a) {
        if (!Dl(a)) return null;
        a = I(a, "tizen.systeminfo.getCapability");
        if (A(a)) try {
            return Cl(a("http://tizen.org/system/tizenid"))
        } catch (b) {}
        return null
    }

    function Gl(a) {
        if (!Dl(a)) return null;
        a = I(a, "tizen.systeminfo.getCapabilities");
        try {
            if (A(a)) return Cl(I(a(), "duid"))
        } catch (b) {}
        return null
    }
    var Hl = x(function(a) {
        return Ab(/webos|web0s/i, a)
    });

    function Il(a) {
        var b = I(a, "webOS.service.request");
        return A(b) ? new Q(function(c) {
            var d = {},
                e = {};
            b("luna://com.webos.service.sm", (e.method = "deviceid/getIDs", e.parameters = (d.idType = ["LGUDID"], d), e.onSuccess = function(f) {
                c(Cl(I(f, "idList.0.idValue")))
            }, e))
        }) : Q.resolve(null)
    }
    var Jl = x(function(a) {
        return A(I(a, "yandex.getSiteUid")) ? a.yandex.getSiteUid() : null
    });

    function Kl(a, b) {
        try {
            var c = b.localStorage.getItem(a);
            return c && zl(Bl(c))
        } catch (d) {}
        return null
    }
    var Ll = x(E("panoramaId", Kl)),
        Ml = x(function(a) {
            return Kl("pubcid.org", a) || Kl("_pubCommonId", a)
        }),
        Nl = x(E("_sharedid", Kl)),
        Ol = x(function(a, b) {
            if (b.Ua) return null;
            var c = ze(a, "").C("_ga");
            return c && zl(Bl(c))
        }, G(Da, N)),
        Pl = [
            ["domainLookupEnd", "domainLookupStart"],
            ["connectEnd", "connectStart"],
            ["responseStart", "requestStart"],
            ["responseEnd", "responseStart"],
            ["fetchStart", "navigationStart"],
            ["redirectEnd", "redirectStart"],
            [function(a, b) {
                return I(b, "redirectCount") || I(a, "navigation.redirectCount")
            }],
            ["domInteractive",
                "domLoading"
            ],
            ["domContentLoadedEventEnd", "domContentLoadedEventStart"],
            ["domComplete", "navigationStart"],
            ["loadEventStart", "navigationStart"],
            ["loadEventEnd", "loadEventStart"],
            ["domContentLoadedEventStart", "navigationStart"]
        ],
        Ql = [
            ["domainLookupEnd", "domainLookupStart"],
            ["connectEnd", "connectStart"],
            ["responseStart", "requestStart"],
            ["responseEnd", "responseStart"],
            ["fetchStart"],
            ["redirectEnd", "redirectStart"],
            ["redirectCount"],
            ["domInteractive", "responseEnd"],
            ["domContentLoadedEventEnd", "domContentLoadedEventStart"],
            ["domComplete"],
            ["loadEventStart"],
            ["loadEventEnd", "loadEventStart"],
            ["domContentLoadedEventStart"]
        ],
        Rl = {},
        Sl = (Rl.responseEnd = 1, Rl.domInteractive = 1, Rl.domContentLoadedEventStart = 1, Rl.domContentLoadedEventEnd = 1, Rl.domComplete = 1, Rl.loadEventStart = 1, Rl.loadEventEnd = 1, Rl.unloadEventStart = 1, Rl.unloadEventEnd = 1, Rl.secureConnectionStart = 1, Rl),
        Tl = x(De);

    function Ul(a, b, c) {
        return L(function(d) {
            var e = q(d),
                f = e.next().value;
            e = e.next().value;
            if (A(f)) return f(a, b) || null;
            if (1 === d.length) return b[f] ? Math.round(b[f]) : null;
            var g;
            !(g = b[f] && b[e]) && (g = 0 === b[f] && 0 === b[e]) && (g = q(d), d = g.next().value, g = g.next().value, g = !(Sl[d] || Sl[g]));
            if (!g) return null;
            f = Math.round(b[f]) - Math.round(b[e]);
            return 0 > f || 36E5 < f ? null : f
        }, c)
    }

    function Vl(a, b) {
        var c = a.length ? L(function(d, e) {
            var f = b[e];
            return f === d ? null : f
        }, a) : b;
        a.length = 0;
        L(G(v, Wa("push", a)), b);
        return nb(ra(null), c).length === a.length ? null : c
    }

    function Wl(a, b, c) {
        if ((void 0 === c.H ? {} : c.H).nohit) return null;
        a = vd(a);
        if (!a) return null;
        var d = c = null;
        I(a, "getEntriesByType") && (d = I(a.getEntriesByType("navigation"), "0")) && (c = Ql);
        if (!c) {
            var e = I(a, "timing");
            e && (c = Pl, d = e)
        }
        if (!c) return null;
        a = Ul(a, d, c);
        b = N(b);
        b = Tl(b);
        return (b = Vl(b, a)) && T(",", b)
    }
    var Xl = x(Ce),
        Yl = x(function(a) {
            var b = I(a, "webkitRequestFileSystem");
            if (A(b) && !rc(a)) return (new Q(C(b, a, 0, 0))).then(function() {
                var d = I(a, "navigator.storage") || {};
                return d.estimate ? d.estimate() : {}
            }).then(function(d) {
                return (d = d.quota) && 12E7 > d ? !0 : !1
            })["catch"](E(!0, v));
            if (Db(a)) return b = I(a, "navigator.serviceWorker"), Q.resolve(B(b));
            b = I(a, "openDatabase");
            if (lc(a) && A(b)) {
                var c = !1;
                try {
                    b(null, null, null, null)
                } catch (d) {
                    c = !0
                }
                return Q.resolve(c)
            }
            return Q.resolve(!I(a, "indexedDB") && (I(a, "PointerEvent") || I(a, "MSPointerEvent")))
        });

    function Zl(a) {
        if (oc(a)) return null;
        var b = Xl(a),
            c = b.sf;
        B(c) && (b.sf = null, Yl(a).then(function(d) {
            b.sf = d
        }));
        return c ? 1 : null
    }
    var $l = /(\?|&)turbo_uid=([\w\d]+)($|&)/,
        am = x(function(a, b) {
            var c = Ae(a),
                d = U(a).search.match($l);
            return d && 2 <= d.length ? (d = q(d), d.next(), d.next(), d = d.next().value, b.Ua || c.D("turbo_uid", d), d) : (c = c.C("turbo_uid")) ? c : ""
        }),
        bm = [
            [
                ["'(-$&$&$'", 30102, 0],
                ["'(-$&$&$'", 29009, 0]
            ],
            [
                ["oWdZ[nc[jh_YW$Yec", 30103, 1],
                ["oWdZ[nc[jh_YW$Yec", 29010, 1]
            ]
        ],
        cm = [
            [
                ["oWdZ[nc[jh_YW$Yec", 30103, 1]
            ],
            [
                ["oWdZ[nc[jh_YW$Yec", 29010, 1]
            ]
        ],
        dm = {
            H: {
                t: 'UV|L7,!"T[rwe&D_>ZIb\\aW#98Y.PC6k'
            }
        },
        em = {
            Qf: 60,
            error: 15
        },
        fm = {
            Qf: 5,
            error: 1
        },
        gm = {
            id: 42822899,
            ca: "0"
        },
        hm = W("pa.plgn", function(a, b) {
            var c = Ui(a, b);
            c && c.Z.F(["pluginInfo"], V(a, "c.plgn", function() {
                var d = O(a);
                d.D("cmc", d.C("cmc", 0) + 1);
                return We(b)
            }))
        }),
        im = {},
        jm = (im.am = "com.am", im.tr = "com.tr", im.ge = "com.ge", im.il = "co.il", im["\u0440\u0444"] = "ru", im["xn--p1ai"] = "ru", im["\u0431\u0435\u043b"] = "by", im["xn--90ais"] = "by", im),
        km = {
            "mc.edadeal.ru": /^([^/]+\.)?edadeal\.ru$/,
            "mc.yandexsport.ru": /^([^/]+\.)?yandexsport\.ru$/,
            "mc.kinopoisk.ru": /^([^/]+\.)?kinopoisk\.ru$/
        },
        lm = {},
        mm = (lm.ka = "ge", lm.ro = "md", lm.tg = "tj", lm.tk =
            "tm", lm.et = "ee", lm.hy = "com.am", lm.he = "co.li", lm.ky = "kg", lm.be = "by", lm.tr = "com.tr", lm.kk = "kz", lm);

    function nm(a, b) {
        var c = sl(function(d, e) {
            return d[1].da > e[1].da ? 1 : -1
        }, bc(Rc));
        c = L(function(d) {
            var e = q(d);
            d = e.next().value;
            var f = e.next().value.Va;
            e = H(b, d) && !Ra(b[d]);
            d = b[d] !== (f || v)(void 0);
            return jb(e && d)
        }, c);
        return Wb(T("", c))
    }
    var om = /^https?:\/\//,
        pm = {
            1882689622: 1,
            2318205080: 1,
            3115871109: 1,
            3604875100: 1,
            339366994: 1,
            849340123: 1,
            3735661796: 1,
            3082499531: 1,
            2343947156: 1,
            655012937: 1,
            3724710748: 1,
            3364370932: 1,
            1996539654: 1,
            2065498185: 1,
            823651274: 1,
            12282461: 1,
            1555719328: 1,
            1417229093: 1,
            138396985: 1,
            3015043526: 1
        },
        qm = x(function() {
            return F(function(a, b) {
                a[Yj(b + "/tag.js")] = 1;
                return a
            }, {}, ["mc.yandex.ru/metrika", "mc.yandex.com/metrika", "cdn.jsdelivr.net/npm/yandex-metrica-watch"])
        }),
        rm = x(function(a) {
            a = vd(a);
            if (!a || !A(a.getEntriesByType)) return null;
            a = a.getEntriesByType("resource");
            var b = qm();
            return (a = Je(function(c) {
                c = q(c.name.replace(om, "").split("?")).next().value;
                return b[Yj(c)]
            }, a)) ? jb(a.transferSize) : null
        }),
        sm = "ar:1:pv:1:v:" + Nc.eb + ":vf:" + na.version,
        tm = Nc.La + "//" + Lc + "/watch/" + Nc.$f;

    function um(a, b) {
        try {
            var c = q(b),
                d = q(c.next().value);
            d.next();
            var e = d.next().value
        } catch (f) {
            return function() {
                return Q.resolve()
            }
        }
        return function(f) {
            var g = {};
            g = (g["browser-info"] = sm, g["page-url"] = a.location && "" + a.location.href, g);
            return e && (f = yf(a, f)) ? e(tm, {
                ab: g,
                ea: [],
                ba: "site-info=" + Td(f)
            })["catch"](u) : Q.resolve()
        }
    }
    var vm = {},
        wm = W("exps.int", function(a, b) {
            var c = {};
            return c.experiments = function(d, e, f) {
                if (y(d) && !(0 >= d.length)) {
                    var g = Rh(a, "e", b),
                        h = Oi(b).url,
                        k = {},
                        l = {};
                    d = g({
                        K: Le((k.ex = 1, k.ar = 1, k)),
                        H: (l["page-url"] = h || U(a).href, l.exp = d, l)
                    }, b);
                    return Ni(a, "exps.s", d, e || u, f)
                }
            }, c
        }),
        xm = [],
        zm = W("p.fh", function(a, b) {
            b = void 0 === b ? !0 : b;
            var c = Ff(a),
                d = Ed(a),
                e = c.C("wasSynced"),
                f = {
                    id: 3,
                    ca: "0"
                };
            if (b && e && e.time + 864E5 > d(Ad)) return Q.resolve(e);
            e = {};
            var g = {};
            return Rh(a, "f", f)({
                K: Le((e.pv = 1, e)),
                H: (g["page-url"] = U(a).href, g["page-ref"] =
                    a.document.referrer, g)
            }, f).then(function(h) {
                var k = {};
                h = (k.time = d(Ad), k.params = I(h, "settings"), k.bkParams = I(h, "userData"), k);
                c.D("wasSynced", h);
                return h
            })["catch"](V(a, "f.h"))
        }),
        Am = pa(function(a, b) {
            0 === parseFloat(I(b, "settings.c_recp")) && (a.Sd.D("ymoo" + a.wa, a.Tf(Bd)), a.kd && a.kd.destruct && a.kd.destruct())
        }),
        Bm = G(db("settings.pcs"), ra("1"));

    function Cm(a, b, c) {
        var d = b || {},
            e = Rh(a, "u", c),
            f = Ff(a);
        return {
            C: function(g, h) {
                return B(d[g]) ? f.C(g, h) : d[g]
            },
            D: function(g, h) {
                var k = "" + h;
                d[g] = k;
                f.D(g, k);
                var l = {};
                return e({
                    H: (l.key = g, l.value = k, l)
                }, [Nc.La + "//" + Lc + "/user_storage_set"], {})["catch"](V(a, "u.d.s.s"))
            }
        }
    }
    var Dm = x(function(a) {
            a = U(a).hostname.split(".");
            return a[a.length - 1]
        }),
        Em = x(function(a) {
            return -1 !== U(a).hostname.search(/(?:^|\.)(?:ya|yandex|beru|kinopoisk|edadeal)\.(?:\w+|com?\.\w+)$/)
        }),
        Fm = RegExp("^(.*\\.)?((yandex(-team)?)\\.(com?\\.)?[a-z]+|(auto|kinopoisk|beru|bringly)\\.ru|ya\\.(ru|cc)|yadi\\.sk|yastatic\\.net|.*\\.yandex|turbopages\\.org|turbo\\.site|diplodoc\\.(com|tech)|datalens\\.tech|white-label\\.yango-tech\\.com|al-sadhan\\.com|spar\\.sa)$"),
        Gm = x(function(a) {
            a = U(a).hostname;
            var b = !1;
            a && (b = -1 !== a.search(Fm));
            return b
        }),
        Hm = RegExp("^(.*\\.)?((yandex(-team)?)\\.(com?\\.)?[a-z]+|(auto|kinopoisk|beru|bringly)\\.ru|ya\\.(ru|cc)|yadi\\.sk|.*\\.yandex|turbopages\\.org|turbo\\.site)$"),
        Im = x(function(a) {
            a = U(a).hostname;
            var b = !1;
            a && (b = -1 !== a.search(Hm));
            return b
        }),
        Jm = {},
        Km = (Jm.s = "p", Jm["8"] = "i", Jm),
        Lm = Yd("csp", function(a, b) {
            return Rh(a, "s", b)({}, ["https://ymetrica1.com/watch/3/1"])
        });

    function Mm(a, b, c) {
        var d = c.Ob,
            e = c.data,
            f = Rh(a, d, c.fb);
        a = M({}, dm);
        e && M(a.H, e);
        return xg(L(function(g) {
            return zg(f(M({
                N: {
                    Wc: !1,
                    Nc: !0
                }
            }, dm), L(function(h) {
                var k = q(h),
                    l = k.next().value;
                h = k.next().value;
                k = k.next().value;
                l = T("", L(function(m) {
                    return String.fromCharCode(m.charCodeAt(0) + 10)
                }, l.split("")));
                return "http" + (k ? "s" : "") + "://" + l + ":" + h + "/" + Km[d]
            }, g)).then(function(h) {
                return M({}, h, {
                    host: g[h.Ae]
                })
            }))
        }, b))
    }

    function Nm(a, b, c, d, e, f) {
        var g = f.Qd,
            h = f.fb,
            k = f.wb;
        return new Q(function(l, m) {
            var p = c.C(g, 0);
            p = parseInt("" + p, 10);
            return b(Bd) - p <= e.Qf ? (k(3), m()) : Im(a) ? l(void 0) : Bm(d) ? (k(4), m()) : l(Lm(a, h)["catch"](G(sa(E(5, k)), md)))
        })
    }

    function Om(a, b, c, d, e) {
        var f = void 0 === e.Rf ? u : e.Rf,
            g = e.Qd,
            h = void 0 === e.wb ? u : e.wb,
            k = d(Ad);
        return Mm(a, b, e)(ug(function(l) {
            h(6);
            L(function(m) {
                m && mf(a, g + ".s", m)
            }, l);
            l = d(Bd);
            c.D(g, l).then(E(7, h))
        }, function(l) {
            h(8);
            c.D(g, d(Bd)).then(E(9, h));
            f(l, d, k)
        }))
    }

    function Pm(a) {
        var b = rc(a);
        a = G(kc, sb(["iPhone", "iPad"]))(a);
        return b ? bm : a ? cm : []
    }

    function Qm(a, b, c) {
        var d = c.fb,
            e = void 0 === c.wb ? u : c.wb,
            f = Ed(a),
            g = Cm(a, b.userData, d),
            h = Pm(a),
            k = G(fe, D([fm, em], hb))(a),
            l = I(b, "settings.sbp");
        c.wb = e;
        if (l) {
            var m = {};
            c.data = M({}, l, (m.c = d.id, m))
        }
        return h.length ? Nm(a, f, g, b, k, c).then(function() {
            return Om(a, h, g, f, c)
        }, u) : (e(2), Q.resolve())
    }

    function Rm(a, b) {
        this.l = a;
        this.type = b
    }
    Rm.isEnabled = function(a) {
        return !!a.JSON
    };
    Rm.prototype.Ha = function(a) {
        return Ag(yf(this.l, a))
    };
    Rm.prototype.ub = function(a) {
        var b = a.data;
        "string" !== typeof b && (b = yf(this.l, a.data));
        return b
    };
    Rm.prototype.lb = function(a) {
        return encodeURIComponent(a).length
    };
    Rm.prototype.ne = function(a, b) {
        for (var c = Math.ceil(a.length / b), d = [], e = 0; e < b; e += 1) d.push(a.slice(e * c, c * (e + 1)));
        return d
    };

    function Sm(a) {
        if (!a) return [0, 0];
        var b = 0 > a;
        b && (a = -a);
        var c = a >>> 0;
        a = (a - c) / 4294967296 >>> 0;
        b && (a = ~a >>> 0, c = ~c >>> 0, 4294967295 < ++c && (c = 0, 4294967295 < ++a && (a = 0)));
        return [a, c]
    }

    function Tm(a, b, c, d) {
        b = q(b);
        a = b.next().value;
        for (b = b.next().value; a;) c[d++] = b & 127 | 128, b = (b >>> 7 | a << 25) >>> 0, a >>>= 7;
        for (; 127 < b;) c[d++] = b & 127 | 128, b >>>= 7;
        c[d++] = b
    }

    function Um(a, b, c) {
        b[c] = a & 255;
        b[c + 1] = a >>> 8 & 255;
        b[c + 2] = a >>> 16 & 255;
        b[c + 3] = a >>> 24
    }

    function Vm(a, b, c, d) {
        var e = 0 > b ? 1 : 0;
        e && (b = -b);
        if (0 === b) Um(0 < 1 / b ? 0 : 2147483648, c, d);
        else if (a.isNaN(b)) Um(2143289344, c, d);
        else if (3.4028234663852886E38 < b) Um((e << 31 | 2139095040) >>> 0, c, d);
        else if (1.1754943508222875E-38 > b) Um((e << 31 | a.Math.round(b / 1.401298464324817E-45)) >>> 0, c, d);
        else {
            var f = a.Math.floor(a.Math.log(b) / Math.LN2);
            Um((e << 31 | f + 127 << 23 | Math.round(b * a.Math.pow(2, -f) * 8388608) & 8388607) >>> 0, c, d)
        }
    }
    var Wm = x(function(a) {
        function b(f, g, h, k) {
            d[0] = g;
            h[k] = e[3];
            h[k + 1] = e[2];
            h[k + 2] = e[1];
            h[k + 3] = e[0]
        }

        function c(f, g, h, k) {
            d[0] = g;
            h[k] = e[0];
            h[k + 1] = e[1];
            h[k + 2] = e[2];
            h[k + 3] = e[3]
        }
        if ("undefined" === typeof a.Float32Array || "undefined" === typeof a.Uint8Array) return Vm;
        var d = new Float32Array([-0]),
            e = new Uint8Array(d.buffer);
        return 128 === e[3] ? c : b
    });

    function Xm(a, b, c, d) {
        return Wm(a)(a, b, c, d)
    }

    function Ym(a) {
        return function(b, c, d, e) {
            for (var f, g = 0, h = 0; h < c.length; ++h)
                if (b = c.charCodeAt(h), 128 > b) a ? g += 1 : d[e++] = b;
                else {
                    if (2048 > b) {
                        if (a) {
                            g += 2;
                            continue
                        }
                        d[e++] = b >> 6 | 192
                    } else {
                        if (55296 === (b & 64512) && 56320 === ((f = c.charCodeAt(h + 1)) & 64512)) {
                            if (a) {
                                g += 4;
                                continue
                            }
                            b = 65536 + ((b & 1023) << 10) + (f & 1023);
                            ++h;
                            d[e++] = b >> 18 | 240;
                            d[e++] = b >> 12 & 63 | 128
                        } else {
                            if (a) {
                                g += 3;
                                continue
                            }
                            d[e++] = b >> 12 | 224
                        }
                        d[e++] = b >> 6 & 63 | 128
                    }
                    d[e++] = b & 63 | 128
                }
            return a ? g : e
        }
    }
    var Zm = Ym(!1),
        $m = Ym(!0);

    function an(a, b, c, d) {
        for (a = 0; a < b.length; ++a) c[d + a] = b[a]
    }

    function bn(a, b, c, d) {
        c[d] = b
    }

    function cn(a, b, c, d) {
        for (a = b; 127 < a;) c[d++] = a & 127 | 128, a >>>= 7;
        c[d] = a
    }

    function dn(a) {
        return [cn, 128 > a ? 1 : 16384 > a ? 2 : 2097152 > a ? 3 : 268435456 > a ? 4 : 5, a]
    }

    function en(a) {
        return 0 > a ? [Tm, 10, Sm(a)] : dn(a)
    }

    function fn(a) {
        return [Xm, 4, a]
    }

    function gn(a) {
        a = Sm(a);
        var b = q(a),
            c = b.next().value;
        b = b.next().value;
        var d = (b >>> 28 | c << 4) >>> 0;
        c >>>= 24;
        return [Tm, 0 === c ? 0 === d ? 16384 > b ? 128 > b ? 1 : 2 : 2097152 > b ? 3 : 4 : 16384 > d ? 128 > d ? 5 : 6 : 2097152 > d ? 7 : 8 : 128 > c ? 9 : 10, a]
    }

    function hn(a) {
        return [bn, 1, a ? 1 : 0]
    }

    function jn(a) {
        return [an, a.length, a]
    }

    function kn(a) {
        var b = $m({}, a, [], 0);
        return b ? [Zm, b, a] : [bn, 0, 0]
    }

    function ln(a) {
        return [
            [513, a.hidden, hn],
            [449, a.prev, dn],
            [385, a.next, dn],
            [337, a.content, kn],
            [257, a.parent, dn],
            [210, a.attributes, 81, kn, 145, kn],
            [145, a.name, kn],
            [65, a.id, dn]
        ]
    }

    function mn(a) {
        return [
            [129, a.height, en],
            [65, a.width, en]
        ]
    }

    function nn(a) {
        return [
            [209, a.path, kn],
            [145, a.protocol, kn],
            [81, a.host, kn]
        ]
    }

    function on(a) {
        return [
            [852, a.content, ln],
            [785, a.tabId, kn],
            [705, a.recordStamp, gn],
            [656, a.location, nn],
            [592, a.viewport, mn],
            [528, a.screen, mn],
            [449, a.hasBase, hn],
            [401, a.base, kn],
            [337, a.referrer, kn],
            [273, a.ua, kn],
            [209, a.address, kn],
            [145, a.title, kn],
            [81, a.doctype, kn]
        ]
    }

    function pn(a) {
        return [
            [210, a.attributes, 81, kn, 145, kn],
            [129, a.index, dn],
            [65, a.target, dn]
        ]
    }

    function qn(a) {
        return [
            [129, a.index, dn],
            [84, a.nodes, ln]
        ]
    }

    function rn(a) {
        return [
            [129, a.index, dn],
            [69, a.nodes, en]
        ]
    }

    function sn(a) {
        return [
            [209, a.value, kn],
            [129, a.index, dn],
            [65, a.target, dn]
        ]
    }

    function tn(a) {
        return [
            [193, a.index, dn],
            [145, a.op, kn],
            [81, a.style, kn]
        ]
    }

    function un(a) {
        return [
            [148, a.changes, tn],
            [65, a.target, en]
        ]
    }

    function vn(a) {
        return [
            [193, a.target, en],
            [129, a.y, dn],
            [65, a.x, dn]
        ]
    }

    function wn(a) {
        return [
            [257, a.target, en],
            [193, a.page, hn],
            [129, a.y, en],
            [65, a.x, en]
        ]
    }

    function xn(a) {
        return [
            [257, a.endNode, dn],
            [193, a.startNode, dn],
            [129, a.end, en],
            [65, a.start, en]
        ]
    }

    function yn(a) {
        return [
            [257, a.target, en],
            [193, a.hidden, hn],
            [129, a.checked, hn],
            [81, a.value, kn]
        ]
    }

    function zn(a) {
        return [
            [297, a.force, fn],
            [233, a.y, fn],
            [169, a.x, fn],
            [81, a.id, kn]
        ]
    }

    function An(a) {
        return [
            [129, a.target, en],
            [84, a.touches, zn]
        ]
    }

    function Bn(a) {
        return [
            [193, a.y, en],
            [129, a.x, en],
            [105, a.level, fn]
        ]
    }

    function Cn(a) {
        return [
            [257, a.pageHeight, dn],
            [193, a.pageWidth, dn],
            [129, a.height, dn],
            [65, a.width, dn]
        ]
    }

    function Dn(a) {
        return [
            [273, a.modifier, kn],
            [193, a.isMeta, hn],
            [145, a.key, kn],
            [65, a.id, dn]
        ]
    }

    function En(a) {
        return [
            [84, a.keystrokes, Dn]
        ]
    }

    function Fn(a) {
        return [
            [193, a.orientation, en],
            [129, a.height, dn],
            [65, a.width, dn]
        ]
    }

    function Gn(a) {
        return [
            [209, a.stack, kn],
            [145, a.Lg, kn],
            [81, a.code, kn]
        ]
    }

    function Hn(a) {
        return [
            [65, a.target, en]
        ]
    }

    function In(a) {
        return [
            [129, a.involvedTime, en],
            [84, a.articleMeta, Jn]
        ]
    }

    function Jn(a) {
        return [
            [513, a.chars, en],
            [489, a.maxScrolled, fn],
            [385, a.involvedTime, en],
            [321, a.height, en],
            [257, a.width, en],
            [193, a.y, en],
            [129, a.x, en],
            [65, a.id, dn]
        ]
    }

    function Kn(a) {
        return [
            [593, a.updateDate, kn],
            [532, a.rubric, Ln],
            [449, a.chars, en],
            [401, a.publicationDate, kn],
            [340, a.topics, Mn],
            [276, a.authors, Nn],
            [209, a.pageTitle, kn],
            [145, a.pageUrlCanonical, kn],
            [65, a.id, dn]
        ]
    }

    function Nn(a) {
        return [
            [81, a.name, kn]
        ]
    }

    function Mn(a) {
        return [
            [81, a.name, kn]
        ]
    }

    function Ln(a) {
        return [
            [129, a.position, en],
            [81, a.name, kn]
        ]
    }

    function On(a) {
        return [
            [84, a.Ih, Pn]
        ]
    }

    function Pn(a) {
        return [
            [1857, a.partsTotal, dn],
            [1793, a.activity, dn],
            [1744, a.textChangeMutation, sn],
            [1680, a.removedNodesMutation, rn],
            [1616, a.addedNodesMutation, qn],
            [1552, a.attributesChangeMutation, pn],
            [1488, a.publishersHeader, In],
            [1424, a.articleInfo, Kn],
            [1360, a.focusEvent, Hn],
            [1296, a.fatalErrorEvent, Gn],
            [1232, a.deviceRotationEvent, Fn],
            [1168, a.keystrokesEvent, En],
            [1104, a.resizeEvent, Cn],
            [1040, a.zoomEvent, Bn],
            [976, a.touchEvent, An],
            [912, a.changeEvent, yn],
            [848, a.selectionEvent, xn],
            [784, a.scrollEvent, wn],
            [720, a.mouseEvent, vn],
            [656, a.styleChangeEvent, un],
            [592, a.page, on],
            [513, a.end, hn],
            [449, a.partNum, dn],
            [401, a.chunk, jn],
            [257, a.frameId, en],
            [193, a.event, dn],
            [129, a.type, dn],
            [65, a.stamp, dn]
        ]
    }
    var Qn = {},
        Rn = (Qn.mousemove = 0, Qn.mouseup = 1, Qn.mousedown = 2, Qn.click = 3, Qn.scroll = 4, Qn.windowblur = 5, Qn.windowfocus = 6, Qn.focus = 7, Qn.blur = 8, Qn.eof = 9, Qn.selection = 10, Qn.change = 11, Qn.input = 12, Qn.touchmove = 13, Qn.touchstart = 14, Qn.touchend = 15, Qn.touchcancel = 16, Qn.touchforcechange = 17, Qn.zoom = 18, Qn.resize = 19, Qn.keystroke = 20, Qn.deviceRotation = 21, Qn.fatalError = 22, Qn.hashchange = 23, Qn.stylechange = 24, Qn.articleInfo = 25, Qn.publishersHeader = 26, Qn.pageData = 27, Qn.mutationAdd = 28, Qn.mutationRemove = 29, Qn.mutationTextChange =
            30, Qn.mutationAttributesChange = 31, Qn),
        Sn = {},
        Tn = (Sn.page = 0, Sn.event = 1, Sn.mutation = 2, Sn.publishers = 3, Sn.activity = 4, Sn);

    function Un(a, b) {
        a[0] += b[1];
        a[2][3] = b;
        a[2] = b
    }

    function Vn(a) {
        a[3] = [a[0], a[1], a[2], a[3]];
        a[1] = [u, 0, 0];
        a[2] = a[1];
        a[0] = 0
    }

    function Wn(a) {
        var b = a[1],
            c = a[0],
            d = a[2];
        a[3] ? (a[0] = a[3][0], a[1] = a[3][1], a[2] = a[3][2], a[3] = a[3][3]) : (a[0] = 0, a[1] = [u, 0, 0], a[2] = a[1]);
        Un(a, dn(c));
        c && (a[2][3] = b[3], a[2] = d, a[0] += c)
    }

    function Xn(a, b) {
        var c = a(b),
            d = [u, 0, 0],
            e = [0, d, d, void 0];
        return Rd(c, function(f, g) {
            var h = q(f),
                k = h.next().value,
                l = h.next().value,
                m = h.next().value;
            if (0 === k) return m(e, l), e;
            if (void 0 === l || null === l) return e;
            h = k >> 3;
            if (k & 4)
                for (var p = l.length - 1; 0 <= p;) {
                    var r = l[p];
                    k & 1 ? Pe(g, [
                        [k - 4, r, m]
                    ]) : (r = m(r), r.push([0, 0, Vn]), r.push([0, dn(h), Un]), r.unshift([0, 0, Wn]), Pe(g, r));
                    --p
                } else if (k & 1) Un(e, dn(h)), l = m(l), h & 2 && Un(e, dn(l[1])), Un(e, l);
                else if (k & 2) {
                r = q(f);
                r.next();
                r.next();
                k = r.next().value;
                m = r.next().value;
                p = r.next().value;
                r = r.next().value;
                for (var t = cc(l), w = t.length - 1; 0 <= w;) {
                    var z = t[w];
                    Pe(g, [
                        [0, 0, Wn],
                        [p, l[z], r],
                        [k, z, m],
                        [0, 0, Vn],
                        [0, dn(h), Un]
                    ]);
                    --w
                }
            } else l = m(l), l.push([0, 0, Vn]), l.push([0, dn(h), Un]), l.unshift([0, 0, Wn]), Pe(g, l);
            return e
        })
    }

    function Yn(a, b) {
        var c = b[1][3],
            d = 0,
            e = new a.Uint8Array(b[0]);
        return Rd([c], function(f, g) {
            if (!f) return e;
            f[0](a, f[2], e, d);
            d += f[1];
            g.push(f[3]);
            return e
        })
    }

    function Zn(a, b) {
        var c = this;
        this.isSync = !1;
        this.Eb = [];
        var d = {};
        this.Jg = (d.ad = "mutationAdd", d.re = "mutationRemove", d.tc = "mutationTextChange", d.ac = "mutationAttributesChange", d.page = "pageData", d);
        d = {};
        this.Dg = (d.ad = "addedNodesMutation", d.re = "removedNodesMutation", d.tc = "textChangeMutation", d.ac = "attributesChangeMutation", d.touchmove = "touchEvent", d.touchstart = "touchEvent", d.touchend = "touchEvent", d.touchforcechange = "touchEvent", d.touchcancel = "touchEvent", d.resize = "resizeEvent", d.scroll = "scrollEvent", d.change =
            "changeEvent", d.mousemove = "mouseEvent", d.mousedown = "mouseEvent", d.mouseup = "mouseEvent", d.click = "mouseEvent", d.focus = "focusEvent", d.blur = "focusEvent", d.deviceRotation = "deviceRotationEvent", d.zoom = "zoomEvent", d.keystroke = "keystrokesEvent", d.selection = "selectionEvent", d.stylechange = "styleChangeEvent", d.fatalError = "fatalErrorEvent", d.pageData = "page", d);
        this.Xg = function(e) {
            var f = e.type;
            return e.event || "publishersHeader" !== f && "articleInfo" !== f ? {
                type: Tn[f],
                event: Rn[c.Jg[e.event] || e.event]
            } : {
                type: Tn.publishers,
                event: Rn[f]
            }
        };
        this.lf = function(e) {
            var f = !B(e.partNum),
                g = c.Xg(e);
            g = {
                stamp: e.stamp,
                type: g.type,
                event: g.event,
                frameId: e.frameId,
                chunk: f ? e.data : void 0,
                partNum: e.partNum,
                end: e.end
            };
            !f && e.data && (f = c.Dg[e.event] || e.event || e.type) && (g[f] = e.data);
            return g
        };
        this.l = a;
        this.type = b
    }
    Zn.prototype.Ha = function(a, b) {
        var c = this;
        b = void 0 === b ? !1 : b;
        var d = Rd(a, this.lf),
            e = this.isSync || b ? Infinity : 10;
        d = ml(this.l, d, e);
        var f = [d];
        this.Eb.push(d);
        return d(wg(function(g) {
            g = Xn(On, {
                Ih: g
            });
            g = ml(c.l, g, e, Od);
            f.push(g);
            c.Eb.push(g);
            return g
        }))(wg(function(g) {
            g = Yn(c.l, g.slice(-4));
            g = ml(c.l, g, e, Od);
            f.push(g);
            c.Eb.push(g);
            return g
        }))(vg(function(g) {
            g = g[g.length - 1];
            L(function(h) {
                h = wb(c.l)(h, c.Eb);
                c.Eb.splice(h, 1)
            }, f);
            return g
        }))
    };
    Zn.prototype.ub = function(a) {
        return Xn(Pn, this.lf(a))(Nd(u))
    };
    Zn.prototype.lb = function(a) {
        return a[0]
    };
    Zn.prototype.ne = function(a, b) {
        for (var c = Yn(this.l, a)(Nd(u)), d = Math.ceil(c.length / b), e = [], f = 0; f < b; f += 1) e.push(c.slice(f * d, d * (f + 1)));
        return e
    };
    Zn.isEnabled = function(a) {
        var b = Be(a),
            c = !1;
        try {
            c = (c = 2 === (new a.Blob(["\u00e4"])).size) && 2 === (new a.Blob([new a.Uint8Array([1, 2])])).size
        } catch (d) {}
        return !b && c && !(!a.Uint8Array || !I(a, "Uint8Array.prototype.slice"))
    };

    function $n(a, b, c) {
        if (Zn.isEnabled(a)) return new Zn(a, b);
        if (Rm.isEnabled(a)) return new Rm(a, c)
    }
    var ao = df("wv");

    function bo(a, b, c, d) {
        var e = c.H;
        e.wmode = "0";
        e["wv-hit"] = e["wv-hit"] || "" + lg(a);
        e["page-url"] = e["page-url"] || U(a).href;
        d && (e[d] = e[d] || "" + Xd(a));
        a = {};
        b = {
            ma: {
                ra: "webvisor/" + b.id
            },
            N: M(c.N || {}, {
                $a: (a["Content-Type"] = "text/plain", a),
                Vc: "POST"
            }),
            H: e
        };
        M(c, b)
    }

    function co(a, b) {
        return {
            R: function(c, d) {
                bo(a, b, c);
                d()
            }
        }
    }
    var eo = "resize scroll mousemove mousedown click windowfocus keydown orientationchange change focus touchmove touchstart".split(" "),
        fo = "id pageTitle stamp chars authors updateDate publicationDate pageUrlCanonical topics rubric".split(" ");

    function go(a, b, c, d, e) {
        var f = this;
        this.xc = !1;
        this.meta = {};
        this.scroll = {
            x: 0,
            y: 0
        };
        this.involvedTime = this.jf = 0;
        this.Ud = this.rf = "";
        this.fa = [];
        this.le = this.Pa = 0;
        this.yb = {
            h: 0,
            w: 0
        };
        this.buffer = [];
        this.ag = fo;
        this.flush = function() {
            f.le = X(f.l, f.flush, 2500);
            var g = f.zd();
            if (f.buffer.length || g) {
                var h = yb(f.buffer);
                g && h.push(g);
                f.rf = f.Ud;
                f.ja.Ha(h)(ug(V(f.l, "p.b.st"), function(k) {
                    k && f.Sb(k)
                }))
            }
        };
        this.Sb = d;
        this.ja = c;
        this.Zb = C(this.Zb, this);
        this.zd = C(this.zd, this);
        this.flush = C(this.flush, this);
        this.l = a;
        this.wa = e;
        this.Oc =
            b;
        this.Od = "pai" + b.id;
        this.Jb();
        this.Pe = ud(this.l);
        this.time = Ed(this.l);
        ho(this);
        this.Bd = O(this.l);
        this.ze = null
    }
    n = go.prototype;
    n.start = function() {
        this.le = X(this.l, this.flush, 2500);
        if (!this.xc) {
            this.Pe.F(this.l, eo, this.Zb);
            var a = this.Bd.C(this.Od, []),
                b = !a.length;
            a.push(C(this.nh, this));
            this.Bd.sa(this.Od, a);
            b && this.Bf();
            this.ze = ud(this.l).F(this.l, ["click"], C(this.Oh, this));
            this.Zb({
                type: "page",
                target: this.l
            })
        }
    };
    n.stop = function() {
        this.ze && this.ze();
        this.Pe.Xb(this.l, eo, this.Zb);
        this.xc = !0;
        this.flush();
        rg(this.l, this.le)
    };
    n.Bf = function() {
        var a = this;
        V(this.l, "p.ic" + this.Oc.id, function() {
            if (!a.xc) {
                var b = a.Bd.C(a.Od),
                    c = io(a.Oc);
                L(function(d) {
                    var e = L(function(f) {
                        return M({}, f)
                    }, c);
                    A(d) && d(e)
                }, b);
                a.Pa = X(a.l, C(a.Bf, a), 1E3, "p")
            }
        })()
    };
    n.nh = function(a) {
        this.xc || (jo(this, a), ko(this), lo(this))
    };
    n.wg = function(a, b) {
        return (a.ie || 0) <= (b.ie || 0) ? b : a
    };
    n.Oh = function(a) {
        if (this.fa.length) {
            a = kj(a);
            var b = U(this.l).hostname;
            a && ee(a.hostname) === ee(b) && (a = F(this.wg, this.fa[0], this.fa).id, b = lg(this.l), Gf(this.l, this.wa.split(":")[0]).D("pai", a + "-" + b))
        }
    };
    n.Zb = function(a) {
        var b = this;
        V(this.l, "p.ec." + this.Oc.id, function() {
            try {
                var c = a.type;
                var d = a.target
            } catch (k) {
                return
            }
            var e = "page" === c;
            if ("scroll" === c || e) {
                var f = [b.l, b.l.document, b.l.document.documentElement, Qf(b.l)];
                J(d, f) && b.Jb()
            }("resize" === c || e) && ho(b);
            c = b.time(Ad);
            var g = Math.min(c - b.jf, 5E3);
            b.involvedTime += Math.round(g);
            b.jf = c;
            if (b.meta && b.scroll && b.yb) {
                var h = b.yb.h * b.yb.w;
                b.fa = L(function(k) {
                    var l = M({}, k),
                        m = b.meta[l.id],
                        p = Vf(k.Db);
                    if (!m || Ej("html", b.l, l.element) !== b.l.document.documentElement ||
                        !p) return l;
                    k = b.l.Math;
                    m = k.max((b.scroll.y + b.yb.h - m.y) / m.height, 0);
                    var r = p.height * p.width,
                        t = b.yb,
                        w = p.top,
                        z = p.bottom,
                        P = p.left,
                        R = t.w;
                    t = t.h;
                    var ma = b.l.Math;
                    p = ma.min(ma.max(p.right, 0), R) - ma.min(ma.max(P, 0), R);
                    p *= ma.min(ma.max(z, 0), t) - ma.min(ma.max(w, 0), t);
                    l.ie = p / h;
                    l.visibility = p / r;
                    if (.9 <= l.visibility || .1 <= l.ie) l.involvedTime += g;
                    l.maxScrolled = k.round(1E4 * m) / 1E4;
                    return l
                }, b.fa);
                c = {};
                d = {};
                Fe(b.l, (d.name = "publishers", d.counterKey = b.wa, d.data = (c.involvedTime = b.involvedTime, c.contentItems = L(function(k) {
                    var l = {};
                    return M((l.contentElement = k.Db, l), k)
                }, b.fa), c), d))
            }
        })()
    };

    function jo(a, b) {
        var c = L(function(d) {
            return d.id
        }, a.fa);
        a.fa = a.fa.concat(nb(function(d) {
            return !J(d.id, c)
        }, b))
    }

    function ho(a) {
        var b = q(Sf(a.l) || Tf(a.l)),
            c = b.next().value;
        b = b.next().value;
        a.yb = {
            w: c,
            h: b
        }
    }

    function ko(a) {
        V(a.l, "p.um." + a.Oc.id, function() {
            var b = [];
            a.Jb();
            a.meta = F(function(c, d) {
                if (Ej("html", a.l, d.element) !== a.l.document.documentElement) return b.push(d), delete c[d.id], c;
                var e = {};
                e = (e.id = d.id, e.involvedTime = Math.max(d.involvedTime, 0), e.maxScrolled = d.maxScrolled || 0, e.chars = d.update ? d.update("chars") || 0 : 0, e);
                if (d.Db) {
                    var f = Vf(d.Db);
                    f && (e.x = Math.max(Math.round(f.left) + a.scroll.x, 0), e.y = Math.max(Math.round(f.top) + a.scroll.y, 0), e.width = Math.round(f.width), e.height = Math.round(f.height))
                }
                c[d.id] =
                    e;
                return c
            }, {}, a.fa);
            L(function(c) {
                c = wb(a.l)(c, a.fa);
                a.fa.splice(c, 1)
            }, b)
        })()
    }
    n.zd = function() {
        var a = L(E(this.meta, I), cc(this.meta));
        if (a.length && (this.Ud = yf(this.l, a), this.rf !== this.Ud)) {
            var b = {},
                c = {};
            return c.type = "publishersHeader", c.data = (b.articleMeta = a || [], b.involvedTime = this.involvedTime, b), c
        }
        return null
    };

    function lo(a) {
        if (a.fa.length) {
            var b = L(function(c) {
                var d = F(function(f, g) {
                    c[g] && (f[g] = c[g]);
                    return f
                }, {}, a.ag);
                c.Kf = !0;
                var e = {};
                return e.type = "articleInfo", e.stamp = d.stamp, e.data = d, e
            }, nb(function(c) {
                return !c.Kf
            }, a.fa));
            b.length && (a.buffer = a.buffer.concat(b), Zh(a.l, a.wa, ["pdf", b]))
        }
    }
    n.Jb = function() {
        this.scroll = {
            x: this.l.pageXOffset || I(this.l, "document.documentElement.scrollLeft") || 0,
            y: this.l.pageYOffset || I(this.l, "document.documentElement.scrollLeft") || 0
        }
    };
    var mo = {},
        no = (mo[1] = 500, mo[2] = 500, mo[3] = 0, mo);

    function oo(a, b, c) {
        var d = b.getAttribute("itemtype");
        c = Aj('[itemprop~="' + c + '"]', b);
        return d ? nb(function(e) {
            return e.parentNode && Ej("[itemtype]", a, e.parentNode) === b
        }, c) : c
    }

    function po(a, b, c) {
        return (a = oo(a, b, c)) && a.length ? a[0] : null
    }

    function qo(a) {
        if (!a) return "";
        a = K(a) ? a : [a];
        return a.length ? a[0].getAttribute("content") || If(a[0]) : ""
    }

    function ro(a) {
        return a ? a.attributes && a.getAttribute("datetime") ? a.getAttribute("datetime") : qo(a) : ""
    }
    var so = ["topics", "rubric", "authors"];

    function to(a, b) {
        var c = this;
        this.id = "a";
        this.Id = !1;
        this.Gb = {};
        this.tb = {
            "schema.org": "Article NewsArticle Movie BlogPosting Review Recipe Answer".split(" "),
            nf: ["article"]
        };
        var d = {};
        this.Wb = (d.Answer = 3, d.Review = 2, d);
        this.Re = x(function(e, f, g) {
            var h = {};
            Zh(c.l, c.wa, "pfi", (h.field = e, h.itemField = f, h.value = g, h))
        }, function(e, f, g) {
            return "" + e + f + g
        });
        this.ai = function(e) {
            L(function(f) {
                e[f] && (e[f] = F(function(g, h) {
                    var k = h.name,
                        l = h.position;
                    if (!k) return c.Re(f, "name", k), g;
                    if ("string" === typeof l) {
                        k = Tb(l);
                        if (null ===
                            k || c.l.isNaN(k)) return c.Re(f, "position", l), g;
                        h.position = k
                    }
                    g.push(h);
                    return g
                }, [], e[f]))
            }, so);
            return e
        };
        this.xg = x(function(e, f) {
            var g = {};
            Zh(c.l, c.wa, ["pcs", f], (g.chars = f.chars, g.limit = no[f.type], g))
        });
        this.l = a;
        this.root = Rf(a);
        this.wa = b
    }
    to.prototype.Ma = function(a) {
        return a.element
    };

    function uo(a, b, c) {
        var d;
        V(a.l, "P.s." + c, function() {
            d = a.Gb[c].call(a, b)
        })();
        return d
    }

    function vo(a, b) {
        var c = M({}, b);
        if (a.Id && !c.id && J(b.type, [3, 2])) {
            var d = T(", ", L(db("name"), c.authors || []));
            c.pageTitle = d + ": " + c.pageTitle
        }
        if (!c.pageTitle) {
            a: {
                d = c.Db;
                for (var e = 1; 5 >= e; e += 1) {
                    var f = qo(Bj("h" + e, d));
                    if (f) {
                        d = f;
                        break a
                    }
                }
                d = void 0
            }
            c.pageTitle = d
        }
        c.pageUrlCanonical || (d = c.id, d = ("string" !== typeof d ? 0 : /^(https?:)\/\//.test(d)) ? c.id : (d = Bj('[rel="canonical"]', a.root)) ? d.href : void 0, c.pageUrlCanonical = d);
        c.id || (c.id = c.pageTitle || c.pageUrlCanonical);
        return c
    }
    to.prototype.Da = function(a) {
        var b = this,
            c = {},
            d = this.Ma(a);
        if (!d) return null;
        c.type = a.type;
        L(function(f) {
            c[f] = uo(b, a, f)
        }, cc(this.Gb));
        var e = Ed(this.l);
        c.stamp = e(Dd);
        c.element = a.element;
        c.Db = d;
        c = this.ai(vo(this, c));
        c.id = c.id ? Yj(c.id) : 1;
        c.update = function(f) {
            return b.Ma(a) ? uo(b, a, f) : void 0
        };
        return c
    };
    to.prototype.getType = function() {
        return 1
    };
    to.prototype.qc = function() {
        return []
    };

    function io(a) {
        var b = a.qc(),
            c = 1;
        return F(function(d, e) {
            var f = a.Da({
                element: e,
                type: a.getType(e)
            }) || [];
            K(f) || (f = [f]);
            f = F(function(g, h) {
                var k = g.values,
                    l = g.bf;
                h && h.chars > no[h.type] && !J(h.id, l) ? (k.push(h), l.push(h.id)) : h && h.chars <= no[h.type] && a.xg(h.id, h);
                return {
                    values: k,
                    bf: l
                }
            }, {
                values: [],
                bf: L(db("id"), d)
            }, f).values;
            return d.concat(L(function(g) {
                var h = {};
                g = M((h.index = c, h.Kf = !1, h.involvedTime = 0, h), g);
                c += 1;
                return g
            }, f))
        }, [], b)
    }

    function wo() {
        to.apply(this, arguments);
        this.id = "j";
        this.Id = !0;
        this.Le = T(",", ['script[type="application/ld+json"]', 'script[type="application/json+ld"]', 'script[type="ld+json"]', 'script[type="json+ld"]']);
        var a = {};
        this.Gb = (a.id = function(b) {
            var c = b.data["@id"];
            b = b.data.mainEntity || b.data.mainEntityOfPage;
            !c && Sa(b) && (c = b["@id"]);
            return c
        }, a.chars = function(b) {
            var c = b.data;
            return y(c.text) ? c.text.length : If(this.Ma(b)).length
        }, a.authors = function(b) {
            b = b.data;
            var c = [];
            c = c.concat(xo(b, "author"));
            c = c.concat(xo(b.mainEntity,
                "author"));
            return c.concat(xo(b.mainEntityOfPage, "author"))
        }, a.pageTitle = function(b) {
            var c = b.data,
                d = c.headline || "";
            c.alternativeHeadline && (d += " " + c.alternativeHeadline);
            "" === d && (c.name ? d = c.name : c.itemReviewed && (d = c.itemReviewed));
            3 === b.type && Sa(c.parentItem) && (d = c.parentItem.text);
            return d
        }, a.updateDate = function(b) {
            return b.data.dateModified || ""
        }, a.publicationDate = function(b) {
            return b.data.datePublished || ""
        }, a.pageUrlCanonical = function(b) {
            return b.data.url
        }, a.topics = function(b) {
            return xo(b.data, "about", ["name", "alternateName"])
        }, a.rubric = function(b) {
            var c = this,
                d = this.Ma(b);
            b = ob(L(function(e) {
                e = xf(c.l, If(e));
                if (Sa(e) || K(e)) {
                    var f = yo(e);
                    if (f) return F(function(g, h) {
                        return g ? g : Sa(h) && "BreadcrumbList" === h["@type"] ? h : g
                    }, null, f);
                    if ("BreadcrumbList" === e["@type"]) return e
                }
                return null
            }, [b.element].concat(Aj(this.Le, document.body === d ? document.documentElement : d))));
            return b.length && (b = b[0].itemListElement, K(b)) ? ob(L(function(e) {
                return Sa(e) && e.item && Sa(e.item) && !c.l.isNaN(e.position) ? {
                    name: e.item.name || e.name,
                    position: e.position
                } : null
            }, b)) : []
        }, a)
    }
    ka(wo, to);

    function xo(a, b, c) {
        c = void 0 === c ? ["name"] : c;
        if (!Sa(a) || !a[b]) return [];
        a = a[b];
        a = K(a) ? a : [a];
        a = ob(L(function(d) {
            return d ? "string" === typeof d ? d : Sa(d) ? F(function(e, f) {
                return e || "" + d[f]
            }, "", c) : null : null
        }, a));
        return L(function(d) {
            var e = {};
            return e.name = d, e
        }, a)
    }
    wo.prototype.Ma = function(a) {
        var b = a.element,
            c = a.data || {};
        a = c["@id"];
        var d = c.url;
        c = null;
        d && y(d) && (c = zo(this, d));
        !c && a && y(a) && (c = zo(this, a));
        c || (c = a = b.parentNode, !Ej("head", this.l, b) && a && 0 !== If(a).length) || (c = this.l.document.body);
        return c
    };

    function zo(a, b) {
        try {
            var c = qh(a.l, b).hash;
            if (c) {
                var d = Bj(c, a.l.document.body);
                if (d) return d
            }
        } catch (e) {}
        return null
    }
    wo.prototype.Da = function(a) {
        var b = this,
            c = a.element,
            d = a.data;
        if (!d && (d = xf(this.l, If(c)), !d || !/schema\.org/.test(d["@context"]) && !K(d))) return null;
        var e = yo(d);
        if (e) return L(function(g) {
            return Sa(g) && J(g["@type"], b.tb["schema.org"]) ? to.prototype.Da.call(b, {
                element: c,
                data: g,
                type: b.Wb[g["@type"]] || 1
            }) : null
        }, e);
        a.data = d;
        if ("QAPage" === a.data["@type"]) {
            var f = a.data.mainEntity || a.data.mainEntityOfPage;
            if (!f) return null
        }
        "Question" === a.data["@type"] && (f = a.data);
        return f ? (a = Jb(E(f, I), ["acceptedAnswer", "suggestedAnswer"]),
            L(function(g) {
                if (!Sa(g) || !J(g["@type"], b.tb["schema.org"])) return null;
                var h = {};
                g = {
                    element: c,
                    type: b.Wb[g["@type"]] || 1,
                    data: M((h.parentItem = f, h), g)
                };
                return to.prototype.Da.call(b, g)
            }, a)) : J(a.data["@type"], this.tb["schema.org"]) ? to.prototype.Da.call(this, M(a, {
            type: this.Wb[a.data["@type"]] || 1
        })) : null
    };
    wo.prototype.qc = function() {
        return Aj(this.Le, this.root)
    };

    function yo(a) {
        if (K(a)) return a;
        if (a && K(a["@graph"])) return a["@graph"]
    }

    function Ao() {
        to.apply(this, arguments);
        this.id = "s";
        this.Id = !0;
        this.Zh = Wa("exec", new RegExp("schema.org\\/(" + T("|", cc(this.Wb)) + ")$"));
        var a = {};
        this.Gb = (a.id = function(b) {
            b = b.element;
            var c = po(this.l, b, "identifier");
            return c ? qo(c) : (c = po(this.l, b, "mainEntityOfPage")) && c.getAttribute("itemid") ? c.getAttribute("itemid") : null
        }, a.chars = function(b) {
            var c = 0;
            b = b.element;
            for (var d = ["articleBody", "reviewBody", "recipeInstructions", "description", "text"], e = 0; e < d.length; e += 1) {
                var f = po(this.l, b, d[e]);
                if (f) {
                    c = qo(f).length;
                    break
                }
            }
            b = If(b);
            0 === c && b && (c += b.length);
            return c
        }, a.topics = function(b) {
            var c = this,
                d = oo(this.l, b.element, "about");
            return L(function(e) {
                var f = {
                    name: qo(e)
                };
                if (d = po(c.l, e, "name")) f.name = qo(d);
                return f
            }, d)
        }, a.rubric = function(b) {
            var c = this;
            (b = Bj('[itemtype$="schema.org/BreadcrumbList"]', b.element)) || (b = Bj('[itemtype$="schema.org/BreadcrumbList"]', this.root));
            return b ? L(function(d) {
                return {
                    name: qo(po(c.l, d, "name")),
                    position: qo(po(c.l, d, "position"))
                }
            }, oo(this.l, b, "itemListElement")) : []
        }, a.updateDate = function(b) {
            return (b =
                po(this.l, b.element, "dateModified")) ? ro(b) : ""
        }, a.publicationDate = function(b) {
            return (b = po(this.l, b.element, "datePublished")) ? ro(b) : ""
        }, a.pageUrlCanonical = function(b) {
            b = oo(this.l, b.element, "url");
            if (b.length) {
                var c = b[0];
                return c.href ? c.href : qo(b)
            }
            return null
        }, a.pageTitle = function(b) {
            var c = "",
                d = b.element,
                e = po(this.l, d, "headline");
            e && (c += qo(e));
            (e = po(this.l, d, "alternativeHeadline")) && (c += " " + qo(e));
            "" === c && ((e = po(this.l, d, "name")) || (e = po(this.l, d, "itemReviewed")), e && (c += qo(e)));
            3 === b.type && (b = Ej('[itemtype$="schema.org/Question"]',
                this.l, d)) && (b = po(this.l, b, "text")) && (c += qo(b));
            return c
        }, a.authors = function(b) {
            var c = this;
            b = oo(this.l, b.element, "author");
            return L(function(d) {
                var e = {};
                e = (e.name = "", e);
                if (/.+schema.org\/(Person|Organization)/.test(d.getAttribute("itemtype") || "")) {
                    var f = po(c.l, d, "name");
                    f && (e.name = qo(f))
                }
                e.name || (e.name = d.getAttribute("content") || If(d) || d.getAttribute("href"));
                return e
            }, b)
        }, a)
    }
    ka(Ao, to);
    Ao.prototype.getType = function(a) {
        a = a.getAttribute("itemtype") || "";
        return (a = this.Zh(a)) ? this.Wb[a[1]] : 1
    };
    Ao.prototype.Da = function(a) {
        return a.element && If(a.element).length ? to.prototype.Da.call(this, a) : null
    };
    Ao.prototype.qc = function() {
        var a = T(",", L(function(b) {
            return '[itemtype$="schema.org/' + b + '"]'
        }, this.tb["schema.org"]));
        return Aj(a, this.root)
    };

    function Bo(a, b) {
        to.call(this, a, b);
        this.id = "o";
        var c = {};
        this.Gb = (c.chars = function(d) {
            d = this.Ma(d);
            return If(d).length
        }, c.authors = function(d) {
            return Co(d.data.author)
        }, c.pageTitle = function(d) {
            return Do(d.data.title) || ""
        }, c.updateDate = function(d) {
            return Do(d.data.modified_time)
        }, c.publicationDate = function(d) {
            return Do(d.data.published_time)
        }, c.pageUrlCanonical = function(d) {
            return Do(d.data.url)
        }, c.rubric = function(d) {
            return Co(d.data.section)
        }, c.topics = function(d) {
            return Co(d.data.tag)
        }, c);
        this.Ig = new RegExp("^(og:)?((" +
            T("|", this.tb.nf) + "):)?")
    }
    ka(Bo, to);

    function Co(a) {
        if (a) {
            if (K(a)) return L(function(c) {
                var d = {};
                return d.name = c ? "" + c : null, d
            }, a);
            var b = {};
            return [(b.name = a ? "" + a : null, b)]
        }
        return []
    }

    function Do(a) {
        return K(a) ? a.length ? "" + a[0] : null : a ? "" + a : null
    }
    Bo.prototype.qc = function() {
        var a = Aj('meta[property="og:type"]', this.l.document.body);
        return [this.l.document.head].concat(a)
    };

    function Eo(a, b) {
        var c = b.element,
            d = {},
            e = a.Ma(b);
        c = Aj("meta[property]", c === a.l.document.head ? c : e);
        if (c.length) L(function(f) {
            try {
                if (f.parentNode === e || f.parentNode === a.l.document.head) {
                    var g = f.getAttribute("property").replace(a.Ig, ""),
                        h = qo(f);
                    d[g] ? K(d[g]) ? d[g].push(h) : d[g] = [d[g], h] : d[g] = h
                }
            } catch (k) {
                mf(a.l, "og.ed", k)
            }
        }, c);
        else return null;
        return J(d.type, a.tb.nf) ? M(b, {
            data: d
        }) : null
    }
    Bo.prototype.Ma = function(a) {
        a = a.element;
        var b = this.l.document;
        return a === b.head ? b.body : a.parentNode
    };
    Bo.prototype.Da = function(a) {
        return (a = Eo(this, a)) ? to.prototype.Da.call(this, a) : null
    };

    function Fo(a, b, c, d, e) {
        d = Nh(a, c, d);
        b = lh(a, e || c, b);
        var f = cf(a, d, b);
        return function(g) {
            g = M({
                N: {
                    ea: ["mms." + c]
                }
            }, g);
            return f(g)
        }
    }
    var Go = "et w v z i u vf".split(" "),
        Ho = {};
    wo && (Ho.json_ld = wo);
    Ao && (Ho.schema = Ao, Ho.microdata = Ao);
    Bo && (Ho.opengraph = Bo);
    var Io = W("p.p", function(a, b) {
        function c(l) {
            var m = M({}, k);
            m.N.ba = l;
            return e(m)["catch"](V(a, "s.ww.p"))
        }
        var d = $n(a, "9", "8");
        if (!wa("querySelectorAll", a.document.querySelectorAll) || !d) return Q.resolve();
        var e = Fo(a, b, "p", ["f", "x"], [
                [Vg(Go), 1],
                [co, 1]
            ]),
            f = Le(),
            g = Gf(a, b.id),
            h = g.C("pai");
        h && (g.kc("pai"), f.D("pai", h));
        g = {};
        var k = {
            H: (g["wv-type"] = d.type, g),
            K: f,
            N: {}
        };
        return Wh(b, V(a, "ps.s", function(l) {
            if (l = I(l, "settings.publisher.schema")) {
                Ki(b) && (l = "microdata");
                var m = Ho[l];
                if (m && d) {
                    var p = N(b);
                    m = new m(a, p);
                    m = new go(a, m, d, c, p);
                    m.start();
                    var r = {};
                    Zh(a, p, "ps", (r.schema = l, r));
                    return C(m.stop, m)
                }
            }
        }))
    });

    function Jo(a) {
        var b = Ko;
        this.type = "0";
        this.l = a;
        this.Vg = b
    }
    n = Jo.prototype;
    n.Ha = function(a) {
        return Ag(Jb(C(this.ub, this), a))
    };
    n.ub = function(a, b) {
        var c = this,
            d = [],
            e = this.Vg(this.l, b && b.type, a.type);
        e && (d = Jb(function(f) {
            return f({
                l: c.l,
                na: a
            }) || []
        }, e));
        return d
    };
    n.lb = function(a) {
        return a.length
    };
    n.ne = function(a) {
        return [a]
    };
    n.isEnabled = function() {
        return !0
    };

    function Lo(a, b, c) {
        this.Me = 0;
        this.ae = 1;
        this.Xc = 5E3;
        this.l = a;
        this.ja = b;
        this.Sb = c
    }
    Lo.prototype.Rc = function() {
        this.Me = X(this.l, G(C(this.flush, this), C(this.Rc, this)), this.Xc, "b.f")
    };
    Lo.prototype.send = function(a, b) {
        var c = this.Sb(a, b || [], this.ae);
        this.ae += 1;
        return c
    };
    Lo.prototype.push = function() {};
    Lo.prototype.flush = function() {};

    function Mo(a, b, c) {
        Lo.call(this, a, b, c);
        this.buffer = [];
        this.bg = 7500;
        this.Xc = 3E4;
        this.Rc()
    }
    ka(Mo, Lo);
    Mo.prototype.push = function(a, b) {
        var c = this.ja.ub(a, b);
        Pe(this.buffer, c);
        this.ja.lb(this.buffer) > this.bg && this.flush()
    };
    Mo.prototype.flush = function() {
        var a = this.buffer;
        a.length && (this.send(a), this.buffer = [])
    };
    var No = /opera mini/i;

    function Oo(a, b) {
        var c = Ae(a),
            d = c.C("visorc");
        J(d, ["w", "b"]) || (d = "");
        xe(a) && re(a, "visorc") && !No.test(Bb(a) || "") || (d = "b");
        var e = I(b, "settings.webvisor.recp");
        if (!a.isFinite(e) || 0 > e || 1 < e) d = "w";
        d || (d = O(a).C("hitId") % 1E4 / 1E4 < e ? "w" : "b");
        c.D("visorc", d, 30);
        return "w" === d
    }
    var Po = ["phone", "email"],
        Qo = "first(-|\\.|_|\\s){0,2}name last(-|\\.|_|\\s){0,2}name zip postal address passport (bank|credit)(-|\\.|_|\\s){0,2}card card(-|\\.|_|\\s){0,2}number card(-|\\.|_|\\s){0,2}holder cvv card(-|\\.|_|\\s){0,2}exp card(-|\\.|_|\\s){0,2}name card.*month card.*year card.*month card.*year password birth(-|\\.|_|\\s){0,2}(day|date) second(-|\\.|_|\\s){0,2}name third(-|\\.|_|\\s){0,2}name patronymic middle(-|\\.|_|\\s){0,2}name birth(-|\\.|_|\\s){0,2}place house street city flat state contact.*".split(" "),
        Ro = /^[\w\u0410-\u042f\u0430-\u044f]$/,
        So = [65, 90],
        To = [97, 122];

    function Uo(a, b) {
        if (Ra(b)) return !1;
        if (Hf(b)) {
            var c = b.parentNode;
            return (Ra(c) ? 0 : 11 === c.nodeType) ? !1 : Uo(a, b.parentNode)
        }
        c = Pf(a);
        if (!c) return !1;
        var d = c.call(b, ".ym-hide-content,.ym-hide-content *");
        return d && c.call(b, ".ym-show-content,.ym-hide-content .ym-show-content *") ? !1 : d
    }

    function Vo(a, b) {
        return T("", L(function(c) {
            if (!a.isNaN(c)) return "" + Xd(a, 0, 9);
            if (Ro.test(c)) {
                var d = q(c.toUpperCase() === c ? So : To);
                c = d.next().value;
                d = d.next().value;
                return String.fromCharCode(Xd(a, c, d))
            }
            return c
        }, b.split("")))
    }
    var Wo = "color radio checkbox date datetime-local email month number password range search tel text time url week".split(" "),
        Xo = new RegExp("(" + Qo.join("|") + ")", "i"),
        Yo = new RegExp("(" + Po.join("|") + ")", "i"),
        Zo = ["password", "passwd", "pswd"],
        $o = new RegExp("(" + Qo.concat("\u0438\u043c\u044f \u0444\u0430\u043c\u0438\u043b\u0438\u044f \u043e\u0442\u0447\u0435\u0441\u0442\u0432\u043e \u0438\u043d\u0434\u0435\u043a\u0441 \u0442\u0435\u043b\u0435\u0444\u043e\u043d \u0430\u0434\u0440\u0435\u0441 \u043f\u0430\u0441\u043f\u043e\u0440\u0442 \u043d\u043e\u043c\u0435\u0440(-|\\.|_|\\s){0,2}\u043a\u0430\u0440\u0442\u044b \u0434\u0430\u0442\u0430(-|\\.|_|\\s){0,2}\u0440\u043e\u0436\u0434\u0435\u043d\u0438\u044f \u0434\u043e\u043c \u0443\u043b\u0438\u0446\u0430 \u043a\u0432\u0430\u0440\u0442\u0438\u0440\u0430 \u0433\u043e\u0440\u043e\u0434 \u043e\u0431\u043b\u0430\u0441\u0442\u044c".split(" ")).join("|") + ")",
            "i");

    function ap(a) {
        return a && Of("(ym-disable-submit|-metrika-noform)", a)
    }

    function bp(a) {
        try {
            var b = Yf(a);
            if (J(b, hg)) {
                if ("INPUT" === b) {
                    var c = a.type;
                    return !c || J(c.toLocaleLowerCase(), Wo)
                }
                return !0
            }
        } catch (d) {}
        return !1
    }

    function cp(a) {
        return !!(a && 2 < a.length)
    }

    function dp(a, b) {
        var c = a && (Na(a.className, "ym-disable-keys") || Na(a.className, "-metrika-nokeys"));
        return b && a ? c || !!Nj(a).length : c
    }

    function ep(a) {
        return $f(a) ? "password" === a.type || a.name && J(a.name.toLowerCase(), Zo) || a.id && J(a.id.toLowerCase(), Zo) : !1
    }

    function fp(a, b) {
        return ep(b) || dp(b) ? !0 : Uo(a, b)
    }

    function gp(a, b, c) {
        c = void 0 === c ? !1 : c;
        if (!b) return {
            Wa: !1,
            hb: !1,
            qb: !1
        };
        var d = b.getAttribute("type") || b.type;
        if ("button" === d) return {
            Wa: !1,
            hb: !1,
            qb: !1
        };
        var e = nb(cp, [b.className, b.id, b.name]),
            f = b && Of("ym-record-keys", b);
        d = d && J(d, Po) || Ob(Xa(Yo), e);
        var g;
        (g = d) || (g = b.placeholder, g = Ob(Xa(Xo), e) || cp(g) && $o.test(g || ""));
        e = g;
        return {
            Wa: !f && (fp(a, b) || e && c || e && !d && !c),
            hb: f,
            qb: e
        }
    }
    var hp = xa(Array.prototype.reverse, "reverse");

    function ip(a) {
        for (var b = [], c = a.length - 1; 0 <= c; --c) b[a.length - 1 - c] = a[c];
        return b
    }
    var jp = hp ? function(a) {
            return hp.call(a)
        } : ip,
        kp = "metrikaId_" + Math.random(),
        lp = {
            counter: 0
        },
        mp = x(function() {
            var a = {};
            return a.A = 1, a.ABBR = 2, a.ACRONYM = 3, a.ADDRESS = 4, a.APPLET = 5, a.AREA = 6, a.B = 7, a.BASE = 8, a.BASEFONT = 9, a.BDO = 10, a.BIG = 11, a.BLOCKQUOTE = 12, a.BODY = 13, a.BR = 14, a.BUTTON = 15, a.CAPTION = 16, a.CENTER = 17, a.CITE = 18, a.CODE = 19, a.COL = 20, a.COLGROUP = 21, a.DD = 22, a.DEL = 23, a.DFN = 24, a.DIR = 25, a.DIV = 26, a.DL = 27, a.DT = 28, a.EM = 29, a.FIELDSET = 30, a.FONT = 31, a.FORM = 32, a.FRAME = 33, a.FRAMESET = 34, a.H1 = 35, a.H2 = 36, a.H3 = 37, a.H4 = 38, a.H5 =
                39, a.H6 = 40, a.HEAD = 41, a.HR = 42, a.HTML = 43, a.I = 44, a.IFRAME = 45, a.IMG = 46, a.INPUT = 47, a.INS = 48, a.ISINDEX = 49, a.KBD = 50, a.LABEL = 51, a.LEGEND = 52, a.LI = 53, a.LINK = 54, a.MAP = 55, a.MENU = 56, a.META = 57, a.NOFRAMES = 58, a.NOSCRIPT = 59, a.OBJECT = 60, a.OL = 61, a.OPTGROUP = 62, a.OPTION = 63, a.P = 64, a.PARAM = 65, a.PRE = 66, a.Q = 67, a.S = 68, a.SAMP = 69, a.SCRIPT = 70, a.SELECT = 71, a.SMALL = 72, a.SPAN = 73, a.STRIKE = 74, a.STRONG = 75, a.STYLE = 76, a.SUB = 77, a.SUP = 78, a.TABLE = 79, a.TBODY = 80, a.TD = 81, a.TEXTAREA = 82, a.TFOOT = 83, a.TH = 84, a.THEAD = 85, a.TITLE = 86, a.TR = 87, a.TT = 88,
                a.U = 89, a.UL = 90, a.VAR = 91, a.NOINDEX = 100, a
        }),
        np = [17, 18, 38, 32, 39, 15, 11, 7, 1];

    function op(a, b) {
        var c = Math.max(0, Math.min(b, 65535));
        Pe(a, [c >> 8, c & 255])
    }

    function pp(a, b) {
        Pe(a, [b & 255])
    }

    function qp(a, b, c) {
        return -1 !== Aa(a)(c, np) ? (pp(b, c), !1) : !0
    }

    function Y(a, b) {
        for (var c = Math.max(0, b | 0); 127 < c;) Pe(a, [c & 127 | 128]), c >>= 7;
        Pe(a, [c])
    }

    function rp(a, b) {
        Y(a, b.length);
        for (var c = 0; c < b.length; c += 1) Y(a, b.charCodeAt(c))
    }

    function sp(a, b) {
        var c = b;
        255 < c.length && (c = c.substr(0, 255));
        a.push(c.length);
        for (var d = 0; d < c.length; d += 1) op(a, c.charCodeAt(d))
    }

    function tp(a, b) {
        var c = [];
        if (qp(a, c, 27)) return [];
        Y(c, b);
        return c
    }

    function up(a, b) {
        var c = Yf(b);
        if (!c) return b[kp] = -1, null;
        var d = +b[kp];
        if (!isFinite(d) || 0 >= d) return null;
        if (b.attributes)
            for (var e = b; e;) {
                if (e.attributes.ni) return null;
                e = e.parentElement
            }
        e = 64;
        var f = Jj(a, b),
            g = f && f[kp] ? f[kp] : 0;
        0 > g && (g = 0);
        c = (c || "").toUpperCase();
        var h = mp()[c];
        h || (e |= 2);
        var k = Kj(a, b);
        k || (e |= 4);
        var l = Ij(a, b);
        (f = f ? Ij(a, f) : null) && l[0] === f[0] && l[1] === f[1] && l[2] === f[2] && l[3] === f[3] && (e |= 8);
        lp[d].pf = l[0] + "x" + l[1];
        lp[d].size = l[2] + "x" + l[3];
        b.id && "string" === typeof b.id && (e |= 32);
        f = [];
        if (qp(a, f, 1)) return null;
        Y(f, d);
        pp(f, e);
        Y(f, g);
        h ? pp(f, h) : sp(f, c);
        k && Y(f, k);
        e & 8 || (Y(f, l[0]), Y(f, l[1]), Y(f, l[2]), Y(f, l[3]));
        e & 32 && sp(f, b.id);
        pp(f, 0);
        return f
    }

    function vp(a, b) {
        var c = b[kp];
        if (!c || 0 > c || !fg(b) || !b.form || ap(b.form)) return [];
        var d = Xf(a, b.form);
        if (0 > d) return [];
        if ($f(b)) var e = {
            text: 0,
            color: 0,
            jc: 0,
            ui: 0,
            "datetime-local": 0,
            email: 0,
            mf: 0,
            Fi: 0,
            search: 0,
            Ni: 0,
            time: 0,
            url: 0,
            month: 0,
            Oi: 0,
            password: 2,
            Ei: 3,
            ri: 4,
            file: 6,
            image: 7
        }[b.type];
        else {
            e = {
                ki: 1,
                li: 5
            };
            var f = Yf(b);
            e = B(f) ? "" : e[f]
        }
        if ("number" !== typeof e) return [];
        f = -1;
        for (var g = b.form.elements, h = g.length, k = 0, l = 0; k < h; k += 1)
            if (g[k].name === b.name) {
                if (g[k] === b) {
                    f = l;
                    break
                }
                l += 1
            }
        if (0 > f) return [];
        g = [];
        if (qp(a, g, 7)) return [];
        Y(g, c);
        Y(g, d);
        Y(g, e);
        rp(g, b.name || "");
        Y(g, f);
        return g
    }
    var wp = Kb(E("\u2022", v));

    function xp(a, b, c) {
        var d = b[kp];
        if (d) {
            a: {
                var e = Fd(a),
                    f = b[kp];
                if (0 < f) {
                    var g = [];
                    b = Ij(a, b);
                    var h = lp[f],
                        k = b[0] + "x" + b[1],
                        l = b[2] + "x" + b[3];
                    if (k !== h.pf) {
                        h.pf = k;
                        if (qp(a, g, 9)) {
                            a = [];
                            break a
                        }
                        Y(g, e);
                        Y(g, f);
                        Y(g, b[0]);
                        Y(g, b[1])
                    }
                    if (l !== h.size) {
                        h.size = l;
                        if (qp(a, g, 10)) {
                            a = [];
                            break a
                        }
                        Y(g, e);
                        Y(g, f);
                        Y(g, b[2]);
                        Y(g, b[3])
                    }
                    if (g.length) {
                        a = g;
                        break a
                    }
                }
                a = []
            }
            Pe(c, a)
        }
        return d
    }

    function yp(a, b) {
        var c = void 0 === c ? [] : c;
        for (var d = [], e = b; e && !xp(a, e, c); e = Jj(a, e)) d.push(e);
        L(function(f) {
            lp.counter += 1;
            var g = lp.counter;
            f[kp] = g;
            lp[g] = {};
            g = up(a, f);
            f = vp(a, f);
            g && f && (Pe(c, g), Pe(c, f))
        }, jp(d));
        return c
    }
    var zp = !0;

    function Ap(a) {
        if (!zp) {
            zp = !0;
            a = Fd(a.l);
            var b = [];
            pp(b, 14);
            Y(b, a);
            return b
        }
    }

    function Bp(a) {
        if (zp) {
            zp = !1;
            var b = a.l;
            a = Fd(a.l);
            var c = [];
            qp(b, c, 15) ? b = [] : (Y(c, a), b = c);
            return b
        }
    }

    function Cp(a) {
        var b = a.na;
        if (!zp || b && !b.fromElement) return Ap(a)
    }

    function Dp(a) {
        var b = a.na;
        if (b && !b.toElement) return Bp(a)
    }

    function Ep(a, b) {
        var c = a.l,
            d = [],
            e = b.form;
        if (!b[kp] && e) {
            var f = e.elements;
            e = e.length;
            for (var g = 0; g < e; g += 1) {
                var h = f[g];
                gg(h) && !h[kp] && Pe(d, yp(c, h))
            }
        } else Pe(d, yp(c, b));
        return d
    }

    function Fp(a) {
        var b = Nf(a.na);
        if (b && gg(b)) {
            var c = Ep(a, b),
                d = c.concat;
            var e = a.l;
            a = Fd(a.l);
            var f = [];
            qp(e, f, 17) ? b = [] : (Y(f, a), Y(f, b[kp]), b = f);
            return d.call(c, b)
        }
    }

    function Gp(a) {
        var b = a.l,
            c = a.na.target;
        if (c && gg(c)) {
            b = yp(b, c);
            var d = b.concat;
            var e = a.l;
            a = Fd(a.l);
            var f = [];
            qp(e, f, 18) ? c = [] : (Y(f, a), Y(f, c[kp]), c = f);
            return d.call(b, c)
        }
    }

    function Hp(a) {
        var b = a.l,
            c = Nf(a.na);
        if (!c || ep(c) || dp(c)) return [];
        if (fg(c)) {
            var d = O(b).C("isEU"),
                e = gp(b, c, d),
                f = e.Wa;
            d = e.qb;
            e = e.hb;
            if (eg(c)) var g = c.checked;
            else g = c.value, g = f ? T("", wp(g.split(""))) : g;
            b = yp(b, c);
            f = b.concat;
            var h = a.l;
            a = Fd(a.l);
            var k = [];
            qp(h, k, 39) ? c = [] : (Y(k, a), Y(k, c[kp]), sp(k, String(g)), pp(k, d && !e ? 1 : 0), c = k);
            return f.call(b, c)
        }
    }

    function Ip(a) {
        var b = a.l,
            c = a.na,
            d = Nf(c);
        if (!d || "SCROLLBAR" === d.nodeName) return [];
        var e = [],
            f = E(e, Pe);
        d && gg(d) ? f(Ep(a, d)) : f(yp(b, d));
        var g = Oj(b, c);
        f = e.concat;
        a = Fd(a.l);
        var h = c.type,
            k = [g.x, g.y];
        g = c.which;
        c = c.button;
        var l = q(Hj(b, d)),
            m = l.next().value;
        for (l = l.next().value; d && (!m || !l);)
            if (d = Jj(b, d)) l = q(Hj(b, d)), m = l.next().value, l = l.next().value;
        if (d)
            if (m = d[kp], !m || 0 > m) b = [];
            else {
                l = {};
                var p = (l.mousemove = 2, l.click = 32, l.dblclick = 33, l.mousedown = 4, l.mouseup = 30, l.touch = 12, l)[h];
                p ? (l = [], d = Gj(b, d), qp(b, l, p) ? b = [] :
                    (Y(l, a), Y(l, m), Y(l, Math.max(0, k[0] - d.left)), Y(l, Math.max(0, k[1] - d.top)), /^mouse(up|down)|click$/.test(h) && (b = g || c, pp(l, 2 > b ? 1 : b === (g ? 2 : 4) ? 4 : 2)), b = l)) : b = []
            }
        else b = [];
        return f.call(e, b)
    }
    var Jp = "";

    function Kp(a) {
        var b = null,
            c = a.l,
            d = c.document;
        if (c.getSelection) {
            try {
                var e = c.getSelection()
            } catch (g) {
                return []
            }
            if (Qa(e)) return [];
            var f = "" + e;
            b = e.anchorNode
        } else d.selection && d.selection.createRange && (b = d.selection.createRange(), f = b.text, b = b.parentElement());
        if ("string" !== typeof f) return [];
        try {
            for (; b && 1 !== b.nodeType;) b = b.parentNode
        } catch (g) {
            return []
        }
        if (!b) return [];
        d = gp(c, b).Wa || dp(b, !0);
        b = b.getElementsByTagName("*");
        for (e = 0; e < b.length && !d;) d = b[e], d = gp(c, d).Wa || dp(d, !0), e += 1;
        if (f !== Jp) return Jp = f, b = d ?
            T("", wp(f.split(""))) : f, f = a.l, a = Fd(a.l), 0 === b.length ? b = c = "" : 100 >= b.length ? (c = b, b = "") : 200 >= b.length ? (c = b.substr(0, 100), b = b.substr(100)) : (c = b.substr(0, 97), b = b.substr(b.length - 97)), d = [], qp(f, d, 29) ? a = [] : (Y(d, a), rp(d, c), rp(d, b), a = d), a
    }

    function Lp(a) {
        return Ip(a).concat(Kp(a) || [])
    }

    function Mp(a) {
        return (a.shiftKey ? 2 : 0) | (a.ctrlKey ? 4 : 0) | (a.altKey ? 1 : 0) | (a.metaKey ? 8 : 0) | (a.ctrlKey || a.altKey ? 16 : 0)
    }
    var Np = !1;

    function Op(a) {
        var b = [];
        Np || (Np = !0, Jp && Pe(b, tp(a.l, Fd(a.l))), ai(a.l, function() {
            Np = !1
        }, "fv.c"));
        return b
    }

    function Pp(a, b, c, d) {
        b = Nf(b);
        if (!b || fp(a, b)) return [];
        var e = gp(a, b),
            f = e.qb,
            g = e.hb;
        e = e.Wa;
        var h = O(a);
        if (!g && (f && h.C("isEU") || dp(b))) a = [];
        else {
            f = yp(a, b);
            g = f.concat;
            var k = Fd(a);
            h = [];
            if (qp(a, h, 38)) a = [];
            else {
                Y(h, k);
                op(h, c);
                pp(h, d);
                a = b[kp];
                if (!a || 0 > a) a = 0;
                Y(h, a);
                pp(h, e ? 1 : 0);
                a = h
            }
            a = g.call(f, a)
        }
        return a
    }
    var Qp = !0;

    function Rp(a) {
        var b = a.l,
            c = a.na,
            d = c.keyCode,
            e = Mp(c),
            f = [],
            g = E(f, Pe);
        if ({
                3: 1,
                8: 1,
                9: 1,
                13: 1,
                16: 1,
                17: 1,
                18: 1,
                19: 1,
                20: 1,
                27: 1,
                33: 1,
                34: 1,
                35: 1,
                36: 1,
                37: 1,
                38: 1,
                39: 1,
                40: 1,
                45: 1,
                46: 1,
                91: 1,
                92: 1,
                93: 1,
                106: 1,
                110: 1,
                111: 1,
                144: 1,
                145: 1
            }[d] || 112 <= d && 123 >= d || 96 <= d && 105 >= d || e & 16) 19 === d && 4 === (e & -17) && (d = 144), g(Pp(b, c, d, e | 16)), Qp = !1, ai(b, function() {
            Qp = !0
        }, "fv.kd"), !(67 === d && e & 4) || e & 1 || e & 2 || g(Op(a));
        return f
    }
    var Sp = !1;

    function Tp(a) {
        var b = a.l;
        a = a.na;
        var c = [];
        Qp && !Sp && 0 !== a.which && (Pe(c, Pp(b, a, a.charCode || a.keyCode, Mp(a))), Sp = !0, ai(b, function() {
            Sp = !1
        }, "fv.kp"));
        return c
    }

    function Up(a) {
        var b = a.l,
            c = Nf(a.na);
        if (!c || ap(c)) return [];
        var d = [];
        if ("FORM" === c.nodeName) {
            for (var e = c.elements, f = 0; f < e.length; f += 1) jg(e[f]) || Pe(d, yp(b, e[f]));
            a = Fd(a.l);
            e = Xf(b, c);
            if (0 > e) b = [];
            else {
                f = c.elements;
                var g = f.length;
                c = [];
                for (var h = 0; h < g; h += 1)
                    if (!jg(f[h])) {
                        var k = f[h][kp];
                        k && 0 < k && c.push(k)
                    }
                f = [];
                if (qp(b, f, 11)) b = [];
                else {
                    Y(f, a);
                    Y(f, e);
                    Y(f, c.length);
                    for (b = 0; b < c.length; b += 1) Y(f, c[b]);
                    b = f
                }
            }
            Pe(d, b)
        }
        return d
    }

    function Vp(a) {
        var b = a.flush;
        "BODY" === Yf(Nf(a.na)) && b()
    }
    var Wp = pa(function(a, b) {
        var c = D([a, "efv." + b.event], V);
        b.T = L(G(v, c), b.T);
        return b
    });

    function Xp(a, b) {
        var c = nb(function(e) {
                return 0 < e.T.length
            }, b),
            d = hc({
                target: a.document,
                type: "document"
            });
        return L(G(v, d, Wp(a)), c)
    }
    var Yp = x(function(a) {
            var b = [],
                c = [],
                d = [];
            a.document.attachEvent && !a.opera && (b.push(Bp), c.push(Cp), c.push(Dp));
            a.document.addEventListener ? b.push(Gp) : (c.push(Fp), d.push(Gp));
            return Xp(a, ("onpagehide" in a ? [] : [{
                target: a,
                type: "window",
                event: "beforeunload",
                T: [u]
            }, {
                target: a,
                type: "window",
                event: "unload",
                T: [u]
            }]).concat([{
                event: "click",
                T: [Ip]
            }, {
                event: "dblclick",
                T: [Ip]
            }, {
                event: "mousedown",
                T: [Ip]
            }, {
                event: "mouseup",
                T: [Lp]
            }, {
                event: "keydown",
                T: [Rp]
            }, {
                event: "keypress",
                T: [Tp]
            }, {
                event: "copy",
                T: [Op]
            }, {
                event: "blur",
                T: b
            }, {
                event: "focusin",
                T: c
            }, {
                event: "focusout",
                T: d
            }]).concat(!a.document.attachEvent || a.opera ? [{
                target: a,
                type: "window",
                event: "focus",
                T: [Ap]
            }, {
                target: a,
                type: "window",
                event: "blur",
                T: [Bp]
            }] : []).concat(a.document.addEventListener ? [{
                event: "focus",
                T: [Fp]
            }, {
                event: "change",
                T: [Hp]
            }, {
                event: "submit",
                T: [Up]
            }] : [{
                type: "formInput",
                event: "change",
                T: [Hp]
            }, {
                type: "form",
                event: "submit",
                T: [Up]
            }]))
        }),
        Zp = x(function(a) {
            var b = [];
            Qf(a) && b.push({
                target: a,
                type: "document",
                event: "mouseleave",
                T: [Vp]
            });
            "onpagehide" in a && b.push({
                target: a,
                type: "window",
                event: "pagehide",
                T: [function(c) {
                    c = c.flush;
                    c()
                }]
            });
            return b
        }),
        $p = ["submit", "beforeunload", "unload"],
        aq = x(function(a, b) {
            var c = b(a);
            return F(function(d, e) {
                d[e.type + ":" + e.event] = e.T;
                return d
            }, {}, c)
        }),
        Ko = E(Yp, function(a, b, c, d) {
            return aq(b, a)[c + ":" + d] || []
        }),
        bq = /^\s*function submit\(\)/;

    function cq(a, b) {
        var c = a.document,
            d = [],
            e = ud(a),
            f = ":submit" + Math.random(),
            g = [],
            h = C(b.flush, b),
            k = pa(function(l, m) {
                V(a, "hfv." + l, function() {
                    try {
                        var p = m.type
                    } catch (r) {
                        return
                    }
                    p = J(p, $p);
                    b.push(m, {
                        type: l
                    });
                    p && h()
                })()
            });
        return {
            start: V(a, "sfv", function() {
                var l = Yp(a),
                    m = Zp(a);
                L(function(p) {
                    d.push(e.F(p.target, [p.event], k(p.type)))
                }, l);
                L(function(p) {
                    d.push(e.F(p.target, [p.event], V(a, "hff." + p.type + "." + p.event, function(r) {
                        L(ta({
                            l: a,
                            na: r,
                            flush: h
                        }), p.T)
                    })))
                }, m);
                g = Dj(a, "form", c);
                c.attachEvent && (l = Dj(a, "form *", c),
                    L(function(p) {
                        d.push(e.F(p, ["submit"], k("form")))
                    }, g), L(function(p) {
                        fg(p) && d.push(e.F(p, ["change"], k("formInput")))
                    }, l));
                L(function(p) {
                    var r = p.submit;
                    if (A(r) || "object" === typeof r && bq.test("" + r)) p[f] = r, p.submit = V(a, "fv", function() {
                        var t = {
                            target: p,
                            type: "submit"
                        };
                        k("document")(t);
                        return p[f]()
                    })
                }, g)
            }),
            stop: V(a, "ufv", function() {
                L(Qe, d);
                L(function(l) {
                    l && (l.submit = l[f])
                }, g);
                b.flush()
            })
        }
    }

    function dq(a, b, c) {
        function d() {
            h && h.stop()
        }
        if (!b.zb) return Q.resolve(u);
        var e = Rh(a, "4", b),
            f = {
                K: Le()
            },
            g = new Mo(a, c, function(k, l, m) {
                if (!e) return Q.resolve();
                l = "wv-data=" + zl(k, !0);
                var p = {};
                p["wv-part"] = "" + m;
                m = k.length;
                for (var r = 0, t = 255, w = 255, z, P, R; m;) {
                    z = 21 < m ? 21 : m;
                    m -= z;
                    do P = "string" === typeof k ? k.charCodeAt(r) : k[r], r += 1, 255 < P && (R = P >> 8, P &= 255, P ^= R), t += P, w += t; while (--z);
                    t = (t & 255) + (t >> 8);
                    w = (w & 255) + (w >> 8)
                }
                k = (t & 255) + (t >> 8) << 8 | (w & 255) + (w >> 8);
                return e(M({}, f, {
                    N: {
                        ba: l
                    },
                    H: (p["wv-check"] = "" + (65535 === k ? 0 : k), p["wv-type"] =
                        c.type, p)
                }), b)["catch"](V(a, "m.n.m.s"))
            }),
            h = cq(a, g);
        return Wh(b, function(k) {
            k && O(a).D("isEU", I(k, "settings.eu"));
            O(a).C("oo") || h && Oo(a, k) && h.start();
            return d
        })
    }
    var eq = W("fw.p", function(a, b) {
        var c;
        if (!(c = b.Eg || !b.zb)) {
            var d = O(a),
                e = !1;
            c = d.C("hitParam", {});
            var f = N(b);
            c[f] && (d = d.C("counters", {}), e = Oc(b.ca) && !d[f]);
            c[f] = 1;
            c = e
        }
        return c ? Q.resolve(u) : dq(a, b, new Jo(a))
    });

    function fq(a, b, c, d) {
        d = void 0 === d ? 0 : d;
        Lo.call(this, a, b, c);
        this.ue = this.Bb = this.ve = 0;
        this.buffer = [];
        this.Xc = 2E3;
        this.Z = Dg(a);
        this.Rc();
        this.ue = d
    }
    ka(fq, Lo);

    function gq(a, b) {
        return ob(a.Z.$("ag", b))
    }

    function hq(a, b, c) {
        b(ug(V(a.l, "wv2.b.st"), function(d) {
            a.send(d, c)
        }))
    }

    function iq(a, b, c) {
        rg(a.l, a.Me);
        var d = Math.ceil(a.ja.lb(c) / 63E4),
            e = a.ja.ne(c, d);
        L(function(f, g) {
            var h = {};
            h = M({}, b, (h.data = f, h.partNum = g + 1, h.end = g + 1 === d, h.partsTotal = e.length, h));
            var k = a.ja.Ha([h], !1);
            hq(a, k, [h])
        }, e);
        a.Rc()
    }
    n = fq.prototype;
    n.send = function(a, b) {
        var c = this;
        this.Z.$("se", b);
        return Lo.prototype.send.call(this, a, b).then(v, function() {
            c.Z.$("see", b)
        })
    };

    function jq(a, b, c, d, e, f) {
        fq.$c["" + b + c] || (a.$c[c] = new fq(f, e, d, "m" === c ? 31457280 : 0));
        return a.$c[c]
    }
    n.push = function(a) {
        var b = this;
        if (!(this.ue && this.ve >= this.ue)) {
            this.Z.$("p", a);
            var c = this.ja.ub(a),
                d = this.ja.lb(c);
            7E5 < d ? iq(this, a, c) : (c = gq(this, this.buffer.concat([a])), c = F(function(e, f) {
                return e + b.ja.lb(b.ja.ub(f))
            }, 0, c), this.Bb + c + d >= 7E5 * .7 && this.flush(), this.buffer.push(a), this.Bb += d)
        }
    };
    n.F = function(a, b) {
        this.Z.F([a], b)
    };
    n.ga = function(a, b) {
        this.Z.ga([a], b)
    };
    n.flush = function(a) {
        var b = this.buffer.concat(gq(this, this.buffer));
        b.length && (this.buffer = [], this.ve += this.Bb, this.Bb = 0, a = this.ja.Ha(b, a), hq(this, a, b))
    };
    fq.$c = {};

    function kq(a, b, c, d, e) {
        d = void 0 === d ? 1 : d;
        e = void 0 === e ? "itc" : e;
        b = Rd(b, c);
        ml(a, b, d)(ug(V(a, e), u))
    }

    function lq(a, b, c, d) {
        d = void 0 === d ? "wv2" : d;
        return {
            J: function(e, f) {
                return V(a, d + "." + c + "." + f, e, void 0, b)
            }
        }
    }

    function Z(a, b, c) {
        this.ph = "wv2.c";
        this.rb = [];
        this.ha = [];
        this.l = a;
        this.L = lq(a, this, c, this.ph);
        this.G = b;
        this.Ra = this.G.Zg();
        this.start = this.L.J(this.start, "st");
        this.stop = this.L.J(this.stop, "sp")
    }
    Z.prototype.start = function() {
        var a = this;
        this.rb = L(function(b) {
            var c = q(b);
            b = c.next().value;
            var d = c.next().value;
            c = c.next().value;
            d = C(a.L.J(d, b[0]), a);
            return a.Ra.F(c || a.l, b, d)
        }, this.ha)
    };
    Z.prototype.stop = function() {
        L(Qe, this.rb)
    };
    Z.prototype.Y = function(a) {
        return this.G.xa().Y(a)
    };
    var mq = ["checkbox", "radio"],
        nq = /pwd|value|password/i;

    function oq(a, b, c, d, e, f) {
        f = void 0 === f ? Yf(b) : f;
        var g = {
            pb: !1,
            value: d
        };
        if (bp(b)) "value" === c ? !Ra(d) && "" !== d && (c = e.Kd, f = e.tf, e = Uo(a, b), f ? (c = gp(a, b, c), b = c.qb, a = c.hb, c = c.Wa, g.pb = !a && (e || b)) : (g.pb = e, c = !(b && Of("ym-record-keys", b))), c || e) && (d = "" + d, g.value = 0 < d.length ? pl("\u2022", d.length) : "") : "checked" === c && J((b.getAttribute("type") || "").toLowerCase(), mq) ? g.value = b.checked ? "checked" : null : nq.test(c) && ep(b) && (g.value = null);
        else if ("IMG" === f && "src" === c)(d = Uo(a, b)) ? (g.pb = d, g.value = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=") :
            g.value = (b.getAttribute("srcset") ? b.currentSrc : "") || b.src;
        else if ("A" === f && "href" === c) g.value = d ? "#" : "";
        else if (J(c, ["srcset", "integrity", "crossorigin", "password"]) || 2 < c.length && 0 === La(c, "on") || "IFRAME" === f && "src" === c || "SCRIPT" === f && J(c, ["src", "type"])) g.value = null;
        return g
    }

    function pq(a, b, c) {
        var d = {};
        bp(a) ? d.value = a.value || c.value : "IMG" !== b || c.src || (d.src = "");
        return d
    }

    function qq(a, b, c, d, e) {
        d = void 0 === d ? {} : d;
        e = void 0 === e ? Yf(b) : e;
        var f = M(F(function(h, k) {
            h[k.name] = k.value;
            return h
        }, {}, vb(b.attributes)), d);
        M(f, pq(b, e, f));
        var g = (d = F(function(h, k) {
            var l = q(k),
                m = l.next().value;
            l = l.next().value;
            l = oq(a, b, m, l, c, e);
            var p = l.value;
            Ra(p) ? delete f[m] : f[m] = p;
            return h || l.pb
        }, !1, bc(f))) && Vf(b);
        g && (f.width = g.width, f.height = g.height);
        return {
            pb: d,
            ng: f
        }
    }

    function rq(a, b) {
        if (y(b)) return b;
        var c = a.textContent;
        if (y(c)) return c;
        c = a.data;
        if (y(c)) return c;
        c = a.nodeValue;
        return y(c) ? c : ""
    }
    var sq = db("location.href");

    function tq(a, b, c) {
        Z.call(this, a, b, c);
        this.va = {
            elements: [],
            attributes: []
        };
        this.index = 0;
        this.Xd = this.L.J(this.Xd, "o");
        this.ld = this.L.J(this.ld, "io");
        this.Yc = this.L.J(this.Yc, "ao");
        this.ee = this.L.J(this.ee, "a");
        this.ce = this.L.J(this.ce, "at");
        this.fe = this.L.J(this.fe, "r");
        this.de = this.L.J(this.de, "c");
        this.qa = new a.MutationObserver(this.Xd)
    }
    ka(tq, Z);
    n = tq.prototype;
    n.start = function() {
        this.qa.observe(this.l.document.documentElement, {
            attributes: !0,
            characterData: !0,
            childList: !0,
            subtree: !0,
            attributeOldValue: !0,
            characterDataOldValue: !0
        })
    };
    n.stop = function() {
        this.qa.disconnect()
    };
    n.Yc = function(a) {
        var b = a.target,
            c = a.attributeName,
            d = a.oldValue;
        a = b.getAttribute(c);
        if (a === d) return !1;
        d = Aa(this.l)(b, this.va.elements); - 1 === d && (d = this.va.elements.push(b) - 1, this.va.attributes[d] = {});
        this.va.attributes[d] || (this.va.attributes[d] = {});
        this.va.attributes[d][c] = oq(this.l, b, c, a, this.G.Ib()).value;
        return !0
    };
    n.ld = function(a) {
        function b(g) {
            var h = Aa(c.l)(g, d);
            return -1 === h ? (d.push(g), g = {
                ud: {}
            }, e.push(g), g) : e[h]
        }
        var c = this,
            d = [],
            e = [];
        L(function(g) {
            var h = g.attributeName,
                k = g.removedNodes,
                l = g.oldValue,
                m = g.target,
                p = g.nextSibling,
                r = g.previousSibling;
            switch (g.type) {
                case "attributes":
                    if (c.Yc(g)) {
                        var t = b(m);
                        t.ud[h] || (t.ud[h] = oq(c.l, m, h, l, c.G.Ib()).value)
                    }
                    break;
                case "childList":
                    k && L(function(w) {
                        t = b(w);
                        t.Ue || M(t, {
                            Ue: m,
                            Rg: p ? p : void 0,
                            Sg: r ? r : void 0
                        })
                    }, vb(k));
                    break;
                case "characterData":
                    t = b(m), t.Ve || (t.Ve = l)
            }
        }, a);
        var f =
            this.G.xa();
        L(function(g, h) {
            f.me(g, e[h])
        }, d)
    };
    n.Xd = function(a) {
        var b = this;
        if (sq(this.l)) {
            var c = this.G.stamp();
            this.ld(a);
            L(function(d) {
                var e = d.addedNodes,
                    f = d.removedNodes,
                    g = d.target;
                switch (d.type) {
                    case "childList":
                        f && f.length && b.fe(vb(f), c);
                        e && e.length && b.ee(vb(e), c);
                        break;
                    case "characterData":
                        b.de(g, c)
                }
            }, a);
            this.ce(c)
        } else this.stop()
    };
    n.ce = function(a) {
        var b = this;
        L(function(c, d) {
            var e = uq(b);
            b.G.V("mutation", {
                index: e,
                attributes: b.va.attributes[d],
                target: b.Y(c)
            }, "ac", a)
        }, this.va.elements);
        this.va.elements = [];
        this.va.attributes = []
    };
    n.ee = function(a, b) {
        var c = this,
            d = uq(this);
        this.G.xa().uc({
            nodes: a,
            Qc: function(e) {
                e = L(function(f) {
                    f.node = void 0;
                    return f
                }, e);
                c.G.V("mutation", {
                    index: d,
                    nodes: e
                }, "ad", b)
            }
        })
    };
    n.fe = function(a, b) {
        var c = this,
            d = uq(this),
            e = this.G.xa(),
            f = L(function(g) {
                var h = e.removeNode(g);
                Lk(c.l, g, function(k) {
                    e.removeNode(k)
                });
                return h
            }, a);
        this.G.V("mutation", {
            index: d,
            nodes: f
        }, "re", b)
    };
    n.de = function(a, b) {
        var c = uq(this);
        this.G.V("mutation", {
            value: a.textContent,
            target: this.Y(a),
            index: c
        }, "tc", b)
    };

    function uq(a) {
        var b = a.index;
        a.index += 1;
        return b
    }

    function vq(a, b) {
        var c = this;
        this.oc = [];
        this.gb = [];
        this.Wd = 1;
        this.Je = this.Gf = 0;
        this.Ba = {};
        this.Sa = {};
        this.Hb = [];
        this.Fd = function(e) {
            return c.gb.length ? J(e, c.gb) : !1
        };
        this.removeNode = function(e) {
            var f = c.Y(e),
                g = Yf(e);
            if (g && !B(f)) return g = "NR:" + g.toLowerCase(), c.Fd(g) && c.Z.$(g, {
                data: {
                    node: e,
                    id: f
                }
            }), f
        };
        this.kb = function(e) {
            var f = Yf(e);
            if (f) {
                var g = e.__ym_indexer;
                return g ? g : (g = c.Wd, e.__ym_indexer = g, c.Wd += 1, f = "NA:" + f.toLowerCase(), c.Fd(f) && c.Z.$(f, {
                    data: {
                        node: e,
                        id: g
                    }
                }), g)
            }
            return null
        };
        this.Cf = function() {
            c.Gf =
                X(c.l, G(C(c.aa, c, !1), c.Cf), 50, "i.s")
        };
        this.Af = function() {
            c.Je = X(c.l, G(C(c.dd, c, !1), c.Af), 50, "i.g")
        };
        this.Jh = function(e) {
            null === c.Ba[e] && delete c.Ba[e];
            null === c.Sa[e] && delete c.Sa[e]
        };
        this.l = a;
        var d = lq(a, this, "i");
        this.Z = Dg(a);
        this.options = b;
        this.start = d.J(this.start, "st");
        this.stop = d.J(this.stop, "sp");
        this.Y = d.J(this.Y, "i");
        this.me = d.J(this.me, "o");
        this.uc = d.J(this.uc, "a");
        this.removeNode = d.J(this.removeNode, "r");
        this.aa = d.J(this.aa, "s");
        this.dd = d.J(this.dd, "g")
    }
    n = vq.prototype;
    n.me = function(a, b) {
        var c = this.kb(a);
        Qa(c) || (this.Sa[c] && this.Y(a), this.Sa[c] = b)
    };
    n.F = function(a, b, c) {
        a = "" + b + a;
        this.gb.push(a);
        this.Fd(a) || this.gb.push(a);
        this.Z.F([a], c)
    };
    n.ga = function(a, b, c) {
        var d = "" + b + a;
        this.gb = nb(function(e) {
            return e !== d
        }, this.gb);
        this.Z.ga([d], c)
    };
    n.start = function() {
        this.Cf();
        this.Af()
    };
    n.stop = function() {
        this.flush();
        rg(this.l, this.Je);
        rg(this.l, this.Gf);
        this.oc = [];
        this.Hb = [];
        this.Ba = {};
        this.Sa = {}
    };
    n.uc = function(a) {
        var b = this,
            c = [],
            d = 0,
            e = {
                Qc: a.Qc,
                result: [],
                vc: 0,
                nodes: c
            };
        this.oc.push(e);
        L(function(f) {
            Lk(b.l, f, function(g) {
                var h = b.kb(g);
                Qa(h) || (c.push(g), b.Ba[h] && b.Y(g), b.Ba[h] = {
                    node: g,
                    event: e,
                    Xh: d
                }, d += 1)
            })
        }, a.nodes)
    };
    n.Y = function(a) {
        if (a === this.l) return 0;
        var b = this.kb(a),
            c = this.Ba[b];
        if (Qa(b)) var d = {};
        else(d = this.Sa[b]) ? (this.Sa[b] = null, this.Hb.push(b)) : d = {};
        var e = d.Ue,
            f = d.ud,
            g = d.Ve,
            h = d.Rg,
            k = d.Sg;
        if (c) {
            d = c.event;
            c = c.Xh;
            var l = Jf(this.l) === a;
            h = h || a.nextSibling;
            var m = k || a.previousSibling;
            k = !l && h ? this.kb(h) : null;
            m = !l && m ? this.kb(m) : null;
            l = this.l;
            h = this.options;
            e = this.kb(e || a.parentNode || a.parentElement) || 0;
            var p = f;
            m = void 0 === m ? null : m;
            k = void 0 === k ? null : k;
            p = void 0 === p ? {} : p;
            var r = void 0 === r ? Yf(a) : r;
            if (B(r)) a = void 0;
            else {
                f = {
                    id: b,
                    prev: m !== e ? m : null,
                    next: k !== e ? k : null,
                    parent: e,
                    name: r.toLowerCase(),
                    node: a
                };
                if (Hf(a)) {
                    if (r = rq(a, g), f.attributes = {}, f.content = r)
                        if (a = Uo(l, a)) f.content = "" !== ke(r) ? Vo(l, r) : r, f.hidden = a
                } else r = qq(l, a, h, p, r), g = r.pb, f.attributes = r.ng, g && (f.hidden = g), a.namespaceURI && Na(a.namespaceURI, "svg") && (f.namespace = a.namespaceURI);
                a = f
            }
            if (B(a)) return;
            this.Ba[b] = null;
            this.Hb.push(b);
            d.result[c] = a;
            d.vc += 1;
            d.nodes.length === d.vc && d.Qc(d.result)
        }
        return b
    };
    n.flush = function() {
        this.aa(!0)
    };
    n.dd = function() {
        this.Hb.length && Rd(this.Hb, this.Jh)(Od(this.l, 30))
    };
    n.aa = function(a) {
        var b = this;
        if (sq(this.l)) {
            var c = cc(this.Ba);
            c = F(function(d, e) {
                b.Ba[e] && d.push(b.Ba[e].node);
                return d
            }, [], c);
            c = Rd(c, this.Y);
            a = a ? Md(u) : Pd(this.l, 20);
            c(a);
            this.oc = nb(function(d) {
                return d.vc !== d.result.length
            }, this.oc)
        }
    };
    var wq = ["input", "change", "keyup", "paste", "cut"];

    function xq(a, b, c) {
        Z.call(this, a, b, c);
        this.inputs = {};
        this.nd = !1;
        this.Cc = this.L.J(this.Cc, "ii");
        this.Dc = this.L.J(this.Dc, "ir");
        this.Lc = this.L.J(this.Lc, "ri");
        this.Uc = this.L.J(this.Uc, "ur");
        this.Dd = this.L.J(this.Dd, "ce");
        this.sc = this.L.J(this.sc, "vc")
    }
    ka(xq, Z);
    n = xq.prototype;
    n.start = function() {
        var a = this,
            b = this.G.xa();
        this.nd = yq(this);
        L(function(c) {
            c = c.toLowerCase();
            b.F(c, "NA:", C(a.Cc, a));
            b.F(c, "NR:", C(a.Dc, a))
        }, hg);
        this.rb = [this.Ra.F(this.l.document, wq, C(this.Dd, this)), function() {
            L(function(c) {
                c = c.toLowerCase();
                b.ga(c, "NA:", a.Cc);
                b.ga(c, "NR:", a.Dc)
            }, hg);
            L(a.Uc, cc(a.inputs))
        }]
    };
    n.Uc = function(a) {
        var b = this.inputs[a];
        if (b) {
            if (this.nd) {
                var c = b.Dh;
                b = b.element;
                c && this.l.Object.defineProperty(b, zq(b), c)
            }
            delete this.inputs[a]
        }
    };
    n.Dc = function(a) {
        a && this.Uc(a.data.id)
    };
    n.Cc = function(a) {
        a && (a = a.data, this.Lc(a.node, a.id))
    };

    function zq(a) {
        return eg(a) ? "checked" : "value"
    }
    n.Dd = function(a) {
        if (a = a.target) {
            var b = zq(a);
            this.sc(a[b], a)
        }
    };
    n.sc = function(a, b) {
        var c = this.Y(b),
            d = this.inputs[c];
        if (!d && (d = this.Lc(d, c), !d)) return;
        var e = d;
        c = e.ug;
        var f = e.value,
            g = zq(b),
            h = !a || J(typeof a, ["string", "boolean", "number"]);
        e = this.G.Ib().Kd;
        h && a !== f && (f = oq(this.l, b, g, a, this.G.Ib()).value, c ? this.G.V("event", {
            target: this.Y(b),
            checked: !!a
        }, "change") : (c = gp(this.l, b, e), e = c.hb, this.G.V("event", {
            value: f,
            hidden: c.qb && !e,
            target: this.Y(b)
        }, "change")), d.value = a)
    };
    n.Lc = function(a, b) {
        var c = this;
        if (!bp(a) || "__ym_input_override_test" === a.getAttribute("class") || this.inputs[b]) return null;
        var d = eg(a),
            e = zq(a),
            f = {
                element: a,
                ug: d,
                value: a[e]
            };
        this.inputs[b] = f;
        this.nd && ai(this.l, function() {
            var g = c.l.Object.getOwnPropertyDescriptor(Object.getPrototypeOf(a), e) || {},
                h = c.l.Object.getOwnPropertyDescriptor(a, e) || {},
                k = M({}, g, h);
            if (wa("((set)?(\\s?" + e + ")?)?", k.set)) {
                try {
                    c.l.Object.defineProperty(a, e, M({}, k, {
                        configurable: !0,
                        set: function(l) {
                            c.sc(l, this);
                            return k.set.call(this, l)
                        }
                    }))
                } catch (l) {}
                f.Dh =
                    k
            }
        });
        return f
    };

    function yq(a) {
        var b = !0,
            c = Lf(a.l)("input");
        try {
            c = Lf(a.l)("input");
            c.value = "INPUT_VALUE";
            c.style.setProperty("display", "none", "important");
            c.setAttribute("type", "text");
            c.setAttribute("class", "__ym_input_override_test");
            var d = a.l.Object.getOwnPropertyDescriptor(Object.getPrototypeOf(c), "value") || {},
                e = a.l.Object.getOwnPropertyDescriptor(c, "value") || {},
                f = M({}, d, e);
            a.l.Object.defineProperty(c, "value", M({}, f, {
                configurable: !0,
                set: function(g) {
                    return f.set.call(c, g)
                }
            }));
            "INPUT_VALUE" !== c.value && (b = !1);
            c.value =
                "INPUT_TEST";
            "INPUT_TEST" !== c.value && (b = !1)
        } catch (g) {
            b = !1
        }
        return b
    }

    function Aq(a, b, c) {
        Z.call(this, a, b, c);
        this.Za = {
            width: 0,
            height: 0,
            pageHeight: 0,
            pageWidth: 0,
            orientation: 0
        };
        this.ha.push([
            ["resize"], this.Bh
        ]);
        this.ha.push([
            ["orientationchange"], this.zh
        ])
    }
    ka(Aq, Z);
    Aq.prototype.start = function() {
        Z.prototype.start.call(this);
        this.Ef()
    };
    Aq.prototype.Bh = function() {
        var a = Bq(this);
        if (a.height !== this.Za.height || a.width !== this.Za.width) this.Za = a, Cq(this, a)
    };
    Aq.prototype.zh = function() {
        var a = Bq(this);
        if (this.Za.orientation !== a.orientation) {
            this.Za = a;
            var b = void 0 === b ? this.G.stamp() : b;
            this.G.V("event", {
                width: a.width,
                height: a.height,
                orientation: a.orientation
            }, "deviceRotation", b)
        }
    };

    function Bq(a) {
        var b = a.G.jb(),
            c = q(Tf(a.l)),
            d = c.next().value;
        c = c.next().value;
        b = b.Ad();
        return {
            width: d,
            height: c,
            pageWidth: b ? b.scrollWidth : 0,
            pageHeight: b ? b.scrollHeight : 0,
            orientation: a.G.jb().$g()
        }
    }

    function Cq(a, b, c) {
        c = void 0 === c ? a.G.stamp() : c;
        a.G.V("event", {
            width: b.width,
            height: b.height,
            pageWidth: b.pageWidth,
            pageHeight: b.pageHeight
        }, "resize", c)
    }
    Aq.prototype.Ef = function() {
        var a = Bq(this);
        if (a.height && a.width && a.pageWidth && a.pageHeight) {
            var b = this.Za;
            b.height && b.width && b.pageWidth && b.pageHeight || (this.Za = a);
            Cq(this, a, 0)
        } else X(this.l, C(this.Ef, this), 300)
    };

    function Dq(a) {
        this.index = 0;
        this.xb = {};
        this.l = a
    }

    function Eq(a, b, c, d) {
        d = void 0 === d ? {} : d;
        var e = Ed(a.l),
            f = a.index;
        a.index += 1;
        a.xb[f] = {
            Pa: 0,
            Rb: !1,
            fn: b,
            Zc: [],
            Pd: e(Ad)
        };
        return function() {
            var g = Ha(arguments),
                h = d.Se && !a.xb[f].Rb,
                k = a.xb[f];
            rg(a.l, k.Pa);
            k.Zc = g;
            k.Rb = !0;
            var l = e(Ad);
            if (h || l - k.Pd >= c) b.apply(null, ca(g)), k.Pd = l;
            k.Pa = X(a.l, function() {
                h || (b.apply(null, ca(g)), k.Pd = e(Ad));
                k.Rb = !1;
                k.Zc = []
            }, c, "th")
        }
    }
    Dq.prototype.flush = function() {
        var a = this;
        L(function(b) {
            var c = a.xb[b],
                d = c.Pa,
                e = c.fn,
                f = c.Zc;
            c.Rb && (a.xb[b].Rb = !1, e.apply(null, ca(f)), rg(a.l, d))
        }, cc(this.xb))
    };

    function Fq(a, b, c) {
        Z.call(this, a, b, c);
        this.Sf = [];
        this.Ee = {
            x: 0,
            y: 0
        };
        this.Ca = new Dq(a);
        this.Gc = this.L.J(this.Gc, "o");
        this.ha.push([
            ["scroll"], this.Ch
        ])
    }
    ka(Fq, Z);
    n = Fq.prototype;
    n.start = function() {
        Z.prototype.start.call(this);
        this.G.V("event", {
            x: Math.max(this.l.scrollX, 0),
            y: Math.max(this.l.scrollY, 0),
            page: !0,
            target: -1
        }, "scroll", 0)
    };
    n.stop = function() {
        Z.prototype.stop.call(this);
        this.Ca.flush()
    };
    n.Ch = function(a) {
        if (this.G.jb().df()) this.Gc(a);
        else {
            var b = a.target,
                c = nb(function(d) {
                    return q(d).next().value === b
                }, this.Sf).pop();
            if (c)(0, c[1])(a);
            else c = Eq(this.Ca, C(this.Gc, this), 100, {
                Se: !0
            }), this.Sf.push([b, c]), c(a)
        }
    };
    n.Gc = function(a) {
        var b = this.G.jb().Ad();
        a = a.target;
        var c = this.Jb(a);
        b = b === a || this.l === a || this.l.document === a;
        var d = Math.max(c.left, 0);
        c = Math.max(c.top, 0);
        if (b) {
            if (this.Ee.x === d && this.Ee.y === c) return;
            this.Ee = {
                x: d,
                y: c
            }
        }
        this.G.V("event", {
            x: d,
            y: c,
            page: b,
            target: b ? -1 : this.Y(a)
        }, "scroll")
    };
    n.Jb = function(a) {
        var b = {
            left: 0,
            top: 0
        };
        if (!a) return b;
        if (a.window === a) return {
            top: a.scrollY || 0,
            left: a.scrollX || 0
        };
        var c = a.ownerDocument || a,
            d = a.documentElement,
            e = c.defaultView || c.parentWindow,
            f = c.body;
        return a !== c || (a = this.G.jb().Ad(), a) ? J(a, [d, f]) ? {
            top: a.scrollTop || e.scrollY,
            left: a.scrollLeft || e.scrollX
        } : {
            top: a.scrollTop || 0,
            left: a.scrollLeft || 0
        } : b
    };
    var Gq = ["mousemove", "mousedown", "mouseup", "click"];

    function Hq(a, b, c) {
        Z.call(this, a, b, c);
        this.ha.push([Gq, this.yh]);
        this.Ca = new Dq(a);
        this.Bc = this.L.J(this.Bc, "n");
        this.Rh = this.L.J(Eq(this.Ca, C(this.Bc, this), 100), "t")
    }
    ka(Hq, Z);
    Hq.prototype.stop = function() {
        Z.prototype.stop.call(this);
        this.Ca.flush()
    };
    Hq.prototype.yh = function(a) {
        var b = null;
        try {
            b = a.type
        } catch (c) {
            return
        }
        "mousemove" === b ? this.Rh(a) : this.Bc(a)
    };
    Hq.prototype.Bc = function(a) {
        var b = a.type,
            c = void 0 === a.clientX ? null : a.clientX,
            d = void 0 === a.clientY ? null : a.clientY;
        a = a.target || this.l.document.elementFromPoint(c, d);
        this.G.V("event", {
            x: c || 0,
            y: d || 0,
            target: this.Y(a)
        }, b)
    };
    var Iq = ["focus", "blur"];

    function Jq(a, b, c) {
        Z.call(this, a, b, c);
        this.ha.push([Iq, this.Qg])
    }
    ka(Jq, Z);
    Jq.prototype.Qg = function(a) {
        var b = a.target;
        a = a.type;
        this.G.V("event", {
            target: this.Y(b === this.l ? this.l.document.documentElement : b)
        }, a)
    };
    var Kq = G(x(function(a) {
            var b = xa(a.getSelection, "getSelection");
            return b ? C(b, a) : u
        }), Qe),
        Lq = ["mousemove", "touchmove", "mousedown", "touchdown", "select"],
        Mq = /text|search|password|tel|url/;

    function Nq(a, b, c) {
        Z.call(this, a, b, c);
        this.Gd = !1;
        this.ha.push([Lq, this.fh])
    }
    ka(Nq, Z);
    Nq.prototype.fh = function(a) {
        var b = this.G,
            c = a.type,
            d = a.which;
        a = a.target;
        if ("mousemove" !== c || 1 === d) {
            if ("select" === c) a: {
                if (Mq.test(a.type || "") && (c = this.Y(a), !B(c))) {
                    c = {
                        start: a.selectionStart,
                        end: a.selectionEnd,
                        target: c
                    };
                    break a
                }
                c = void 0
            }
            else a: {
                if ((c = Kq(this.l)) && 0 < c.rangeCount && (c = c.getRangeAt(0) || this.l.document.createRange(), d = this.Y(c.startContainer), a = this.Y(c.endContainer), !B(d) && !B(a))) {
                    c = {
                        start: c.startOffset,
                        end: c.endOffset,
                        startNode: d,
                        endNode: a
                    };
                    break a
                }
                c = void 0
            }
            c && c.start !== c.end ? (this.Gd = !0, b.V("event", c, "selection")) : this.Gd && (this.Gd = !1, b.V("event", {
                start: 0,
                end: 0
            }, "selection"))
        }
    };
    var Oq = {},
        Pq = (Oq.focus = "windowfocus", Oq.blur = "windowblur", Oq.pageshow = "windowfocus", Oq.pagehide = "windowblur", Oq);

    function Qq(a, b, c) {
        Z.call(this, a, b, c);
        this.visibility = null;
        B(this.l.document.hidden) ? B(this.l.document.msHidden) ? B(this.l.document.webkitHidden) || (this.visibility = {
            hidden: "webkitHidden",
            event: "webkitvisibilitychange"
        }) : this.visibility = {
            hidden: "msHidden",
            event: "msvisibilitychange"
        } : this.visibility = {
            hidden: "hidden",
            event: "visibilitychange"
        };
        this.Cd = this.L.J(this.Cd, "fbe");
        this.Ed = this.L.J(this.Ed, "she")
    }
    ka(Qq, Z);
    Qq.prototype.start = function() {
        this.rb = [this.Ra.F(this.l, this.visibility ? [this.visibility.event] : ["focus", "blur"], C(this.Cd, this))];
        "onpagehide" in this.l && this.rb.push(this.Ra.F(this.l, ["pageshow", "pagehide"], C(this.Ed, this), null))
    };
    Qq.prototype.Ed = function(a) {
        this.G.V("event", {}, Pq[a.type])
    };
    Qq.prototype.Cd = function(a) {
        this.visibility ? this.G.V("event", {}, Pq[this.l.document[this.visibility.hidden] ? "blur" : "focus"]) : this.G.V("event", {}, Pq[a.type])
    };

    function Rq() {
        return Math.floor(65536 * (1 + Math.random())).toString(16).substring(1)
    }

    function Sq() {
        return Rq() + Rq() + "-" + Rq() + "-" + Rq() + "-" + Rq() + "-" + Rq() + Rq() + Rq()
    }
    var Tq = ["touchmove", "touchstart", "touchend", "touchcancel", "touchforcechange"];

    function Uq(a, b, c) {
        Z.call(this, a, b, c);
        this.Tc = {};
        this.scrolling = !1;
        this.Df = 0;
        this.ha.push([
            ["scroll"], this.Mh, this.l.document
        ]);
        this.ha.push([Tq, this.Th, this.l.document]);
        this.Ca = new Dq(a);
        this.Mb = this.L.J(this.Mb, "nh");
        this.Sh = this.L.J(Eq(this.Ca, this.Mb, this.G.jb().df() ? 0 : 50, {
            Se: !0
        }), "th")
    }
    ka(Uq, Z);
    Uq.prototype.Mh = function() {
        var a = this;
        this.scrolling = !0;
        rg(this.l, this.Df);
        this.Df = X(this.l, function() {
            a.scrolling = !1
        }, 150)
    };
    Uq.prototype.Th = function(a) {
        var b = this,
            c = "touchcancel" === a.type || "touchend" === a.type;
        a.changedTouches && 0 < a.changedTouches.length && L(function(d) {
            b.Tc[d.identifier] || (b.Tc[d.identifier] = Sq());
            d.__ym_touch_id = b.Tc[d.identifier];
            c && delete b.Tc[d.identifier]
        }, vb(a.changedTouches));
        "touchmove" === a.type ? this.scrolling ? this.Mb(a) : this.Sh(a, this.G.stamp()) : this.Mb(a)
    };
    Uq.prototype.Mb = function(a, b) {
        b = void 0 === b ? this.G.stamp() : b;
        var c = a.type,
            d = L(function(e) {
                return {
                    id: e.__ym_touch_id,
                    x: Math.round(e.clientX),
                    y: Math.round(e.clientY),
                    force: e.force
                }
            }, vb(a.changedTouches));
        0 < d.length && this.G.V("event", {
            touches: d,
            target: this.Y(a.target)
        }, c, b)
    };

    function Vq(a, b, c) {
        Z.call(this, a, b, c);
        this.ha.push([
            ["load"], this.xh, this.l.document
        ])
    }
    ka(Vq, Z);
    Vq.prototype.xh = function(a) {
        a = a.target;
        "IMG" === Yf(a) && a.getAttribute("srcset") && this.G.V("mutation", {
            target: this.Y(a),
            attributes: {
                src: a.currentSrc
            }
        }, "ac")
    };

    function Wq(a, b, c) {
        Z.call(this, a, b, c);
        this.Zf = 1;
        this.Ca = new Dq(a);
        this.cc = this.L.J(this.cc, "z")
    }
    ka(Wq, Z);
    Wq.prototype.start = function() {
        if (Xq(this)) {
            Z.prototype.start.call(this);
            this.cc();
            var a = this.Ra.F(I(this.l, "visualViewport"), ["resize"], Eq(this.Ca, this.cc, 10));
            this.rb.push(a)
        }
    };
    Wq.prototype.stop = function() {
        Z.prototype.stop.call(this);
        this.Ca.flush()
    };
    Wq.prototype.cc = function() {
        var a = Xq(this);
        if (a && a !== this.Zf) {
            this.Zf = a;
            var b = Uf(this.l);
            this.G.V("event", {
                x: b.x,
                y: b.y,
                level: a
            }, "zoom")
        }
    };

    function Xq(a) {
        return (a = Sf(a.l)) ? a[2] : null
    }
    var Yq = {
            91: "super",
            93: "super",
            224: "super",
            18: "alt",
            17: "ctrl",
            16: "shift",
            9: "tab",
            8: "backspace",
            46: "delete"
        },
        Zq = {
            Ki: 1,
            ti: 2,
            alt: 3,
            shift: 4,
            Mi: 5,
            "delete": 6,
            oi: 6
        },
        $q = [4, 9, 8, 32, 37, 38, 39, 40, 46],
        ar = {},
        br = (ar["1"] = {
            91: "&#8984;",
            93: "&#8984;",
            224: "&#8984;",
            18: "&#8997;",
            17: "&#8963;",
            16: "&#8679;",
            9: "&#8677;",
            8: "&#9003;",
            46: "&#9003;"
        }, ar["2"] = {
            91: "&#xff;",
            93: "&#xff;",
            224: "&#xff;",
            18: "Alt",
            17: "Ctrl",
            16: "Shift",
            9: "Tab",
            8: "Backspace",
            46: "Delete"
        }, ar.rh = {
            32: "SPACEBAR",
            37: "&larr;",
            38: "&uarr;",
            39: "&rarr;",
            40: "&darr;",
            13: "Enter"
        }, ar),
        cr = /flash/,
        dr = /ym-disable-keys/,
        er = /^&#/;

    function fr(a, b, c) {
        Z.call(this, a, b, c);
        this.mb = {};
        this.Na = 0;
        this.Ea = [];
        this.Pf = [];
        this.wf = this.lc = 0;
        this.ha.push([
            ["keydown"], this.bh
        ]);
        this.ha.push([
            ["keyup"], this.dh
        ]);
        this.hg = -1 !== Ma(I(a, "navigator.appVersion") || "", "Mac") ? "1" : "2";
        this.zc = this.L.J(this.zc, "v");
        this.pd = this.L.J(this.pd, "ec");
        this.Pc = this.L.J(this.Pc, "sk");
        this.yd = this.L.J(this.yd, "gk");
        this.oe = this.L.J(this.oe, "sc");
        this.bc = this.L.J(this.bc, "cc");
        this.reset = this.L.J(this.reset, "r");
        this.Mc = this.L.J(this.Mc, "rs")
    }
    ka(fr, Z);
    n = fr.prototype;
    n.bh = function(a) {
        if (this.zc(a) && (!a.target || "INPUT" !== a.target.nodeName || !a.shiftKey && 32 !== a.keyCode && "shift" !== Yq[a.keyCode])) {
            var b = a.keyCode;
            a.repeat || this.mb[b] || (this.mb[a.keyCode] = !0, Yq[a.keyCode] && !this.Na ? (this.Na += 1, this.oe(a), this.reset(300)) : this.Na ? (rg(this.l, this.wf), gr(this, a), this.pd()) : (this.reset(), gr(this, a)))
        }
    };
    n.dh = function(a) {
        if (this.zc(a)) {
            var b = a.keyCode,
                c = Yq[a.keyCode];
            this.mb[a.keyCode] && (this.mb[b] = !1);
            c && this.Na && (this.Na = 0, this.mb = {});
            1 === this.Ea.length && (a = q(this.Ea).next().value, J(a.keyCode, $q) && (this.Pc([a], !0), this.reset()));
            this.Ea = nb(G(db("keyCode"), ra(b), Ea), this.Ea);
            rg(this.l, this.lc)
        }
    };
    n.zc = function(a) {
        var b = this.l.document.activeElement;
        b = b && "OBJECT" === b.nodeName && cr.test(b.getAttribute("type") || "");
        a = a.target;
        if (!a) return !b;
        a = "INPUT" === a.nodeName && "password" === a.getAttribute("type") && dr.test(a.className);
        return !b && !a
    };
    n.pd = function() {
        this.Pf = this.Ea.slice(0);
        rg(this.l, this.lc);
        this.lc = X(this.l, E(this.Pf, C(this.Pc, this)), 0, "e.c")
    };
    n.Pc = function(a, b) {
        if (1 < a.length || (void 0 === b ? 0 : b)) {
            var c = this.yd(a);
            this.G.V("event", {
                keystrokes: c
            }, "keystroke")
        }
    };
    n.yd = function(a) {
        var b = this;
        a = L(function(c) {
            c = c.keyCode;
            var d = Yq[c],
                e = br[b.hg][c] || br.rh[c] || String.fromCharCode(c);
            return {
                id: c,
                key: e,
                isMeta: !!d && er.test(e),
                modifier: d
            }
        }, a);
        return sl(function(c, d) {
            return (Zq[c.modifier] || 100) - (Zq[d.modifier] || 100)
        }, a)
    };

    function gr(a, b) {
        J(b, a.Ea) || a.Ea.push(b)
    }
    n.oe = function(a) {
        gr(this, a);
        this.bc()
    };
    n.bc = function() {
        this.Na ? X(this.l, this.bc, 100) : this.Ea = []
    };
    n.reset = function(a) {
        a ? this.wf = X(this.l, C(this.Mc, this), a) : this.Mc()
    };
    n.Mc = function() {
        this.Na = 0;
        this.Ea = [];
        this.mb = {};
        rg(this.l, this.lc)
    };
    var hr = ["sr", "sd", "\u043d"];

    function ir(a) {
        return !B(a.frameId) && !B(a.data)
    }

    function jr(a, b, c) {
        b || md(hf());
        b.postMessage(yf(a, c), "*")
    }

    function kr(a, b) {
        try {
            return Je(G(db("contentWindow"), ra(b)), vb(a.document.querySelectorAll("iframe")))
        } catch (c) {
            return null
        }
    }

    function lr(a, b, c) {
        var d = Dg(a),
            e = ud(a),
            f = xc(a),
            g = b.xd(),
            h = !I(a, "postMessage") || f && !I(a, "parent.postMessage"),
            k = E(d, v);
        if (h) {
            if (!g) return X(a, C(d.$, d, "i", {
                ia: !1
            }), 10), {
                wd: k,
                Ff: u,
                stop: u
            };
            md(hf())
        }
        d.F(["sr"], function(t) {
            if (y(t.origin) && !B(t.source)) {
                var w = kr(a, t.source);
                if (w) {
                    var z = {};
                    jr(a, t.source, (z.type = "\u043d", z.frameId = b.xa().Y(w), z))
                }
            }
        });
        d.F(["sd"], function(t) {
            if (y(t.origin) && !B(t.source)) {
                var w = t.data;
                t = t.source;
                (a === t || kr(a, t)) && d.$("sdr", {
                    data: w.data,
                    frameId: w.frameId
                })
            }
        });
        if (f && !g) {
            var l = !1,
                m = 0,
                p = function() {
                    var t = {};
                    jr(a, a.parent, (t.type = "sr", t));
                    m = X(a, p, 100, "if.i")
                };
            p();
            var r = function(t) {
                if (y(t.origin) && !B(t.source)) {
                    d.ga(["\u043d"], r);
                    rg(a, m);
                    var w = qh(a, t.origin).host;
                    l || t.source !== a.parent || !t.data.frameId || "about:blank" !== U(a).host && !J(w, c) || (l = !0, d.$("i", {
                        frameId: t.data.frameId,
                        ia: !0
                    }))
                }
            };
            d.F(["\u043d"], r);
            X(a, function() {
                d.ga(["\u043d"], r);
                rg(a, m);
                l || (l = !0, d.$("i", {
                    ia: !1
                }))
            }, 2E3, "if.r")
        }
        e = e.F(a, ["message"], function(t) {
            var w = xf(a, t.data);
            w && w.type && J(w.type, hr) && d.$(w.type, {
                data: w,
                source: t.source,
                origin: t.origin
            })
        });
        return {
            wd: k,
            Ff: function(t) {
                var w = {};
                return jr(a, a.parent, (w.frameId = b.xd(), w.data = t, w.type = "sd", w))
            },
            stop: e
        }
    }
    var mr = /allow-same-origin/;

    function nr(a, b, c) {
        Z.call(this, a, b, c);
        this.Ub = [];
        this.vd = {};
        this.Yd = this.L.J(this.Yd, "fi");
        this.Zd = this.L.J(this.Zd, "sd");
        this.$d = this.L.J(this.$d, "src");
        this.qa = new a.MutationObserver(this.$d)
    }
    ka(nr, Z);
    n = nr.prototype;
    n.start = function() {
        Z.prototype.start.call(this);
        this.G.Ib().dc && this.G.xa().F("iframe", "NA:", C(this.Yd, this));
        this.G.We().wd().F(["sdr"], C(this.Zd, this))
    };
    n.stop = function() {
        Z.prototype.stop.call(this);
        L(function(a) {
            a.G.stop()
        }, this.Ub)
    };
    n.$d = function(a) {
        var b = a.pop().target;
        if (a = Je(function(d) {
                return d.cf === b
            }, this.Ub)) {
            this.Ub = nb(function(d) {
                return d.cf !== b
            }, this.Ub);
            var c = a.G.xd();
            try {
                a.G.stop()
            } catch (d) {}
            this.hc(b, c)
        }
    };
    n.Yd = function(a) {
        if (a) {
            var b = a.data.node;
            this.qa.observe(b, {
                attributes: !0,
                attributeFilter: ["src"]
            });
            this.hc(b, a.data.id)
        }
    };
    n.hc = function(a, b) {
        var c = this;
        or(this, a) && Bg(this.l, a)(ug(u, function() {
            var d = c.G.hc(a.contentWindow, b);
            c.Ub.push({
                G: d,
                cf: a
            })
        }))
    };
    n.Zd = function(a) {
        var b = this;
        if (ir(a)) {
            var c = a.frameId;
            a = a.data;
            this.vd[c] || (this.vd[c] = {
                data: []
            });
            var d = this.vd[c];
            d.data = d.data.concat(a);
            this.l.isNaN(d.md) && L(function(e) {
                "page" === e.type && (d.md = e.data.recordStamp - b.G.Xe())
            }, d.data);
            this.l.isNaN(d.md) || (this.G.aa(L(function(e) {
                e.stamp += d.md;
                e.stamp = b.l.Math.max(0, e.stamp);
                return e
            }, d.data)), d.data = [])
        }
    };

    function or(a, b) {
        var c = b.getAttribute("src"),
            d = b.getAttribute("sandbox");
        return b.getAttribute("_ym_ignore") || d && !d.match(mr) || c && "about:blank" !== c && (c = qh(a.l, c).host) && U(a.l).host !== c ? !1 : I(b, "contentWindow.location.href")
    }
    var pr = x(function(a) {
        var b = I(a, "sessionStorage");
        if (!b) return null;
        try {
            var c = b.getItem("__ym_tab_guid");
            b = !1;
            var d = I(a, "opener.sessionStorage");
            try {
                b = !!d && c === d.getItem("__ym_tab_guid")
            } catch (e) {
                b = !0
            }
            if (!c || b) c = Sq(), a.sessionStorage.setItem("__ym_tab_guid", c);
            return c
        } catch (e) {
            return null
        }
    });

    function qr(a, b, c) {
        Z.call(this, a, b, c);
        this.je = this.L.J(this.je, "ps")
    }
    ka(qr, Z);
    qr.prototype.start = function() {
        this.G.xa().uc({
            nodes: [this.l.document.documentElement],
            Qc: this.je
        })
    };
    qr.prototype.je = function(a) {
        var b = this.G.ah(),
            c = b.Ug(),
            d = U(this.l),
            e = d.host,
            f = d.protocol;
        d = d.pathname;
        var g = q(Tf(this.l)),
            h = g.next().value;
        g = g.next().value;
        this.G.V("page", {
            content: L(function(k) {
                k.node = void 0;
                return k
            }, a),
            base: c || "",
            hasBase: !!c,
            viewport: {
                width: h,
                height: g
            },
            title: this.l.document.title,
            doctype: b.Wg() || "",
            address: this.l.location.href,
            ua: this.l.navigator.userAgent,
            referrer: this.l.document.referrer,
            screen: {
                width: this.l.screen.width,
                height: this.l.screen.height
            },
            location: {
                host: e,
                protocol: f,
                path: d
            },
            recordStamp: this.G.Xe(),
            tabId: pr(this.l)
        }, "page", 0)
    };
    var rr = ["addRule", "removeRule", "insertRule", "deleteRule"];

    function sr(a, b, c) {
        Z.call(this, a, b, c);
        this.bb = {};
        this.Vb = {};
        this.Ie = 0;
        this.Ec = this.L.J(this.Ec, "a");
        this.vb = this.L.J(this.vb, "sr");
        this.Fc = this.L.J(this.Fc, "r");
        this.aa = this.L.J(this.aa, "d")
    }
    ka(sr, Z);
    n = sr.prototype;
    n.start = function() {
        var a = this.G.xa();
        a.F("style", "NA:", this.Ec);
        a.F("style", "NR:", this.Fc);
        this.aa()
    };
    n.stop = function() {
        var a = this;
        Z.prototype.stop.call(this);
        var b = this.G.xa();
        b.ga("style", "NA:", this.Ec);
        b.ga("style", "NR:", this.Fc);
        this.aa();
        rg(this.l, this.Ie);
        L(function(c) {
            a.bb[c].sheet && tr(a, a.bb[c].sheet)
        }, cc(this.bb));
        this.bb = {}
    };
    n.aa = function() {
        var a = this;
        L(function(b) {
            b = q(b);
            var c = b.next().value;
            b = b.next().value;
            if (b.length) {
                for (var d = [], e = b[0].stamp, f = [], g = 0; g < b.length; g += 1) {
                    var h = b[g],
                        k = h.stamp;
                    delete h.stamp;
                    k <= e + 50 ? d.push(h) : (f.push(d), e = k, d = [h])
                }
                d.length && f.push(d);
                f.length && L(function(l) {
                    a.G.V("event", {
                        target: Vb(c),
                        changes: l
                    }, "stylechange", e)
                }, f);
                delete a.Vb[c]
            }
        }, bc(this.Vb));
        this.Ie = X(this.l, this.aa, 100)
    };
    n.vb = function(a, b, c, d, e) {
        this.Vb[a] || (this.Vb[a] = []);
        this.Vb[a].push({
            op: b,
            style: void 0 === d ? "" : d,
            index: void 0 === e ? -1 : e,
            stamp: c
        })
    };

    function ur(a, b, c) {
        var d = b.addRule,
            e = b.removeRule,
            f = b.insertRule,
            g = b.deleteRule;
        A(d) && (b.addRule = function(h, k, l) {
            a.vb(c, "a", a.G.stamp(), h + "{" + k + "}", l);
            return d.call(b, h, k, l)
        });
        A(e) && (b.removeRule = function(h) {
            a.vb(c, "r", a.G.stamp(), "", h);
            return e.call(b, h)
        });
        A(f) && (b.insertRule = function(h, k) {
            a.vb(c, "a", a.G.stamp(), h, k);
            return f.call(b, h, k)
        });
        A(g) && (b.deleteRule = function(h) {
            a.vb(c, "r", a.G.stamp(), "", h);
            return g.call(b, h)
        })
    }

    function tr(a, b) {
        L(function(c) {
            var d = a.l.CSSStyleSheet.prototype[c];
            A(d) && (b[c] = C(d, b))
        }, rr)
    }
    n.Ec = function(a) {
        var b = a.data;
        a = b.id;
        b = b.node;
        if (b.sheet && !b.getAttribute("src") && !b.innerText) {
            var c = b.sheet;
            try {
                var d = c.cssRules || c.rules
            } catch (g) {
                d = null
            }
            if (d && d.length) {
                for (var e = [], f = 0; f < d.length; f += 1) e.push({
                    style: d[f].cssText,
                    index: f,
                    op: "a"
                });
                this.G.V("event", {
                    changes: e,
                    target: a
                }, "stylechange")
            }
            ur(this, c, a);
            this.bb[a] = b
        }
    };
    n.Fc = function(a) {
        a = a.data.id;
        var b = this.bb[a];
        b && (delete this.bb[a], b.sheet && tr(this, b.sheet))
    };
    var vr = [
        [sr, "ss"],
        [xq, "in"],
        [tq, "mu"],
        [Aq, "r"],
        [Fq, "sc"],
        [Hq, "mo"],
        [Jq, "f"],
        [Nq, "se"],
        [Qq, "wf"],
        [Uq, "t"],
        [Vq, "src"],
        [Wq, "z"],
        [fr, "ks"]
    ];
    vr.push([nr, "if"]);
    vr.push([qr, "pa"]);
    var wr = x(function(a) {
        var b = a.document;
        return {
            Ad: function() {
                if (b.scrollingElement) return b.scrollingElement;
                var c = 0 === La(b.compatMode, "CSS1") ? b.documentElement : b.body;
                return I(b, "documentElement.scrollHeight") >= I(b, "body.scrollHeight") ? c : null
            },
            $g: function() {
                var c = a.screen;
                if (!c) return 0;
                var d = Je(E(c, I), ["orientation", "mozOrientation", "msOrientation"]);
                return I(c, d + ".angle") || 0
            },
            Ci: E(a, xc),
            df: E(a, rc),
            Bi: E(a, jc)
        }
    });

    function xr(a) {
        return {
            Ug: function() {
                var b = a.document.querySelector("base[href]");
                return b ? b.getAttribute("href") : null
            },
            Wg: function() {
                if (a.document.doctype) {
                    var b = M({
                            name: "html",
                            publicId: "",
                            systemId: ""
                        }, a.document.doctype),
                        c = b.publicId,
                        d = b.systemId;
                    return "<!DOCTYPE " + T("", [b.name, c ? ' PUBLIC "' + c + '"' : "", !c && d ? " SYSTEM" : "", d ? ' "' + d + '"' : ""]) + ">"
                }
                return null
            }
        }
    }

    function yr(a, b) {
        var c = this;
        this.Lb = 0;
        this.ic = [];
        this.Kb = null;
        this.ia = this.Yb = this.Nf = !1;
        this.recordStamp = 0;
        this.stopped = !1;
        this.ah = function() {
            return c.page
        };
        this.xd = function() {
            return c.Lb
        };
        this.Xe = function() {
            return c.recordStamp
        };
        this.Zg = function() {
            return c.Ra
        };
        this.We = function() {
            return c.Kb
        };
        this.xa = function() {
            return c.Hd
        };
        this.stamp = function() {
            return c.te ? c.l.Math.max(c.te(Ad) - c.recordStamp, 0) : 0
        };
        this.Ib = function() {
            return c.options
        };
        this.jb = function() {
            return c.og
        };
        this.V = function(e, f, g, h) {
            h = void 0 ===
                h ? c.stamp() : h;
            e = c.Yg(e, f, g, h);
            c.aa(e)
        };
        this.Yg = function(e, f, g, h) {
            h = void 0 === h ? c.stamp() : h;
            return {
                type: e,
                data: f,
                stamp: h,
                frameId: c.Lb,
                event: g
            }
        };
        this.aa = function(e) {
            e = K(e) ? e : [e];
            c.Nf && !c.Yb ? c.ia ? (e = L(function(f) {
                return f.frameId ? f : M(f, {
                    frameId: c.Lb
                })
            }, e), c.We().Ff(e)) : c.Sb(e) : c.ic = c.ic.concat(e)
        };
        this.l = a;
        var d = lq(a, this, "R");
        this.pe = d.J(this.pe, "s");
        this.aa = d.J(this.aa, "sd");
        d = O(a);
        d.C("wv2e") && jf();
        d.D("wv2e", !0);
        this.options = b;
        this.Ra = ud(a);
        this.Hd = new vq(this.l, b);
        this.og = wr(a);
        this.Ke = L(function(e) {
            var f =
                q(e);
            e = f.next().value;
            f = f.next().value;
            return new e(a, c, f)
        }, vr);
        zr(this);
        this.page = xr(this.l);
        this.pe()
    }
    yr.prototype.start = function(a) {
        this.Nf = !0;
        this.Sb = a;
        a = yb(this.ic);
        this.aa(a)
    };
    yr.prototype.stop = function() {
        this.stopped || (this.stopped = !0, sq(this.l) && (L(function(a) {
            return a.stop()
        }, this.Ke), this.Hd.stop(), this.Kb && this.Kb.stop(), this.ia || this.V("event", {}, "eof")))
    };
    yr.prototype.hc = function(a, b) {
        var c = new yr(a, M({}, this.options, {
            frameId: b
        }));
        c.start(u);
        return c
    };

    function zr(a) {
        a.ia = !!a.options.frameId;
        a.Lb = a.options.frameId || 0;
        a.Yb = !a.ia;
        var b = a.options.Wf || [];
        b.push(U(a.l).host);
        a.Kb = lr(a.l, a, b);
        b = a.Kb.wd();
        xc(a.l) ? a.Yb && b.F(["i"], function(c) {
            if (!1 === c.ia || !0 === c.ia) a.ia = c.ia, a.Yb = !1, c.frameId && (a.Lb = c.frameId), c = yb(a.ic), a.aa(c)
        }) : (a.ia = !1, a.Yb = !1)
    }
    yr.prototype.pe = function() {
        this.te = zd(this.l);
        this.recordStamp = this.te(Ad);
        L(function(a) {
            a.start()
        }, this.Ke);
        this.Hd.start()
    };

    function Ar(a, b, c) {
        var d = this;
        this.bd = this.Nb = !1;
        this.Xa = [];
        this.kf = [];
        this.Oe = [];
        this.send = function(e, f, g) {
            e = d.sender(e, d.Ag);
            f && g && e.then(f, g);
            return e
        };
        this.se = function(e, f, g) {
            return new Q(function(h, k) {
                e.push([f, h, k, g])
            })
        };
        this.gh = function() {
            d.Xa = sl(function(g, h) {
                return g[3].partNum - h[3].partNum
            }, d.Xa);
            var e = F(function(g, h, k) {
                    h = h[3];
                    return g && k + 1 === h.partNum
                }, !0, d.Xa),
                f = !!d.Xa[d.Xa.length - 1][3].end;
            return e && f
        };
        this.sd = function(e) {
            kq(d.l, e.slice(), function(f) {
                var g = q(f);
                f = g.next().value;
                var h =
                    g.next().value;
                g = g.next().value;
                d.send(f, h, g)
            }, 20, "s.w2.sf.fes");
            yb(e)
        };
        this.Pg = function() {
            d.bd || (d.bd = !0, d.sd(d.kf), d.sd(d.Oe))
        };
        this.sg = function(e) {
            return F(function(f, g) {
                var h = "page" === g.type && !g.frameId,
                    k = "eof" === g.data.type || "eof" === g.event,
                    l = h && !!g.partNum;
                return {
                    gd: f.gd || l,
                    fd: f.fd || h,
                    ed: f.ed || k
                }
            }, {
                fd: !1,
                ed: !1,
                gd: !1
            }, e)
        };
        this.eh = function(e, f, g) {
            g ? (e = d.se(d.Xa, e, f[0]), d.gh() && (d.sd(d.Xa), d.Nb = !0)) : (d.Nb = !0, e = d.send(e));
            return e
        };
        this.Ye = function(e, f, g) {
            var h = {};
            f = {
                H: (h["wv-part"] = "" + g, h["wv-type"] =
                    d.Nh, h),
                K: Le(),
                N: {
                    ba: f
                }
            };
            e && f.K.D("bt", 1);
            return f
        };
        this.Kg = function(e, f, g) {
            e = d.Ye(!1, e, g);
            return d.Nb ? d.send(e) : d.se(d.Oe, e, f)
        };
        this.sh = function(e, f, g) {
            e = d.Ye(!0, e, g);
            if (d.Nb) return d.send(e);
            var h = d.sg(f);
            g = h.fd;
            var k = h.ed;
            h = h.gd;
            var l;
            g && (l = d.eh(e, f, h));
            d.bd ? g || (l = d.send(e)) : (g || (l = d.se(d.kf, e, f)), (d.Nb || k) && d.Pg());
            return l
        };
        this.l = a;
        this.Nh = c;
        this.sender = Rh(a, "W", b);
        this.Ag = b
    }

    function Br() {
        var a = F(function(b, c) {
            var d = q(c),
                e = d.next().value;
            d = d.next().value;
            b[e] = {
                cd: 0,
                qg: 1 / d
            };
            return b
        }, {}, [
            ["blur", .0034],
            ["change", .0155],
            ["click", .01095],
            ["deviceRotation", 2E-4],
            ["focus", .0061],
            ["mousemove", .5132],
            ["scroll", .4795],
            ["selection", .0109],
            ["touchcancel", 2E-4],
            ["touchend", .0265],
            ["touchforcechange", .0233],
            ["touchmove", .1442],
            ["touchstart", .027],
            ["zoom", .0014]
        ]);
        return {
            lg: function(b) {
                if (b.length) return {
                    type: "activity",
                    data: F(function(c, d) {
                            var e = a[d];
                            return Math.round(c + e.cd * e.qg)
                        },
                        0, cc(a))
                }
            },
            uh: function(b) {
                b && (b = a[b.data.type || b.event]) && (b.cd += 1)
            }
        }
    }
    var Cr = x(function(a) {
            var b = O(a),
                c = b.C("isEU");
            if (B(c)) {
                var d = Vb(se(a, "is_gdpr") || "");
                if (J(d, [0, 1])) b.D("isEU", d), c = !!d;
                else if (a = Ff(a).C("wasSynced"), a = I(a, "params.eu")) b.D("isEU", a), c = !!a
            }
            return c
        }, function(a) {
            return O(a).C("isEU")
        }),
        Dr = W("i.e", Cr),
        Er = W("i.ep", function(a) {
            Cr(a)
        });

    function Fr(a, b) {
        var c = Ff(a),
            d = "wv2rf:" + N(b),
            e = b.dc,
            f = Dr(a),
            g = c.C(d),
            h = b.Yh;
        return B(f) || Qa(g) ? ta(function(k, l) {
            Wh(b, function(m) {
                var p = !!I(m, "settings.webvisor.forms");
                p = !I(m, "settings.x3") && p;
                f = Dr(a) || I(m, "settings.eu");
                c.D(d, jb(p));
                l({
                    dc: e,
                    Kd: !!f,
                    tf: p,
                    Wf: h
                })
            })
        }) : Ag({
            dc: e,
            Kd: f,
            tf: !!Vb(g),
            Wf: h
        })
    }
    var Gr = W("w2", function(a, b) {
            function c() {
                h = !0
            }
            var d = O(a),
                e = N(b);
            if (!b.zb || ic(a) || !a.MutationObserver || !wa("Element", a.Element)) return u;
            wa("MutationObserver", a.MutationObserver) || Yh(a, e).warn("w2mo");
            var f = ta(function(k, l) {
                    Wh(b, l)["catch"](k)
                }),
                g = Bg(a)(wg(D([a, b], Fr)))(vg(function(k) {
                    return new yr(a, k)
                })),
                h = !1;
            yg([g, f])(ug(V(a, "wv2.R.c"), function(k) {
                k = q(k);
                var l = k.next().value;
                k = k.next().value;
                if (!h) {
                    c = C(l.stop, l);
                    var m = d.C("wv2Counter");
                    if (!Oo(a, k) || m) c();
                    else if (d.D("wv2Counter", e), d.D("stopRecorder",
                            c), k = $n(a, "7", "6")) {
                        m = new Ar(a, b, k.type);
                        var p = jq(fq, e, "m", C(m.sh, m), k, a),
                            r = jq(fq, e, "e", C(m.Kg, m), k, a);
                        "onpagehide" in a ? ud(a).F(a, ["pagehide"], function(w) {
                            w.persisted ? (p.flush(!0), r.flush(!0)) : c()
                        }, null) : ud(a).F(a, ["beforeunload", "unload"], c);
                        k = Br();
                        m = k.uh;
                        r.F("ag", k.lg);
                        r.F("p", m);
                        p.F("see", function(w) {
                            var z = !1;
                            L(function(P) {
                                "page" === P.type && (z = !0)
                            }, w);
                            z && (h || r.push({
                                type: "event",
                                event: "fatalError",
                                data: {
                                    code: "invalid-snapshot",
                                    Lg: "p.s.f",
                                    stack: ""
                                }
                            }), c())
                        });
                        var t = Kb(function(w) {
                            "eof" === I(w, "data.type") ||
                                "eof" === w.event ? (r.push(w), p.push(w), r.flush(!0), p.flush(!0)) : ("event" === w.type ? r : p).push(w)
                        });
                        X(a, c, 864E5);
                        ai(a, function() {
                            var w = {},
                                z = {};
                            Fe(a, (z.counterKey = e, z.name = "webvisor", z.data = (w.version = 2, w), z));
                            l.start(t)
                        })
                    }
                }
            }));
            return function() {
                return c()
            }
        }),
        Hr = W("w2.cs", function(a, b) {
            var c = N(b),
                d = {};
            Ci(a, c, (d.webvisor = !!b.zb, d))
        }),
        Ir = x(Ce, N),
        Jr = G(Mg, Yj),
        Kr = Nc.La + "//" + Lc + "/metrika",
        Lr = Kr + "/metrika_match.html",
        Mr = x(function(a) {
            return {
                wi: a,
                ib: null,
                sb: []
            }
        });

    function Nr(a, b) {
        var c = Mr(Lr);
        J(b, c.sb) || c.sb.push(b);
        if (Qa(c.ib)) {
            var d = Lf(a);
            if (!d) return null;
            d = d("iframe");
            M(d.style, {
                display: "none",
                width: "1px",
                height: "1px",
                visibility: "hidden"
            });
            d.src = Lr;
            var e = Rf(a);
            if (!e) return null;
            e.appendChild(d);
            c.ib = d
        } else(d = I(c.ib, "contentWindow")) && d.postMessage("frameReinit", "*");
        return c.ib
    }

    function Or(a) {
        var b = Mr(Lr);
        J(a, b.sb) && (b.sb = nb(G(ra(a), Ea), b.sb), b.sb.length || (Mf(b.ib), b.ib = null))
    }

    function Pr(a, b, c, d) {
        var e = d.data;
        if (y(e)) {
            var f = q(e.split("*"));
            e = f.next().value;
            var g = f.next().value,
                h = f.next().value;
            f = f.next().value;
            "sc.frame" === e && d.source ? d.source.postMessage(("mf" === a ? "sc.images" : "sc.bl") + "*" + b, "*") : e === ("mf" === a ? "sc.image" : "sc.blr") && g === b.split("?")[0] && c(h, y(f) ? Al(yl(f)) : null)
        }
    }

    function Qr(a, b, c) {
        return new Q(function(d, e) {
            if (Nr(a, "isp")) {
                var f = u,
                    g = function(h, k) {
                        "1" === h ? d({
                            Ga: k,
                            Ae: 0
                        }) : e();
                        f();
                        Or("isp")
                    };
                f = ud(a).F(a, ["message"], D([b, c, g], V(a, "isp.stat.m", Pr)));
                X(a, g, 1500)
            } else e()
        })
    }

    function Rr(a, b, c) {
        var d = Ir(b).Ob,
            e = {};
        return Rh(a, "pi", b)({
            K: Le((e[d] = 1, e))
        }, [c])
    }

    function Sr(a, b, c) {
        if ("rt" === c) return "https://" + Jr(a, b) + ".mc.yandex.ru/watch/3/1";
        if ("mf" === c) {
            c = U(a);
            c = Td(c.protocol + "//" + c.hostname + c.pathname);
            b = Mg(a, b);
            var d = "";
            do d += Xd(a); while (d.length < b.length);
            d = d.slice(0, b.length);
            a = "";
            for (var e = 0; e < b.length; e += 1) a += (b.charCodeAt(e) + d.charCodeAt(e) - 96) % 10;
            a = q([d, a]);
            b = a.next().value;
            return "https://adstat.yandex.ru/track?service=metrika&id=" + a.next().value + "&mask=" + b + "&ref=" + c
        }
    }
    var Tr = Yd("isp", function(a, b) {
            return Wh(b, function(c) {
                if (Fc(a)) {
                    var d = Je(function(g) {
                        return I(c, "settings." + g)
                    }, vl);
                    if (d) {
                        var e = "rt" === d && Bm(c) && !Gm(a);
                        if (!e) {
                            var f = Ir(b);
                            M(f, {
                                Ob: d,
                                status: e ? 3 : 4
                            });
                            if (e = Sr(a, b, d)) return ("rt" === d ? Rr(a, b, e) : Qr(a, d, e)).then(function(g) {
                                g = g.Ga;
                                f.status = 1;
                                "bl" === d && y(g) && (g = I(xf(a, g), "cid")) && (g = zl(Bl(g)), O(a).D("bl", g))
                            })["catch"](function() {
                                f.status = 2
                            })
                        }
                    }
                }
            })["catch"](V(a, "l.isp"))
        }),
        Ur = W("fbq.o", function(a, b, c) {
            var d = I(a, "fbq");
            if (d && d.callMethod) {
                var e = function() {
                    var g =
                        Ha(arguments),
                        h = d.apply(null, ca(g));
                    b(g);
                    return h
                };
                M(e, d);
                c && L(b, c);
                a.fbq = e
            } else var f = X(a, D([a, b].concat(vb(d && d.queue)), Ur), 1E3, "fbq.d");
            return C(rg, null, a, f)
        }),
        Vr = {},
        Wr = (Vr.add_to_wishlist = "add-to-wishlist", Vr.begin_checkout = "begin-checkout", Vr.generate_lead = "submit-lead", Vr.add_payment_info = "add-payment-info", Vr),
        Xr = {},
        Yr = (Xr.AddToCart = "add-to-cart", Xr.Lead = "submit-lead", Xr.InitiateCheckout = "begin-checkout", Xr.Purchase = "purchase", Xr.CompleteRegistration = "register", Xr.Contact = "submit-contact",
            Xr.AddPaymentInfo = "add-payment-info", Xr.AddToWishlist = "add-to-wishlist", Xr.Subscribe = "subscribe", Xr),
        Zr = {},
        $r = (Zr["1"] = Wr, Zr["2"] = Wr, Zr["3"] = Wr, Zr["0"] = Yr, Zr),
        as = [Yr.AddToCart, Yr.Purchase];

    function bs(a, b, c) {
        if (c) {
            var d = c.version;
            (c = I($r, d + "." + c.nc)) && (b && J(c, as) || a("ym-" + c + "-" + d))
        }
    }
    var cs = pa(function(a, b) {
        var c = I(b, "ecommerce"),
            d = I(b, "event") || "";
        if (!(c = c && d && {
                version: "3",
                nc: d
            })) a: {
            if (K(b) || eb(b))
                if (d = q(Ha(b)), c = d.next().value, d = d.next().value, "event" === c && d) {
                    c = {
                        version: "2",
                        nc: d
                    };
                    break a
                }
            c = void 0
        }
        c || (c = (c = I(b, "ecommerce")) && {
            version: "1",
            nc: T(",", cc(c))
        });
        c && a(c)
    });

    function ds(a, b, c) {
        c = q(Ha(c));
        a = c.next().value;
        c = c.next().value;
        "track" === a && b({
            version: "0",
            nc: c
        })
    }
    var es = W("ag.e", function(a, b) {
        if ("0" === b.ca) {
            var c = [],
                d = V(a, "ag.s", D([Qe, c], L));
            Wh(b, function(e) {
                if (I(e, "settings.auto_goals") && fi(a, b) && (e = dj(a, b, "autogoal").reachGoal)) {
                    e = D([e, !!b.od], bs);
                    var f = cs(e);
                    e = D([a, e], ds);
                    c.push(Ur(a, e));
                    c.push(Ek(a, "dataLayer", function(g) {
                        g.qa.F(f)
                    }))
                }
            });
            return d
        }
    });

    function fs(a, b) {
        if (!b) return "";
        var c = [],
            d = I(a, "document");
        Kk(a, b, function(e) {
            if (e.nodeType === d.TEXT_NODE) var f = e.textContent;
            else e instanceof a.HTMLImageElement ? f = e.alt : e instanceof a.HTMLInputElement && (f = e.value);
            (f = f && ke(f)) && c.push(f)
        });
        return 0 === c.length ? "" : T(" ", c)
    }
    var gs = /[^\d.,]/g,
        hs = /[.,]$/;

    function is(a) {
        a = vb(yl(a));
        return L(function(b) {
            b = b.charCodeAt(0).toString(2);
            return ql("0", 8, b)
        }, a)
    }

    function js(a, b) {
        var c = null;
        try {
            c = b ? Bj(b, a) : c
        } catch (d) {}
        return c
    }

    function ks(a, b, c) {
        if (b = fi(a, b)) a = fb(["dr", c || "" + Xd(a, 10, 99)]), b.params(fb(["__ym", a]))
    }
    var ls = W("ep.pp", function(a, b) {
            if (!b) return 0;
            a: {
                var c = b.replace(gs, "").replace(hs, "");
                for (var d = "0" === c[c.length - 1], e = c.length; 0 < e && !(3 < c.length - e + 1 && d); --e) {
                    var f = c[e - 1];
                    if (J(f, [",", "."])) {
                        c = f;
                        break a
                    }
                }
                c = ""
            }
            c = (d = c) ? b.split(d) : [b];
            d = d ? c[1] : "00";
            c = parseFloat(ne(c[0]) + "." + ne(d));
            d = Math.pow(10, 8) - .01;
            a.isNaN(c) ? c = 0 : (c = a.Math.min(c, d), c = a.Math.max(c, 0));
            return c
        }),
        ms = [
            [
                ["EUR", "\u20ac"], "978"
            ],
            [
                ["USD", "\u0423\\.\u0415\\.", "\\$"], "840"
            ],
            [
                ["UAH", "\u0413\u0420\u041d", "\u20b4"], "980"
            ],
            ["\u0422\u0413 KZT \u20b8 \u0422\u04a2\u0413 TENGE \u0422\u0415\u041d\u0413\u0415".split(" "),
                "398"
            ],
            [
                ["GBP", "\u00a3", "UKL"], "826"
            ],
            ["RUR RUB \u0420 \u0420\u0423\u0411 \u20bd P \u0420UB P\u0423\u0411 P\u0423B PY\u0411 \u0420Y\u0411 \u0420\u0423B P\u0423\u0411".split(" "), "643"]
        ],
        ns = x(function(a) {
            return new RegExp(T("|", a), "i")
        }),
        os = x(function() {
            function a() {
                var k = h + "0",
                    l = h + "1";
                f[k] ? f[l] ? (h = h.slice(0, -1), --g) : (e[l] = c(8), f[l] = 1) : (e[k] = c(8), f[k] = 1)
            }

            function b() {
                var k = h + "1";
                f[h + "0"] ? f[k] ? (h = h.slice(0, -1), --g) : (h += "1", f[h] = 1) : (h += "0", f[h] = 1)
            }

            function c(k) {
                k = void 0 === k ? 1 : k;
                var l = d.slice(g, g + k);
                g += k;
                return l
            }
            for (var d = T("", is("Cy2FcreLJLpYXW3BXFJqldVsGMwDcBw2BGnHL5uj1TKstzse3piMo3Osz+EqDotgqs1TIoZvKtMKDaSRFztgUS8qkqZcaETgKWM54tCpTXjV5vW5OrjBpC0jF4mspUBQGd95fNSfv+vz+g+Hze33Hg8by+Yen1PP6zsdl7PQCwX9mf+f7FMb9x/Pw+v2Pp8Xy74eTwuBwTt913u4On1XW6hxOO5nIzFam00tC218S0kaeugpqST+XliLOlMoTpRQkuewUxoy4CT3efWtdFjSAAm+1BkjIhyeU4vGOf13a6U8wzNY4bGo6DIUemE7N3SBojDr7ezXahpWF022y8mma1NuTnZbq8XZZlPStejfG/CsbPhV6/bSnA==")), e = {}, f = {}, g = 1, h = ""; g < d.length - 1;)("0" === c() ? b : a)();
            return e
        }),
        ps = W("ep.dec", function(a, b) {
            if (!b ||
                ic(a)) return [];
            var c = q(is(b)),
                d = c.next().value,
                e = c.next().value,
                f = c.next().value;
            c = ba(c);
            if (2 !== Wb(d)) return [];
            d = os();
            c = T("", c);
            e = Wb(e + f);
            for (var g = f = "", h = 0; g.length < e && c[h];) f += c[h], d[f] && (g += String.fromCharCode(Wb(d[f])), f = ""), h += 1;
            d = xf(a, Al(g));
            return K(d) ? L(Oa, d) : []
        }),
        qs = W("ep.ent", function(a, b, c) {
            a = "" + Xd(a, 10, 99);
            c = "" + 100 * b + c + a;
            if (16 < eb(c)) return "";
            c = ql("0", 16, c);
            b = c.slice(0, 8);
            c = c.slice(-8);
            b = (+b ^ 92844).toString(35);
            c = (+c ^ 92844).toString(35);
            return "" + b + "z" + c
        });

    function rs(a, b) {
        var c = js(a.document.body, b);
        return c ? fs(a, c) : ""
    }

    function ss(a, b) {
        var c = rs(a, b);
        return ls(a, c)
    }
    var ts = G(rs, W("ep.cp", function(a) {
        if (!a) return "643";
        var b = me(a);
        return (a = Je(function(c) {
            c = q(c).next().value;
            return ns(c).test(b)
        }, ms)) ? a[1] : "643"
    }));

    function us(a, b, c, d) {
        (c = qs(a, d, c)) && ks(a, b, c)
    }
    var vs = W("ep.ctp", function(a, b, c, d) {
        var e = ts(a, c),
            f = ss(a, d);
        us(a, b, e, f);
        wa("MutationObserver", a.MutationObserver) && (new a.MutationObserver(function() {
            var g = ts(a, c),
                h = ss(a, d);
            if (e !== g || f !== h) e = g, f = h, us(a, b, e, f)
        })).observe(a.document.body, {
            attributes: !0,
            childList: !0,
            subtree: !0,
            characterData: !0
        })
    });

    function ws(a, b, c, d, e) {
        c = js(a.document.body, c);
        d = js(a.document.body, d);
        J(e.target, [c, d]) && ks(a, b)
    }
    var xs = W("ep.chp", function(a, b, c, d, e) {
        c && ks(a, b);
        return d || e ? ud(a).F(a.document, ["click"], V(a, "ep.chp.cl", D([a, b, d, e], ws))) : u
    });

    function ys(a, b) {
        return Wh(b, function(c) {
            var d = I(c, "settings.dr");
            return {
                Gg: ps(a, d),
                isEnabled: I(c, "settings.auto_goals")
            }
        })
    }

    function zs(a, b) {
        if (!b) return !1;
        var c = U(a);
        return (new RegExp(b)).test("" + c.pathname + c.hash + c.search)
    }
    var As = W("ep.i", function(a, b) {
        if (zj(a)) return ys(a, b).then(function(c) {
            var d = q(c.Gg),
                e = d.next().value,
                f = d.next().value,
                g = d.next().value,
                h = d.next().value,
                k = d.next().value,
                l = d.next().value,
                m = d.next().value,
                p = d.next().value,
                r = d.next().value,
                t = d.next().value,
                w = d.next().value,
                z = d.next().value,
                P = d.next().value,
                R = d.next().value,
                ma = d.next().value,
                Cc = d.next().value;
            if (!c.isEnabled) return Q.resolve(u);
            var Hd = zs(a, e),
                Ze = zs(a, h),
                mu = zs(a, m),
                nu = zs(a, r),
                ou = "" + e + f + g === "" + h + k + l;
            return new Q(function(pu, qu) {
                Bg(a)(ug(qu,
                    function() {
                        Hd && vs(a, b, f, g, w, z, P);
                        Ze && !ou && vs(a, b, k, l, R, ma, Cc);
                        pu(xs(a, b, mu || nu, p, t))
                    }))
            })
        })
    });

    function Bs(a, b) {
        var c = Ff(a),
            d = c.C,
            e = c.D;
        if ("" === d("cc")) {
            e("cc", 0);
            var f = Ed(a),
                g = O(a);
            Rh(a, "6", b)({
                N: {
                    cb: !0,
                    Wc: !1
                }
            }, ["https://mc.yandex.md/cc"]).then(function(h) {
                h = I(h.Ga, "c");
                e("cc", h + "&" + f(Bd));
                g.D("cc", h)
            })["catch"](function(h) {
                var k = f(Bd);
                e("cc", "&" + k);
                mf(a, "cc", h)
            })
        }
    }
    var Cs = W("cc.i", function(a, b) {
        var c = D([a, b], Bs);
        c = D([a, c, 300, void 0], X);
        Wh(b, c)
    });

    function Ds(a, b) {
        var c = Nf(b),
            d = Nc.fc,
            e = Sc(a);
        if (c && Of("ym-advanced-informer", c)) {
            var f = e.C("ifc", 0) + 1;
            e.D("ifc", f);
            f = c.getAttribute("data-lang");
            var g = Vb(c.getAttribute("data-cid") || "");
            if (g || 0 === g)(d = I(a, "Ya." + d + ".informer")) ? (e = {}, d((e.i = c, e.id = g, e.lang = f, e))) : e.D("ib", !0), c = b || window.event, c.preventDefault ? c.preventDefault() : c.returnValue = !1
        }
    }

    function Es(a) {
        var b = V(a, "i.clch", Ds);
        ud(a).F(a.document, ["click"], E(a, b), {
            passive: !1
        });
        return function(c) {
            var d = Nc.La,
                e = a.Ya[Nc.fc],
                f = !!e._informer;
            e._informer = M({
                domain: "informer.yandex.ru"
            }, c);
            f || oh(a, {
                src: d + "//informer.yandex.ru/metrika/informer.js"
            })
        }
    }

    function Fs(a) {
        return {
            R: function(b, c) {
                var d = b.K;
                if (d) {
                    var e = O(a).C("adBlockEnabled");
                    e && d.D("adb", e)
                }
                c()
            }
        }
    }

    function Gs(a, b) {
        var c = a.document;
        if (J(c.readyState, ["interactive", "complete"])) ai(a, b);
        else {
            var d = ud(a),
                e = d.F,
                f = d.Xb,
                g = function() {
                    f(c, ["DOMContentLoaded"], g);
                    f(a, ["load"], g);
                    b()
                };
            e(c, ["DOMContentLoaded"], g);
            e(a, ["load"], g)
        }
    }
    var Hs = E("9-d5ve+.r%7", v),
        Is = W("ad", function(a, b) {
            if (!b.Ua) {
                var c = O(a);
                if (!c.C("adBlockEnabled")) {
                    var d = function(m) {
                            J(m, ["2", "1"]) && c.D("adBlockEnabled", m)
                        },
                        e = Ae(a),
                        f = e.C("isad");
                    if (f) d(f);
                    else {
                        var g = E("adStatus", c.D),
                            h = function(m) {
                                m = m ? "1" : "2";
                                d(m);
                                g("complete");
                                e.D("isad", m, 1200);
                                return m
                            },
                            k = Rh(a, "adb", b);
                        if (!c.C("adStatus")) {
                            g("process");
                            var l = "metrika/a" + Hs().replace(/[^a-v]+/g, "") + "t.gif";
                            Gs(a, function() {
                                return k({
                                    ma: {
                                        ra: l
                                    }
                                }).then(E(!1, h))["catch"](E(!0, h))
                            })
                        }
                    }
                }
            }
        }),
        Js = W("pr.p", function(a, b) {
            if (Ec(a)) {
                var c =
                    Rh(a, "5", b),
                    d = {};
                d = Le((d.pq = 1, d.ar = 1, d));
                var e = {};
                c({
                    K: d,
                    H: (e["page-url"] = U(a).href, e["page-ref"] = I(a, "document.referrer") || "", e)
                }, b)["catch"](V(a, "pr.p.s"))
            }
        }),
        Ks = !1;

    function Ls(a) {
        return {
            R: function(b, c) {
                if (!b.K) return c();
                var d = O(a).C("fid");
                !Ks && d && ( of (b, "fid", d), Ks = !0);
                return c()
            }
        }
    }
    var Ms = W("fid", function(a) {
        var b = u;
        if (!A(a.PerformanceObserver)) return b;
        var c = O(a);
        if (c.C("fido")) return b;
        c.D("fido", !0);
        var d = new a.PerformanceObserver(V(a, "fid", function(f) {
            f = f.getEntries()[0];
            c.D("fid", a.Math.round(100 * (f.processingStart - f.startTime)));
            b()
        }));
        b = function() {
            return d.disconnect()
        };
        try {
            var e = {};
            d.observe((e.type = "first-input", e.buffered = !0, e))
        } catch (f) {}
        return b
    });

    function Ns(a, b, c) {
        if (I(c, "settings.ins")) {
            var d = O(a);
            if (!d.C("scip")) {
                var e = Ff(a),
                    f = Ed(a)(Bd);
                c = Tb(e.C("sci"));
                if (!(c && 1440 >= f - c)) {
                    c = Rh(a, "ci");
                    var g = ["sync.cook.int"],
                        h = function(m) {
                            m = d.C("scip", "") + m;
                            d.D("scip", m)
                        },
                        k = E("a", h);
                    d.D("scip", "0");
                    var l = {};
                    return c({
                        N: {
                            ea: g,
                            Oa: 3E3,
                            cb: !0
                        },
                        H: (l.tag = "cm-urls", l.stage = "mc-yandex-com", l["mc-id"] = "" + b.id, l.duid = Mg(a, b), l)
                    }, ["https://eu.asas.yango.com/mapuid"]).then(function(m) {
                        m = I(m.Ga, "CookieMatchUrls");
                        if (K(m) && eb(m)) {
                            h("1");
                            var p = Rh(a, "c");
                            m = L(function(r,
                                t) {
                                return p({
                                    N: {
                                        ea: g,
                                        Oa: 3E3
                                    }
                                }, ["https://" + r])["catch"](G(E("b", h), E("" + t, h)))
                            }, nb(y, m));
                            return Q.all(m)
                        }
                        k()
                    }, k).then(function() {
                        var m = d.C("scip");
                        !m || Na(m, "a") || Na(m, "b") || (e.D("sci", f), h("2"))
                    }, u)
                }
            }
        }
    }
    E(hf("ccf"), md);

    function Os(a, b, c) {
        var d = I(a, "location.host");
        a = Mg(a, b);
        c.D("pu", "" + Yj(d) + a)
    }

    function Ps(a, b, c) {
        var d = Lg(a, b);
        if (d) {
            d.Z.F(["gpu-get"], function() {
                var g = {};
                return g.type = "gpu-get", g.pu = c.C("pu"), g
            });
            var e = I(a, "opener");
            if (e) {
                var f = X(a, D([a, b, c], Os), 200, "pu.m");
                b = {};
                d.ke(e, (b.type = "gpu-get", b), function(g, h) {
                    var k = I(h, "pu");
                    k && (rg(a, f), c.D("pu", k))
                })
            } else Os(a, b, c)
        }
    }

    function Qs(a, b, c, d) {
        return Wh(b, function(e) {
            if (!Bm(e) && !ic(a))
                if (e = d.C("zzlc"), B(e) || Qa(e) || "na" === e) {
                    var f = Lf(a);
                    if (f && (e = Rf(a))) {
                        var g = f("iframe");
                        M(g.style, {
                            display: "none",
                            width: "1px",
                            height: "1px",
                            visibility: "hidden"
                        });
                        f = Ic(a);
                        var h = Hc(a);
                        g.src = "https://mc.yandex." + (f || h ? "md" : "ru") + yl("L21ldHJpa2EvenpsYy5odG1s");
                        e.appendChild(g);
                        var k = 0,
                            l = ud(a).F(a, ["message"], V(a, "zz.m", function(m) {
                                (m = I(m, "data")) && m.substr && "__ym__zz" === m.substr(0, 8) && (Mf(g), m = m.substr(8), d.D("zzlc", m), c.D("zzlc", m), l(), rg(a,
                                    k))
                            }));
                        k = X(a, G(l, E(g, Mf)), 3E3)
                    }
                } else c.D("zzlc", e)
        })
    }

    function Rs(a, b, c, d) {
        b = d.C("cc");
        d = D(["cc", ""], d.D);
        if (b) {
            var e = q(b.split("&"));
            b = e.next().value;
            (e = (e = e.next().value) && Vb(e)) && 1440 < Ed(a)(Bd) - e ? d() : c.D("cc", b)
        } else ra(0)(b) || d()
    }
    var Ss = x(function(a, b) {
        var c = O(a),
            d = Ff(a),
            e = [],
            f = D([a, b, c, d], hl),
            g = !gl(a) || Ic(a);
        g && e.push(D([Ps, "pu", ""], f));
        !g || d.Jd || Fc(a) || (e.push(D([Qs, "zzlc", "na"], f)), e.push(D([Rs, "cc", ""], f)));
        return e.length ? {
            ta: function(h, k) {
                if (0 === c.C("isEU")) try {
                    L(Re, e)
                } catch (l) {}
                k()
            },
            R: function(h, k) {
                var l = h.K;
                if (l && 0 === c.C("isEU")) try {
                    L(ta(l), e)
                } catch (m) {}
                k()
            }
        } : {}
    }, G(Da, N));

    function Ts(a, b, c, d, e) {
        if (!zj(a)) return u;
        var f = [],
            g = [],
            h = ud(a),
            k;
        Bg(a)(ug(u, function() {
            var l = Aj(b, a.document.body);
            e && (l = nb(e, l));
            L(function(p) {
                f.push(p);
                g.push(h.F(p, c, d))
            }, l);
            if (wa("MutationObserver", a.MutationObserver)) {
                var m = b.toUpperCase();
                l = new a.MutationObserver(V(a, "de.m", function(p) {
                    L(function(r) {
                        var t = r.addedNodes;
                        r = r.removedNodes;
                        t && t.length && L(function(w) {
                            Kk(a, w, function(z) {
                                z.nodeName !== m || e && !e(z) || Je(ra(z), f) || (f.push(z), g.push(h.F(z, c, d)))
                            }, void 0, a.NodeFilter.SHOW_ELEMENT, !0)
                        }, t);
                        r && r.length && L(function(w) {
                            Kk(a, w, function(z) {
                                z.nodeName !== m || e && !e(z) || (z = wb(a)(z, f), -1 !== z && (g[z](), g.splice(z, 1), f.splice(z, 1)))
                            }, void 0, a.NodeFilter.SHOW_ELEMENT, !0)
                        }, r)
                    }, p)
                }));
                l.observe(a.document.body, {
                    childList: !0,
                    subtree: !0
                });
                k = C(l.disconnect, l)
            }
        }));
        return function() {
            k && k();
            L(Qe, g);
            yb(g);
            yb(f)
        }
    }

    function Us(a, b) {
        var c = I(b, "target");
        if (c) {
            var d = I(c, "value");
            if ((d = ke(d)) && !(100 <= eb(d))) {
                var e = "tel" === I(c, "type"),
                    f = 0 < La(d, "@") && !e,
                    g = ne(d);
                g = eb(g);
                if (f || !f && (e || g))
                    if (d = f ? qi(d) : ti(a, d)) return e = I(b, "isTrusted"), {
                        jh: c,
                        mh: f,
                        kh: d,
                        isTrusted: e,
                        Md: b.Md
                    }
            }
        }
    }

    function Vs(a, b, c, d) {
        var e = c.mh,
            f = c.jh,
            g = c.isTrusted;
        c = c.Md;
        a = Mj(a, f);
        f = f.readOnly;
        var h = {},
            k = {};
        d = (k.fi = nf((h.a = e ? 1 : 0, h.b = a, h.c = d || 0, h.d = f ? 1 : null, h.e = c ? 1 : null, h)).Ha(), k);
        Ra(g) || (d.ite = jb(g));
        g = {};
        b.params((g.__ym = d, g))
    }
    var Ws = W("ice", function(a, b, c) {
            if (b = fi(a, b))
                if (c = Us(a, c)) return Vs(a, b, c), !0
        }),
        Xs = W("ice", function(a, b, c) {
            if (b = fi(a, b))
                if (c = Us(a, c)) return vi(a, c.kh).then(D([a, b, c], Vs), V(a, "ice.s")), !0
        }),
        Ys = ["text", "email", "tel"],
        Zs = ["cc-", "name", "shipping"],
        $s = W("icei", function(a, b) {
            if (ui(a)) {
                var c = !1,
                    d = u,
                    e = u;
                Wh(b, function(f) {
                    if (!(Dr(a) || I(f, "settings.eu") || c)) {
                        f = I(f, "settings.cf") ? Xs : Ws;
                        var g = D([a, b], f),
                            h = function(k) {
                                return fp(a, k) || !J(k.type, Ys) || Ob(kb, L(E(k.autocomplete, Na), Zs)) ? !1 : !0
                            };
                        d = Ts(a, "input", ["blur"],
                            g, h);
                        e = Ts(a, "form", ["submit"], function(k) {
                            var l = k.target;
                            if (l) {
                                l = Aj("input", l);
                                var m = 0;
                                L(function(p) {
                                    20 <= m || !h(p) || g({
                                        target: p,
                                        isTrusted: k.isTrusted,
                                        Md: !0
                                    }) && (m += 1)
                                }, l)
                            }
                        })
                    }
                });
                return function() {
                    c = !0;
                    d();
                    e()
                }
            }
        }),
        at;

    function bt(a, b, c) {
        var d = I(a, "AppMetricaInitializer"),
            e = I(d, "init");
        if (e) try {
            C(e, d)(yf(a, b))
        } catch (f) {} else at = X(a, D([a, b, 2 * c], bt), c, "ai.d");
        return function() {
            return rg(a, at)
        }
    }
    var ct = W("p.ai", function(a, b) {
            if (oc(a) || dl(a)) return Wh(b, function(c) {
                if (c = I(c, "settings.sbp")) {
                    var d = {};
                    return bt(a, M({}, c, (d.c = b.id, d)), 10)
                }
            })
        }),
        dt = "architecture bitness model platformVersion uaFullVersion fullVersionList".split(" "),
        et = Yd("uah", function(a) {
            if (!wa("getHighEntropyValues", I(a, "navigator.userAgentData.getHighEntropyValues"))) return Q.reject("0");
            try {
                return a.navigator.userAgentData.getHighEntropyValues(dt).then(function(b) {
                    if (!Sa(b)) throw "2";
                    return b
                }, function() {
                    throw "1";
                })
            } catch (b) {
                return Q.reject("3")
            }
        }),
        ft = new RegExp(T("|", "yandex.com/bots;Googlebot;APIs-Google;Mediapartners-Google;AdsBot-Google;FeedFetcher-Google;Google-Read-Aloud;DuplexWeb-Google;Google Favicon;googleweblight;Lighthouse;Mail.RU_Bot;StackRambler;Slurp;msnbot;bingbot;www.baidu.com/search/spi_?der.htm".split(";")).replace(/[./]/g, "\\$&")),
        gt = x(function(a) {
            var b = Bb(a);
            return (b = ft.test(b)) ? Q.resolve(b) : et(a).then(function(c) {
                try {
                    return F(function(d, e) {
                        return d || ft.test(e.brand)
                    }, !1, c.brands)
                } catch (d) {
                    return !1
                }
            }, E(!1, v))
        }),
        ht = ["0", "1",
            "2", "3"
        ],
        it = ht[0],
        jt = ht[1],
        kt = ht[2],
        lt = ["GDPR-ok-view-detailed-0", "GDPR-ok-view-detailed-1", "GDPR-ok-view-detailed-2", "GDPR-ok-view-detailed-3"],
        mt = ["GDPR-ok-view-default", "GDPR-ok-view-detailed"].concat(lt);

    function nt(a) {
        if (J(a, ["GDPR-ok-view-default", "GDPR-ok-view-detailed"])) return it;
        a = a.replace("GDPR-ok-view-detailed-", "");
        return J(a, ht) ? a : it
    }
    var ot = "GDPR-ok GDPR-cross GDPR-cancel 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 GDPR-settings GDPR-ok-view-default GDPR-ok-view-detailed 21 22 23".split(" ").concat(lt).concat(["28", "29", "30", "31"]),
        pt = "3 13 14 31 15 16 17 28".split(" "),
        qt = G(Kb(db("ymetrikaEvent.type")), pb(sb(ot)));

    function rt(a, b, c) {
        a = c || wc(a);
        return J(a, b) ? a : "en"
    }
    var st = {
            oh: !0,
            url: "https://yastatic.net/s3/gdpr/v3/gdpr",
            qf: "",
            hf: "az be en es et fi fr hy ka kk ky lt lv no pt ro ru sl tg tr uz cs da de el hr it nl pl sk sv".split(" ")
        },
        tt = Yd("gdpr", function(a, b, c, d, e) {
            function f(p) {
                b("10");
                c.F(mt, function(r) {
                    r = r.type;
                    var t = {};
                    l.If((t.type = r, t));
                    p({
                        value: nt(r)
                    })
                })
            }
            var g = void 0 === e ? st : e;
            e = g.url;
            var h = g.qf,
                k = g.oh;
            g = rt(a, g.hf, d.hi);
            var l = Ui(a, d);
            if (!l) return Q.resolve({
                value: it,
                Ld: !0
            });
            if (a._yaGdprLoaded) return new Q(function(p) {
                b("7");
                f(p)
            });
            var m = oh(a, {
                src: "" +
                    e + (k ? "" : g) + h + ".js"
            });
            return new Q(function(p, r) {
                m ? (b("7"), m.onerror = function() {
                    b("9");
                    var t = {};
                    l.If((t.type = "GDPR-ok-view-default", t));
                    p(null)
                }, m.onload = E(p, f)) : (b("9"), r(hf("gdp.e")))
            })
        });

    function ut(a, b) {
        var c = Ui(a, b);
        c && c.Z.F(["isYandex"], function() {
            var d = {};
            return d.type = "isYandex", d.isYandex = Gm(a), d
        })
    }

    function vt(a, b, c) {
        var d = Ui(a, c);
        return new Q(function(e) {
            if (d) {
                var f = d.Z,
                    g = G(E("4", b), E(null, e)),
                    h = X(a, g, 2E3, "gdp.f.t"),
                    k = {};
                d.Jf((k.type = "isYandex", k)).then(function(l) {
                    l.isYandex ? (b("5"), f.F(mt, function(m) {
                        m = q(m);
                        m.next();
                        m = m.next().value.type;
                        e({
                            value: nt(m)
                        })
                    })) : (b("6"), e(null))
                })["catch"](g).then(D([a, h], rg))
            } else e({
                value: jt,
                Ld: !0
            })
        })
    }
    var wt = {},
        xt = (wt["GDPR-ok"] = "ok", wt["GDPR-ok-view-default"] = "ok-default", wt["GDPR-ok-view-detailed"] = "ok-detailed", wt["GDPR-ok-view-detailed-0"] = "ok-detailed-all", wt["GDPR-ok-view-detailed-1"] = "ok-detailed-tech", wt["GDPR-ok-view-detailed-2"] = "ok-detailed-tech-analytics", wt["GDPR-ok-view-detailed-3"] = "ok-detailed-tech-other", wt);

    function yt(a, b) {
        if (Gm(a)) {
            var c = Wi(a),
                d = fi(a, b);
            d = d && d.params;
            c = L(E(xt, I), qt(c));
            d && c.length && d("gdpr", ob(c))
        }
    }
    var zt = "az be en es et fi fr hy ka kk ky lt lv no pt ro ru sl tg tr uz ar he sr uk zh".split(" "),
        At = [],
        Bt = Wa("push", At),
        Ct = x(function(a, b) {
            var c = b.C("gdpr");
            return J(c, ht) ? "-" + c : ""
        });

    function Dt(a, b, c, d) {
        if (!c.K || Oc(b.ca)) d();
        else {
            var e = Wi(a),
                f = E(e, Vi),
                g = ze(a, ""),
                h = function() {
                    var r = T(",", L(Ca(ot), qt(e)));
                    r = "" + r + Ct(r, g); of (c, "gdpr", r);
                    d()
                };
            if (b.ei) f("31"), h();
            else if (3 === b.id) h();
            else {
                var k = O(a),
                    l = k.C("f1");
                if (l) l(h);
                else if (l = qt(e), Ob(sb(ot), l)) h();
                else if (g.C("yandex_login")) f("13"), g.D("gdpr", it, 525600), h();
                else {
                    l = Gm(a);
                    var m = U(a);
                    var p = /(^|\w+\.)yango(\.yandex)?\.com$/.test(m.hostname) ? {
                            url: "https://yastatic.net/s3/taxi-front/yango-gdpr-popup/",
                            version: 2,
                            hf: zt,
                            qf: "_inversed_buttons"
                        } :
                        void 0;
                    l || p ? (l = g.C("gdpr"), J(l, ht) ? (f(l === jt ? "12" : "3"), h()) : dl(a) || el(a) ? (f("17"), h()) : gt(a).then(v, u).then(function(r) {
                        r ? (f("28"), h()) : (Bt(h), k.D("f1", Bt), r = q(xm).next().value, r(a).then(db("params.eu")).then(function(t) {
                            if (t || Na(m.href, "yagdprcheck=1") || g.C("yaGdprCheck")) {
                                g.D("gdpr_popup", jt);
                                ut(a, b);
                                if (xc(a)) return vt(a, f, b);
                                var w = Zi(a, e);
                                if (w) return t = tt(a, f, w, b, p), t.then(D([a, b], yt)), t
                            }
                            t || f("8");
                            return Q.resolve({
                                value: it,
                                Ld: !0
                            })
                        }).then(function(t) {
                            g.kc("gdpr_popup");
                            if (t) {
                                var w = t.value;
                                t = t.Ld;
                                J(w, ht) && g.D("gdpr", w, t ? void 0 : 525600)
                            }
                            w = Rd(At, Qe);
                            ml(a, w, 20)(ug(V(a, "gdr"), u));
                            k.D("f1", Qe)
                        })["catch"](V(a, "gdp.a")))
                    })) : (f("14"), h())
                }
            }
        }
    }
    var Et = Lc.split("."),
        Ft = Et.pop(),
        Gt = T(".", Et),
        Ht = {};

    function It(a, b) {
        Ht[b] || (Ht[b] = {
            Lh: oh(a, {
                src: b
            }),
            state: 0
        });
        return Ht[b]
    }

    function Jt(a, b, c, d) {
        function e() {
            g.state = 1;
            c()
        }

        function f() {
            g.state = 2;
            d && d()
        }
        var g = It(a, b);
        b = g.Lh;
        var h = g.state;
        b && 2 !== h ? 1 === h ? e() : (a = ud(a), a.F(b, ["load"], e), a.F(b, ["error"], f)) : f()
    }
    var Kt = x(Ce, N);

    function Lt(a, b, c, d) {
        var e = Kt(c).Hh;
        if (!e) throw S("im.no");
        Jt(a, Kr + "/" + b + ".js?ver=" + Nc.eb + "&b=e", function() {
            var f = O(a).C("ytmm");
            (f = I(f, b + ".init")) && f(e, d, Nc.eb)
        })
    }
    var Mt = x(De);

    function Nt(a) {
        a = wc(a);
        return mm[a] || "com"
    }

    function Ot(a) {
        a = Dm(a);
        return jm[a] || a
    }
    var Pt = x(function() {
            var a = F(function(b, c) {
                "ru" !== c && (b[c] = Gt + "." + c);
                return b
            }, {}, be);
            L(function(b) {
                a[b] = b
            }, cc(km));
            a.com = Gt + ".com";
            return a
        }),
        Qt = x(function(a) {
            a = U(a).hostname;
            return (a = Je(G(db("1"), bb("test"), qa(Qe)(a)), bc(km))) && a[0]
        });

    function Rt(a, b) {
        var c = Nt(a),
            d = [Qt(a) || Ot(a)];
        Em(a) && d.push(c);
        d.unshift("com");
        var e = Ed(a);
        c = Ff(a);
        var f = c.C("synced", {});
        d = nb(function(g) {
            if (b[g]) {
                var h = (f[g] || 1) + 1440 < e(Bd);
                h && delete f[g];
                return h
            }
        }, d);
        c.D("synced", f);
        return L(function(g) {
            return {
                Qh: b[g],
                qh: g
            }
        }, d)
    }
    var St = function(a, b) {
            return function(c, d) {
                if (Fc(c) || Db(c)) return {};
                var e = N(d);
                e = Pt(e);
                var f = Rt(c, e),
                    g = O(c),
                    h = xc(c);
                return {
                    R: function(k, l) {
                        var m = k.K;
                        m = !(m && m.C("pv"));
                        if (h || m || !f.length) return l();
                        g.C("startSync") ? Mt(c).push(l) : (g.D("startSync", !0), D([c, f, u, !1], a)().then(l, G(sa(l), V(c, b)))["catch"](u))
                    },
                    ta: function(k, l) {
                        if (!I(k.zf, "settings.nss")) return l();
                        var m = k.K;
                        m = !(m && m.C("pv"));
                        if (h || m || !f.length) return l();
                        if (g.C("startSync")) Mt(c).push(l);
                        else return g.D("startSync", !0), a(c, f, u, !0).then(l,
                            G(sa(l), V(c, b)))
                    }
                }
            }
        }(function(a, b, c, d) {
            var e = Ed(a),
                f = O(a),
                g = Ff(a);
            c = Nh(a, "c");
            var h = Oe(a, c);
            return F(function(k, l) {
                function m() {
                    var t = g.C("synced");
                    f.D("startSync", !1);
                    t && (t[l.qh] = p, g.D("synced", t));
                    t = Mt(a);
                    L(Qe, t);
                    yb(t)
                }
                var p, r = h({
                    N: {
                        ea: ["sync.cook"],
                        Oa: 1500
                    }
                }, [Nc.La + "//" + l.Qh + "/sync_cookie_image_check" + (d ? "_secondary" : "")]).then(function() {
                    p = e(Bd);
                    m()
                })["catch"](function() {
                    p = e(Bd) - 1435;
                    m()
                });
                r = E(r, v);
                return k.then(r)
            }, Q.resolve(), b)["catch"](V(a, "ctl"))
        }, "sy.c"),
        Tt = {},
        Ut = (Tt.brands = "chu", Tt.architecture =
            "cha", Tt.bitness = "chb", Tt.uaFullVersion = "chf", Tt.fullVersionList = "chl", Tt.mobile = "chm", Tt.model = "cho", Tt.platform = "chp", Tt.platformVersion = "chv", Tt);

    function Vt(a) {
        return y(a) ? a : K(a) ? T(",", L(function(b) {
            return '"' + b.brand + '";v="' + b.version + '"'
        }, a)) : Ra(a) ? "" : a ? "?1" : "?0"
    }

    function Wt(a) {
        return "che\n" + a
    }

    function Xt(a) {
        var b = F(function(c, d) {
            var e = q(d),
                f = e.next().value;
            e = e.next().value;
            (f = Vt(a[f])) && c.push("" + e + "\n" + f);
            return c
        }, [], bc(Ut));
        return T("\n", b)
    }
    var Yt = x(function(a) {
        return et(a).then(Xt, Wt)
    });

    function Zt(a) {
        return {
            R: function(b, c) {
                Yt(a).then(function(d) {
                    b.H || (b.H = {});
                    b.H.uah = d;
                    c()
                }, c)
            }
        }
    }

    function $t(a, b) {
        if ("https://oauth.yandex.ru" === I(b, "origin") && I(b, "source.window") && "_ym_uid_request" === I(b.data, "_ym")) {
            var c = b.source,
                d = {};
            d = (d._ym_uid = a, d);
            c.postMessage(d, "https://oauth.yandex.ru")
        }
    }
    var au = Yd("ot", function(a, b) {
        if (Jc(a)) {
            var c = ud(a);
            return Wh(b, V(a, "ot.s", function(d) {
                if (I(d, "settings.oauth")) {
                    var e = [],
                        f = Mg(a, b);
                    e.push(c.F(a, ["message"], V(a, "ot.m", E(f, $t))));
                    Bg(a)(ug(u, V(a, "ot.b", function() {
                        function g(p) {
                            var r = p.href;
                            if (r && tj(r, "https://oauth.yandex.ru/") && !Na(r, "_ym_uid=")) {
                                r = Na(r, "?") ? "&" : "?";
                                var t = {};
                                p.href += "" + r + Wd((t._ym_uid = f, t.mc = "v", t));
                                c.F(p, ["click"], V(a, "ot.click", function() {
                                    var w = "et=" + k(Ad);
                                    p.href += "&" + w
                                }))
                            }
                        }
                        var h = a.document.body,
                            k = Ed(a),
                            l = Aj("a", h);
                        L(g, l);
                        if (wa("MutationObserver",
                                a.MutationObserver)) {
                            l = new a.MutationObserver(V(a, "ot.m", E(function(p) {
                                p = p.addedNodes;
                                for (var r = 0; r < p.length; r += 1) {
                                    var t = p[r];
                                    "A" === t.nodeName && g(t)
                                }
                            }, L)));
                            var m = {};
                            m = (m.childList = !0, m.subtree = !0, m);
                            l.observe(h, m);
                            e.push(C(l.disconnect, l))
                        }
                    })));
                    return D([Re, e], L)
                }
            }))
        }
    });

    function bu(a, b, c, d) {
        var e = I(d, "data");
        if (y(e)) {
            var f = q(e.split("*"));
            e = f.next().value;
            var g = f.next().value;
            f = f.next().value;
            "sc.topics-response" === e ? (g && ("1" === g && f ? (a = xf(a, f), K(a) && b.D("cta", a)) : b.D("cta.e", g)), c()) : "sc.frame" === e && d.source && d.source.postMessage("sc.topics", "*")
        }
    }

    function cu(a) {
        var b = I(a, "featurePolicy");
        return b ? "browsingTopics" in a && b.allowsFeature("browsing-topics") : !1
    }
    var du = W("p.cta", function(a) {
            Bg(a)(ug(u, function() {
                var b = O(a);
                if (cu(a.document)) {
                    var c = 0;
                    if (Nr(a, "cta")) {
                        var d = u,
                            e = function() {
                                Or("cta");
                                d();
                                rg(a, c)
                            };
                        d = ud(a).F(a, ["message"], W("p.cta.o", D([a, b, e], bu)));
                        c = X(a, e, 1500)
                    } else b.D("cta.e", "if")
                } else b.D("cta.e", "ns")
            }))
        }),
        eu = "pbjsInit bidRequested bidAdjustment bidWon bidResponse bidTimeout auctionInit auctionEnd adRenderSucceeded adRenderFailed".split(" "),
        fu = ["cpm", "currency", "netRevenue", "requestTimestamp", "responseTimestamp"],
        gu = {},
        hu = (gu.netRevenue =
            function(a) {
                return y(a) ? "net" === a : !!a
            }, gu),
        iu = {},
        ju;

    function ku(a) {
        var b = iu[a],
            c = b.Sc,
            d = b.Ne,
            e = b.Kh;
        return L(function(f) {
            var g = q(f);
            f = g.next().value;
            g = g.next().value;
            var h = g.Td,
                k = g.timeout,
                l = g.Fb,
                m = {};
            return M((m.renderState = g.Pb, m.mediaTypes = h, m.auctionId = a, m.adUnitCode = f, m.startStamp = c, m.endStamp = d, m.requestedBidders = e, m.bidTimeout = k, m), l)
        }, bc(b.Ic))
    }

    function lu(a, b, c) {
        var d = iu[c];
        d.aa = !1;
        d.Pa && rg(a, d.Pa);
        d.Pa = X(a, function() {
            var e = ku(c),
                f = {},
                g = {};
            b((g.__ym = (f.pbjsv = ju, f.pbjs = e, f), g));
            delete iu[c]
        }, 2E3)
    }

    function ru(a, b) {
        L(function(c) {
            iu[c].aa && lu(a, b, c)
        }, cc(iu))
    }

    function su(a, b) {
        a.Ic[b] || (a.Ic[b] = {
            Fb: {}
        });
        return a.Ic[b]
    }

    function tu(a, b, c) {
        var d = c.adUnitCode,
            e = c.bidderCode || c.bidder;
        if (e && d) {
            var f = su(b, d);
            !f.Td && c.mediaTypes && (f.Td = {}, L(function(g) {
                var h = q(g);
                g = h.next().value;
                h = h.next().value;
                var k;
                K(h) ? k = h : h.sizes ? k = h.sizes : h.playerSize && (k = h.playerSize);
                k && (f.Td[g] = k)
            }, bc(c.mediaTypes)));
            "bidTimeout" === a ? (f.timeout || (f.timeout = {}), f.timeout[e] = !0) : (f.Fb[a] || (f.Fb[a] = {}), f.Fb[a][e] = F(function(g, h) {
                Ra(c[h]) || (g[h] = hu[h] ? hu[h](c[h]) : c[h]);
                return g
            }, {}, fu), b = I(c, "meta.advertiserDomains"), K(b) && (f.Fb[a][e].advertiserDomains =
                b))
        }
    }

    function uu(a, b, c) {
        var d = c.bid,
            e = d.bidderCode || d.bidder;
        d = d.adUnitCode;
        e && d && (b = su(b, d), b.Pb || (b.Pb = {}), a = "adRenderSucceeded" === a, d = {}, b.Pb[e] = (d.success = a, d), a || (b.Pb[e].reason = c.reason, b.Pb[e].message = c.message))
    }

    function vu(a, b) {
        if (J(a, eu))
            if ("pbjsInit" === a) ju = b.version;
            else {
                var c = I(b, "auctionId") || I(b, "bid.auctionId") || void 0;
                if (c) {
                    iu[c] || (iu[c] = {
                        Ic: {}
                    });
                    c = iu[c];
                    var d = "auctionInit" === a,
                        e = "auctionEnd" === a,
                        f = "adRenderFailed" === a || "adRenderSucceeded" === a;
                    f || c.Sc && !d || (c.Sc = I(b, "auctionStart") || void 0, !c.Sc && d && (c.Sc = b.timestamp));
                    var g = D([a, c], tu);
                    "bidRequested" === a ? L(g, b.bids) : f ? uu(a, c, b) : e ? (c.Ne = b.auctionEnd || b.timestamp, c.Kh = nb(function(h, k, l) {
                            return Ba(h, l) === k
                        }, L(db("bidderCode"), b.bidderRequests))) : d ||
                        g(b);
                    c.Ne && (c.aa = !0)
                }
            }
    }

    function wu(a) {
        L(function(b) {
            var c = b.event;
            b = b.data;
            var d = E(c, vu);
            "bidTimeout" === c ? L(d, b) : d(b)
        }, a)
    }
    var xu = W("pj", function(a, b) {
        var c = fi(a, b),
            d = c && c.params;
        if (!d) return u;
        c = {};
        return c.pbjs = function(e) {
            K(e) && (e = nb(kb, L(function(f) {
                if (Sa(f) && f.data && f.event && (Sa(f.data) || K(f.data))) {
                    var g = I(f, "data.args");
                    return g ? {
                        event: f.event,
                        data: g
                    } : f
                }
            }, e)), wu(e), ru(a, d))
        }, c
    });

    function yu(a, b) {
        var c = a[b[0]];
        return !(!c || c !== b[1])
    }

    function zu(a, b) {
        var c = b.patterns;
        if (0 === c.length) return !1;
        if (1 === c.length) return yu(a, c[0]);
        c = F(function(f, g) {
            var h = q(g),
                k = h.next().value;
            h = h.next().value;
            var l = a[k];
            if (l === h) {
                if (f.qd += 1, "i" === k || "c" === k) f.ff = !0
            } else l && "p" === k && oe(l) === oe(h) && (f.gf = !0);
            return f
        }, {
            qd: 0,
            ff: !1,
            gf: !1
        }, c);
        var d = c.ff,
            e = c.gf;
        return 2 <= c.qd || d && e
    }

    function Au(a, b) {
        var c = b.patterns;
        return 0 === c.length ? !1 : Ob(E(a, yu), c)
    }
    var Bu = qa(tj)("btn:"),
        Cu = qa(tj)("form:"),
        Du = x(function() {
            var a = Lj();
            return F(function(b, c) {
                b[a[c]] = c;
                return b
            }, {}, cc(a))
        }),
        Eu = /(\D\d*)/g;

    function Fu(a) {
        if (!a) return "";
        a = a.match(Eu);
        if (!a || 0 === a.length) return "";
        var b = Du();
        return "//HTML/BODY/" + F(function(c, d) {
            var e = d[0],
                f = Vb(d.slice(1));
            return "/" + b[e] + (f ? "[" + (f + 1) + "]" : "") + c
        }, "", a)
    }
    var Gu = x(Ce);

    function Hu(a) {
        return {
            Fh: If(a.element),
            rd: a.rd
        }
    }

    function Iu(a) {
        var b = q(a),
            c = b.next().value;
        b = b.next().value;
        return "bp" === c ? ["p", Al(yl(b))] : a
    }
    var Ju = Kb(function(a) {
            a.patterns = L(Iu, a.patterns);
            a.price_patterns = L(Iu, a.price_patterns);
            return a
        }),
        Ku = "ytm.js ytm.dom ytm.load ytm.init ytm.click ytm.linkClick ytm.formSubmit".split(" "),
        Lu = ["ytm.click", "ytm.linkClick", "ytm.formSubmit"];

    function Mu(a, b, c) {
        if (Lu.includes(b) && c) {
            a = Fa(c.classList);
            var d = c.innerText,
                e = c.getAttribute("id");
            var f = c.getAttribute("formAction") || c.getAttribute("action") || c.getAttribute("href") || c.getAttribute("src") || c.getAttribute("code") || c.getAttribute("codebase") || "";
            c = {
                element: c,
                elementClasses: a,
                elementText: d,
                elementId: e,
                elementUrl: f,
                vi: c.getAttribute("formTarget") || c.getAttribute("target") || ""
            };
            return {
                event: b,
                ytm: c
            }
        }
        return "ytm.init" === b ? {
            event: b,
            ytm: {
                timestamp: Ed(a)(Ad)
            }
        } : {
            event: b,
            ytm: {}
        }
    }

    function Nu(a, b) {
        return ud(a).F(a.document, ["click"], function(c) {
            "A" === c.target.nodeName && b(Mu(a, "ytm.linkClick", c.target))
        })
    }

    function Ou(a, b, c, d, e) {
        e = void 0 === e ? a.document : e;
        return ud(a).F(e, d, function(f) {
            b(Mu(a, c, f.target))
        })
    }

    function Pu(a, b, c) {
        return J(a.document.readyState, ["complete", "interactive"]) ? (b(Mu(a, c)), u) : Ou(a, b, c, ["DOMContentLoaded"])
    }

    function Qu(a, b, c) {
        if ("ytm.linkClick" === b) return Nu(a, c);
        if ("ytm.js" === b) return Pu(a, c, "ytm.js");
        if ("ytm.dom" === b) return Pu(a, c, "ytm.dom");
        if ("ytm.load" === b) return "complete" === a.document.readyState ? (c(Mu(a, "ytm.load")), a = u) : a = Ou(a, c, "ytm.load", ["load"], a), a;
        if ("ytm.click" === b) return Ou(a, c, "ytm.click", ["click"]);
        if ("ytm.formSubmit" === b) return Ou(a, c, "ytm.formSubmit", ["submit"], a)
    }
    var Ru = ["ytm.js"],
        Su = ["ytm.js", "ytm.dom", "ytm.load"];

    function Tu(a, b) {
        var c = a[b["var"]],
            d = "eq" === b.fn,
            e = b.target;
        return c && "event" === c.type && d && y(e) && e
    }

    function Uu(a) {
        return Jb(G(db("conditions"), Kb(E(a.variables, Tu)), ob), a.triggers)
    }

    function Vu(a, b, c) {
        var d = void 0 === d ? "dataLayer" : d;
        c = Uu(c);
        var e = [],
            f = [];
        L(function(g) {
            if (J(g, Ku)) {
                var h = Qu(a, g, b);
                h && e.push(h);
                J(g, Ru) && f.push(g)
            } else f.push(g)
        }, sl(function(g, h) {
            var k = wb(a)(g, Su),
                l = wb(a)(h, Su);
            return -1 === k ? 1 : -1 === l ? -1 : k - l
        }, c));
        c = I(a, d);
        c || (c = [], a[d] = c);
        Xi(a, c, function(g) {
            g.qa.F(function(h) {
                var k = I(h, "event");
                y(k) && J(k, f) && b(h)
            });
            e.push(g.unsubscribe)
        });
        return function() {
            return L(Qe, e)
        }
    }
    var Wu = u,
        Xu = x(function(a, b) {
            Wu = b
        });

    function Yu(a, b, c) {
        return function() {
            try {
                return b.apply(null, arguments)
            } catch (d) {
                Wu(a, d)
            }
            return c
        }
    }

    function Zu(a) {
        Xu(a, function(b, c) {
            mf(a, "ytm." + b, c)
        })
    }

    function $u(a, b) {
        return a === b
    }

    function av(a, b, c) {
        return Xb(a, b) && Xb(a, c) ? b > c : !1
    }

    function bv(a, b, c) {
        return Xb(a, b) && Xb(a, c) ? b < c : !1
    }

    function cv(a, b) {
        if (!y(a) || !y(b)) return !1;
        try {
            return (new RegExp(b)).test(a)
        } catch (c) {
            return !1
        }
    }

    function dv(a, b) {
        return K(a) ? J(b, a) : y(a) ? Na(a, "" + b) : !1
    }

    function ev(a, b, c) {
        var d = b.key;
        b = b.defaultValue;
        c && c.X.checkPermission({
            permissions: c.permissions,
            permissionType: "dataLayer",
            permissionParams: {
                key: d,
                operation: 2
            }
        });
        a = I(a, d);
        return B(a) ? b : a
    }
    var fv = x(function(a, b, c) {
        b = void 0 === c.min ? 0 : c.min;
        b = a.Math.random() * ((void 0 === c.max ? 2147483647 : c.max) - b + 1) + b;
        return (void 0 === c.isInt ? 0 : c.isInt) ? a.Math.floor(b) : b
    }, Da);

    function gv(a, b, c, d) {
        d = void 0 === d ? !1 : d;
        return "query" === b ? c ? Vd(a.query)[c] : a.query : "protocol" === b ? a.protocol : "host" === b ? d ? ee(a.host) : a.host : "port" === b ? (b = a.protocol, a = Vb(a.port) ? a.port : "http:" === b ? "80" : "https:" === b ? "443" : void 0, a) : "path" === b ? a.pathname : "fragment" === b ? a.hash.replace("#", "") : "extension" === b ? (a = a.pathname.split("."), ((1 < a.length ? a.pop() : void 0) || "").split("/")[0]) : a.href
    }
    var hv = "clientInformation globalThis this caches console cookieStore credentialless crypto customElements document documentPictureInPicture event external fence frameElement frames history indexedDB launchQueue localStorage location mozInnerScreenX mozInnerScreenY navigation navigator opener orientation origin originAgentCluster parent performance scheduler self sessionStorage sharedStorage speechSynthesis top trustedTypes visualViewport window alert atob back blur btoa cancelAnimationFrame cancelIdleCallback captureEvents clearImmediate clearInterval clearTimeout close confirm dump fetch find focus forward getComputedStyle getDefaultComputedStyle getScreenDetails getSelection matchMedia moveBy moveTo open postMessage print prompt queryLocalFonts queueMicrotask releaseEvents reportError requestAnimationFrame requestFileSystem requestIdleCallback resizeBy resizeTo scroll scrollBy scrollByLines scrollByPages scrollTo setImmediate setInterval setTimeout showDirectoryPicker showModalDialog showOpenFilePicker showSaveFilePicker sizeToContent stop structuredClone".split(" ");

    function iv(a) {
        if (!y(a)) throw S("gppns");
        if (J(a.split(".")[0], hv)) throw S("rwp");
        if (tj(a, "on")) throw S("rwp");
    }

    function jv(a, b) {
        if (Ra(b) || !!b === b || Sb(a, b) || y(b)) return b
    }

    function kv(a, b) {
        if (Ra(b)) return b;
        var c = jv(a, b);
        if (!Ra(c)) return c;
        if (Sa(b)) return F(function(d, e) {
            var f = q(e),
                g = f.next().value;
            f = f.next().value;
            d[g] = kv(a, f);
            return d
        }, {}, bc(b));
        if (K(b)) return L(E(a, kv), b)
    }

    function lv(a, b, c, d, e) {
        if ("event" === c.type) return ev(b, {
            type: "dataLayer",
            key: "event"
        }, e);
        if ("dataLayer" === c.type) return ev(b, c, e);
        if ("cnst" === c.type) return c.value;
        if ("rand" === c.type) return fv(a, b, c);
        if ("url" === c.type || "ref" === c.type) {
            e = !1;
            b = c.component;
            if ("url" === c.type) {
                var f = c.urlSource;
                f ? (d = d(f), d = y(d) ? d : null) : d = I(a, "location.href")
            } else d = I(a, "document.referrer");
            if (d) {
                if ("queryVar" === c.component) {
                    b = "query";
                    var g = c.key
                }
                "host" === c.component && (e = c.Ji);
                a = qh(a, d);
                a = gv(a, b, g, e)
            } else a = null;
            return a
        }
        if ("cookie" ===
            c.type) return "null" === a.origin ? a = "" : (g = c.cookieName, a = (a = te(a)) ? a[g] || "" : ""), a;
        if ("js" === c.type) return g = c.key, iv(g), e && e.X.checkPermission({
            permissions: e.permissions,
            permissionType: "globals",
            permissionParams: {
                key: g,
                operation: 2
            }
        }), g = I(a, g), jv(a, g)
    }

    function mv(a, b, c, d, e) {
        var f = d[c];
        if (!f) throw S("var: " + c);
        c = D([a, b, d], nv);
        return lv(a, b, f, c, e)
    }

    function nv(a, b, c, d, e) {
        if (K(d)) {
            if ("var" === d[0]) return d = q(d), d.next(), d = d.next().value, mv(a, b, d, c, e)
        } else return d
    }

    function ov(a, b) {
        if ("eq" === b) return $u;
        if ("more" === b) return E(a, av);
        if ("less" === b) return E(a, bv);
        if ("regex" === b) return cv;
        if ("inc" === b) return dv
    }
    var pv = Yu("c.ch", function(a, b, c, d) {
        var e = mv(a, b, c["var"], d),
            f = c.target,
            g = ov(a, c.fn);
        if (!g) throw S("fn: " + c.fn);
        a = nv(a, b, d, f);
        return g(e, a)
    }, !1);

    function qv(a, b) {
        var c = b.split("."),
            d = c.pop();
        c = c.length ? I(a, T(".", c)) : a;
        if (!c) throw S("noma");
        return {
            value: I(c, d),
            parent: c,
            Kc: d
        }
    }

    function rv(a, b, c, d) {
        var e = Lf(a)("img");
        e.src = b;
        b = E(e, Mf);
        var f = E(void 0, v);
        e.onerror = G(b, f, d);
        e.onload = G(b, f, c);
        lc(a) && (a = Qf(a), M(e.style, {
            position: "absolute",
            visibility: "hidden",
            width: "0px",
            height: "0px"
        }), a.appendChild(e))
    }
    var sv = x(function(a, b) {
            return F(function(c, d) {
                c[d] = a[d];
                return c
            }, {}, b)
        }),
        tv = "protocol host port path query extension fragment href".split(" ");

    function uv(a, b, c, d) {
        if (!c) return !1;
        var e = (b = "set_cookies" === b) ? 1 : 2;
        return b && !Sa(d) ? !1 : a.oa({
            permissionType: "cookies",
            permissionParams: {
                name: c,
                operation: e,
                options: d
            }
        })
    }

    function vv(a, b, c, d) {
        if (!c || !y(c) || !y(d)) return !1;
        switch (c) {
            case "read":
                c = 2;
                break;
            case "write":
                c = 1;
                break;
            case "execute":
                c = 4;
                break;
            default:
                return !1
        }
        return a.oa({
            permissionType: "access_local_storage" === b ? "localStorage" : "globals",
            permissionParams: {
                key: d,
                operation: c
            }
        })
    }

    function wv(a, b, c) {
        if (!c) return !1;
        var d = "iframe";
        "load_script" === b ? d = "loadScript" : "send_pixel" === b && (d = "pixel");
        return a.oa({
            permissionType: d,
            permissionParams: {
                url: c
            }
        })
    }
    var xv = {},
        yv = (xv.access_globals = vv, xv.access_local_storage = vv, xv.get_cookies = uv, xv.get_referrer = function(a, b, c) {
            return a.oa({
                permissionType: "referrer",
                permissionParams: {
                    urlComponent: c || "href"
                }
            })
        }, xv.get_url = function(a, b, c) {
            return a.oa({
                permissionType: "url",
                permissionParams: {
                    urlComponent: c || "href"
                }
            })
        }, xv.inject_hidden_iframe = wv, xv.load_script = wv, xv.logging = function(a) {
            return a.oa({
                permissionType: "log",
                permissionParams: null
            })
        }, xv.read_data_layer = function(a, b, c) {
            return c ? a.oa({
                permissionType: "dataLayer",
                permissionParams: {
                    key: c,
                    operation: 2
                }
            }) : !1
        }, xv.read_title = function(a) {
            return a.oa({
                permissionType: "readTitle",
                permissionParams: null
            })
        }, xv.send_pixel = wv, xv.set_cookies = uv, xv),
        zv = {},
        Av = (zv.callInWindow = function(a) {
                var b = a.l,
                    c = a.X;
                return function(d) {
                    var e = la.apply(1, arguments);
                    iv(d);
                    c.checkPermission({
                        permissionType: "globals",
                        permissionParams: {
                            key: d,
                            operation: 4
                        }
                    });
                    var f = I(b, d);
                    if (!A(f)) throw S("ca.c.wenf");
                    e = f.apply(null, ca(e));
                    return kv(b, e)
                }
            }, zv.callLater = function(a) {
                var b = a.l;
                return function(c) {
                    X(b,
                        c, 0)
                }
            }, zv.copyFromDataLayer = function(a) {
                var b = a.l,
                    c = a.X,
                    d = a.event;
                return function(e) {
                    if (!d) throw S("No dataLayer data");
                    c.checkPermission({
                        permissionType: "dataLayer",
                        permissionParams: {
                            key: e,
                            operation: 2
                        }
                    });
                    return kv(b, I(d, e))
                }
            }, zv.copyFromWindow = function(a) {
                var b = a.l,
                    c = a.X;
                return function(d) {
                    iv(d);
                    c.checkPermission({
                        permissionType: "globals",
                        permissionParams: {
                            operation: 2,
                            key: d
                        }
                    });
                    d = I(b, d);
                    return kv(b, d)
                }
            }, zv.createArgumentsQueue = function(a) {
                var b = a.l,
                    c = a.X;
                return function(d, e) {
                    function f() {
                        return g.push(arguments)
                    }
                    c.checkPermission({
                        permissionType: "globals",
                        permissionParams: {
                            key: d,
                            operation: 2
                        }
                    });
                    c.checkPermission({
                        permissionType: "globals",
                        permissionParams: {
                            key: d,
                            operation: 1
                        }
                    });
                    c.checkPermission({
                        permissionType: "globals",
                        permissionParams: {
                            key: e,
                            operation: 2
                        }
                    });
                    c.checkPermission({
                        permissionType: "globals",
                        permissionParams: {
                            key: e,
                            operation: 1
                        }
                    });
                    iv(d);
                    iv(e);
                    var g = [],
                        h = qv(b, d);
                    h.value || (h.parent[h.Kc] = f);
                    h = qv(b, e);
                    if (h.value) {
                        if (!K(h.value)) throw S("ca.akna");
                        g = h.value
                    } else h.parent[h.Kc] = g;
                    return f
                }
            }, zv.createQueue =
            function(a) {
                var b = a.l,
                    c = a.X;
                return function(d) {
                    c.checkPermission({
                        permissionType: "globals",
                        permissionParams: {
                            key: d,
                            operation: 2
                        }
                    });
                    c.checkPermission({
                        permissionType: "globals",
                        permissionParams: {
                            key: d,
                            operation: 1
                        }
                    });
                    iv(d);
                    var e = qv(b, d);
                    d = e.value;
                    var f = e.parent;
                    e = e.Kc;
                    if (!d) f[e] = [];
                    else if (!K(d)) throw S("akna");
                    return C(f[e].push, f[e])
                }
            }, zv.decodeUri = function(a) {
                var b = a.l;
                return function(c) {
                    try {
                        return b.decodeURI(c)
                    } catch (d) {}
                }
            }, zv.decodeUriComponent = function(a) {
                var b = a.l;
                return function(c) {
                    try {
                        return b.decodeURIComponent(c)
                    } catch (d) {}
                }
            },
            zv.encodeUri = function(a) {
                var b = a.l;
                return function(c) {
                    try {
                        return b.encodeURI(c)
                    } catch (d) {}
                }
            }, zv.encodeUriComponent = function(a) {
                var b = a.l;
                return function(c) {
                    try {
                        return b.encodeURIComponent(c)
                    } catch (d) {}
                }
            }, zv.getCookieValues = function(a) {
                var b = a.l,
                    c = a.X;
                return function(d, e) {
                    e = void 0 === e ? !0 : e;
                    c.checkPermission({
                        permissionType: "cookies",
                        permissionParams: {
                            name: d,
                            operation: 2
                        }
                    });
                    return F(function(f, g) {
                        var h = q(ke(g).split("=")),
                            k = h.next().value;
                        h = h.next().value;
                        k === d && f.push(e ? Ud(h) : h);
                        return f
                    }, [], b.document.cookie.split(";"))
                }
            },
            zv.getTimestamp = function(a) {
                var b = a.l;
                return function() {
                    return Ed(b)(Ad)
                }
            }, zv.getType = function(a) {
                var b = a.l;
                return function(c) {
                    return B(c) ? "undefined" : Qa(c) ? "null" : Sb(b, c) ? "number" : y(c) ? "string" : !0 === c || !1 === c ? "boolean" : A(c) ? "function" : K(c) ? "array" : "object"
                }
            }, zv.getUrl = function(a) {
                var b = a.l,
                    c = a.X;
                return function(d) {
                    d = J(d, tv) ? d : "href";
                    c.checkPermission({
                        permissionType: "url",
                        permissionParams: {
                            urlComponent: d
                        }
                    });
                    var e = U(b);
                    e.query = e.search.replace(/^\?/, "");
                    return gv(e, d)
                }
            }, zv.injectHiddenIframe = function(a) {
                var b =
                    a.l,
                    c = a.X;
                return function(d, e) {
                    e = void 0 === e ? u : e;
                    c.checkPermission({
                        permissionType: "iframe",
                        permissionParams: {
                            url: d
                        }
                    });
                    var f = Lf(b)("iframe");
                    M(f.style, {
                        display: "none",
                        width: "1px",
                        height: "1px",
                        visibility: "hidden"
                    });
                    f.src = d;
                    f.onload = function() {
                        return e()
                    };
                    f.onerror = u;
                    Qf(b).appendChild(f)
                }
            }, zv.JSON = function(a) {
                var b = a.l;
                return {
                    parse: function(c) {
                        try {
                            return b.JSON.parse("" + c)
                        } catch (d) {}
                    },
                    stringify: function(c) {
                        try {
                            return b.JSON.stringify(c)
                        } catch (d) {}
                    }
                }
            }, zv.loadScript = function(a) {
                var b = a.l,
                    c = a.X;
                return function(d,
                    e, f) {
                    c.checkPermission({
                        permissionType: "loadScript",
                        permissionParams: {
                            url: d
                        }
                    });
                    Jt(b, d, A(e) ? Yu("ls.ol", function() {
                        return e.apply(null)
                    }) : u, A(f) ? Yu("ls.ol", function() {
                        return f.apply(null)
                    }) : void 0)
                }
            }, zv.localStorage = function(a) {
                var b = a.X,
                    c = a.l.localStorage;
                return {
                    getItem: function(d) {
                        b.checkPermission({
                            permissionType: "localStorage",
                            permissionParams: {
                                key: d,
                                operation: 2
                            }
                        });
                        return c.getItem(d)
                    },
                    setItem: function(d, e) {
                        b.checkPermission({
                            permissionType: "localStorage",
                            permissionParams: {
                                key: d,
                                operation: 1
                            }
                        });
                        c.setItem(d, e)
                    },
                    removeItem: function(d) {
                        b.checkPermission({
                            permissionType: "localStorage",
                            permissionParams: {
                                key: d,
                                operation: 1
                            }
                        });
                        c.removeItem(d)
                    }
                }
            }, zv.logToConsole = function(a) {
                var b = a.l,
                    c = a.X;
                return function() {
                    var d = la.apply(0, arguments);
                    if (c.oa({
                            permissionType: "log",
                            permissionParams: {
                                logLevel: 0
                            }
                        })) {
                        var e;
                        (e = Wk(b)).log.apply(e, ca(d))
                    }
                }
            }, zv.Math = function(a) {
                return sv(a.l.Math, "abs floor ceil round max min pow sqrt".split(" "))
            }, zv.Object = function(a) {
                var b = a.l;
                return {
                    keys: cc,
                    values: fc,
                    freeze: function(c) {
                        return b.Object.freeze(c)
                    },
                    entries: bc,
                    "delete": function(c, d) {
                        if (!c || !H(c, d) || K(c) || c === b) return !1;
                        try {
                            return delete c[d]
                        } catch (e) {
                            return !1
                        }
                    }
                }
            }, zv.queryPermission = function(a) {
                var b = a.X;
                return function(c, d, e) {
                    return (B(d) || y(d)) && H(yv, c) ? (0, yv[c])(b, c, d, e) : !1
                }
            }, zv.readTitle = function(a) {
                var b = a.l,
                    c = a.X;
                return function() {
                    c.checkPermission({
                        permissionType: "readTitle",
                        permissionParams: null
                    });
                    return b.document.title
                }
            }, zv.sendPixel = function(a) {
                var b = a.X,
                    c = a.l;
                return function(d, e, f) {
                    e = void 0 === e ? u : e;
                    f = void 0 === f ? u : f;
                    if (!y(d)) throw S("ca.p.uns");
                    b.checkPermission({
                        permissionType: "pixel",
                        permissionParams: {
                            url: d
                        }
                    });
                    rv(c, d, e, f)
                }
            }, zv.setCookie = function(a) {
                var b = a.l,
                    c = a.X;
                return function(d, e, f, g) {
                    f = void 0 === f ? {} : f;
                    g = void 0 === g ? !0 : g;
                    c.checkPermission({
                        permissionType: "cookies",
                        permissionParams: {
                            name: d,
                            operation: 1,
                            options: f
                        }
                    });
                    e = g ? Td(e) : e;
                    d = d + "=" + e + ";";
                    if (f) {
                        H(f, "domain") && (d += " Domain=" + f.domain + ";");
                        H(f, "path") && (d += " Path=" + f.path + ";");
                        H(f, "expires") && (d += " Expires=" + f.expires + ";");
                        if (H(f, "max-age")) {
                            if (!Sb(b, f["max-age"])) throw S("ca.c.mann");
                            d += " Max-Age=" + f["max-age"] + ";"
                        }
                        if (H(f, "sameSite")) {
                            if (!J(f.sameSite, ["Lax", "Strict", "None"])) throw S("ca.c.ssuop");
                            d += " Same-Site=" + f.sameSite + ";"
                        }
                        H(f, "secure") && f.secure && (d += " Secure;")
                    }
                    b.document.cookie = d
                }
            }, zv.setInWindow = function(a) {
                var b = a.l,
                    c = a.X;
                return function(d, e, f) {
                    f = void 0 === f ? !1 : f;
                    c.checkPermission({
                        permissionType: "globals",
                        permissionParams: {
                            key: d,
                            operation: 1
                        }
                    });
                    iv(d);
                    try {
                        var g = qv(b, d),
                            h = g.parent,
                            k = g.Kc;
                        if (!f && H(h, k)) return !1;
                        h[k] = e;
                        return !0
                    } catch (l) {
                        return !1
                    }
                }
            }, zv);

    function Bv(a) {
        return H(Av, a) ? Av[a] : void 0
    }

    function Cv(a, b) {
        for (var c = a.length; 0 < c;) {
            var d = a[--c];
            if (H(d.De, b)) return d.De[b]
        }
    }

    function Dv(a, b, c) {
        b = void 0 === b ? {} : b;
        c = void 0 === c ? {} : c;
        b = void 0 === b ? {} : b;
        c = void 0 === c ? {} : c;
        return a.concat({
            De: b,
            methods: c,
            pc: !0
        })
    }

    function Ev(a, b, c, d) {
        for (var e = a.length - 1; 0 <= e; --e) {
            var f = a[e];
            f.pc = !1;
            if (H(f.methods, b)) {
                f.methods[b](d ? d() : void 0);
                return
            }
        }
        throw S(c);
    }

    function Fv(a, b) {
        var c = q(b);
        c.next();
        var d = c.next().value,
            e = c.next().value,
            f = c.next().value,
            g = L(v, a);
        return function() {
            var h = arguments,
                k = F(function(m, p, r) {
                    if (m[p]) throw S("da");
                    m[p] = {
                        kind: 1,
                        value: h[r]
                    };
                    return m
                }, {}, e);
            d && !J(d, e) && (k[d] = {
                kind: 0,
                value: d
            });
            var l;
            Gv(g, f, k, {
                "return": function(m) {
                    l = m
                }
            });
            return l
        }
    }

    function Hv(a) {
        return K(a) && 42 === a[0]
    }

    function Iv(a) {
        return K(a) && 35 === a[0]
    }

    function Jv(a, b) {
        var c = q(b);
        c.next();
        c = ba(c);
        return F(function(d, e) {
            var f = q(e),
                g = f.next().value;
            f = f.next().value;
            g = Kv(a, g);
            f = Kv(a, f);
            d["" + g] = f;
            return d
        }, {}, c)
    }

    function Lv(a) {
        return K(a) && 40 === a[0]
    }

    function Mv(a, b) {
        var c = q(b);
        c.next();
        c = ba(c);
        return L(function(d) {
            return Kv(a, d)
        }, c)
    }

    function Nv(a, b) {
        var c = q(b);
        c.next();
        var d = c.next().value,
            e = c.next().value;
        c = c.next().value;
        e = Kv(a, e);
        c = Kv(a, c);
        switch (d) {
            case "==":
                return e == c;
            case "!=":
                return e != c;
            case "===":
                return e === c;
            case "!==":
                return e !== c;
            case "<":
                return e < c;
            case "<=":
                return e <= c;
            case ">":
                return e > c;
            case ">=":
                return e >= c;
            case "<<":
                return e << c;
            case ">>":
                return e >> c;
            case ">>>":
                return e >>> c;
            case "+":
                return e + c;
            case "-":
                return e - c;
            case "*":
                return e * c;
            case "/":
                return e / c;
            case "%":
                return e % c;
            case "|":
                return e | c;
            case "^":
                return e ^
                    c;
            case "&":
                return e & c;
            case "in":
                return e in c;
            case "instanceof":
                return e instanceof c;
            default:
                throw S("uo");
        }
    }

    function Ov(a, b) {
        var c = q(b);
        c.next();
        var d = c.next().value;
        c = c.next().value;
        c = Kv(a, c);
        switch (d) {
            case "+":
                return +c;
            case "!":
                return !c;
            case "-":
                return -c;
            case "~":
                return ~c;
            default:
                throw S("uo");
        }
    }

    function Pv(a, b, c) {
        c = void 0 === c ? [] : c;
        if (Lv(b)) {
            b = q(b);
            b.next();
            b = b.next().value;
            a = Cv(a, b);
            if (!a) throw S("vnd");
            if (0 === a.kind && 0 === c.length) throw S("cva");
            return {
                Gh: c,
                bi: a
            }
        }
        if (Iv(b)) {
            var d = q(b);
            d.next();
            b = d.next().value;
            d = d.next().value;
            d = Kv(a, d);
            c.push("" + d);
            return Pv(a, b, c)
        }
        throw S("iat");
    }

    function Qv(a, b, c, d) {
        b = Pv(a, b);
        a = b.bi;
        var e = b.Gh;
        e.unshift("value");
        b = e.pop();
        a = F(function(f, g) {
            return f[g]
        }, a, e);
        switch (d) {
            case "=":
                return a[b] = c;
            case "+=":
                return a[b] += c;
            case "-=":
                return a[b] -= c;
            case "*=":
                return a[b] *= c;
            case "/=":
                return a[b] /= c;
            case "%=":
                return a[b] %= c;
            case "<<=":
                return a[b] <<= c;
            case ">>=":
                return a[b] >>= c;
            case ">>>=":
                return a[b] >>>= c;
            case "|=":
                return a[b] |= c;
            case "^=":
                return a[b] ^= c;
            case "&=":
                return a[b] &= c;
            default:
                throw S("uo");
        }
    }

    function Kv(a, b) {
        if (y(b) || "[object Number]" === Object.prototype.toString.call(b) || !!b === b || Hv(b)) return Hv(b) ? null : b;
        if (Lv(b)) {
            var c = q(b);
            c.next();
            c = c.next().value;
            c = Cv(a, c);
            if (!c) throw S("vnd");
            return c.value
        }
        if (K(b) && 37 === b[0]) {
            var d = q(b);
            d.next();
            c = d.next().value;
            d = ba(d);
            c = Kv(a, c);
            if (!A(c)) throw S("tenf");
            d = L(E(a, Kv), d);
            return c.apply(null, d)
        }
        if (K(b) && 24 === b[0]) return Fv(a, b);
        if (Iv(b)) {
            d = q(b);
            d.next();
            c = d.next().value;
            d = d.next().value;
            c = Kv(a, c);
            d = Kv(a, d);
            if (!c) throw S("noma");
            return c["" + d]
        }
        if (K(b) &&
            23 === b[0]) return Jv(a, b);
        if (K(b) && 22 === b[0]) return Mv(a, b);
        if (K(b) && 29 === b[0]) return Nv(a, b);
        if (K(b) && 25 === b[0]) return Ov(a, b);
        if (K(b) && 27 === b[0]) {
            d = q(b);
            d.next();
            var e = d.next().value;
            c = d.next().value;
            d = d.next().value;
            switch (e) {
                case "++":
                    e = "+=";
                    break;
                case "--":
                    e = "-=";
                    break;
                default:
                    throw S("uo");
            }
            c ? c = Qv(a, d, 1, e) : (c = Kv(a, d), Qv(a, d, 1, e));
            return c
        }
        if (K(b) && 31 === b[0]) return e = q(b), e.next(), c = e.next().value, d = e.next().value, e = e.next().value, e = Kv(a, e), Qv(a, d, e, c);
        if (K(b) && 33 === b[0]) {
            c = q(b);
            c.next();
            d = c.next().value;
            e = c.next().value;
            c = c.next().value;
            if ("&&" === d) c = (d = Kv(a, e)) ? Kv(a, c) : d;
            else if ("||" === d) c = (d = Kv(a, e)) ? d : Kv(a, c);
            else throw S("uo");
            return c
        }
        if (K(b) && 36 === b[0]) return e = q(b), e.next(), d = e.next().value, c = e.next().value, e = e.next().value, d = Kv(a, d), Kv(a, d ? c : e)
    }

    function Rv(a) {
        return K(a) && (18 === a[0] || 19 === a[0])
    }

    function Sv(a, b) {
        var c = q(b),
            d = c.next().value;
        c = ba(c);
        var e = 18 === d;
        L(function(f) {
            var g = q(f),
                h = g.next().value;
            g = g.next().value;
            if (e && 1 === f.length) throw S("mca");
            f = a[a.length - 1].De;
            if (H(f, h)) throw S("vr");
            g = B(g) ? g : Kv(a, g);
            f[h] = {
                kind: e ? 0 : 1,
                value: g
            }
        }, c)
    }

    function Tv(a, b) {
        var c = q(b);
        c.next();
        var d = c.next().value;
        Ev(a, "return", "irs", function() {
            return B(d) ? d : Kv(a, d)
        })
    }

    function Uv(a) {
        var b = {
            hd: !1
        };
        a = Dv(a, void 0, {
            "continue": function() {
                b.hd = !0
            },
            "break": u
        });
        b.stack = a;
        b.Cg = a[a.length - 1];
        return b
    }

    function Vv(a, b) {
        if (K(b) && 3 === b[0]) Gv(a, b);
        else if (Rv(b)) Sv(a, b);
        else if (K(b) && 2 === b[0]) {
            var c = q(b);
            c.next();
            c = c.next().value;
            Kv(a, c)
        } else if (K(b) && 7 === b[0]) {
            var d = q(b);
            d.next();
            c = d.next().value;
            var e = d.next().value;
            d = d.next().value;
            Kv(a, c) ? Vv(a, e) : d && Vv(a, d)
        } else if (8 === b[0]) {
            c = q(b);
            c.next();
            var f = c.next().value;
            c = ba(c);
            d = e = !1;
            var g = [],
                h = [];
            f = Kv(a, f);
            for (var k = 0; k < c.length; k += 1) {
                var l = q(c[k]);
                l.next();
                var m = l.next().value;
                l = ba(l);
                var p = Qa(m);
                d = d || p;
                p || (e = e || Kv(a, m) === f);
                e && (g = g.concat(l));
                d && (h =
                    h.concat(l))
            }
            Gv(a, [3].concat(ca(e ? g : h)), {}, {
                "break": u
            })
        } else if (K(b) && 4 === b[0]) Tv(a, b);
        else if (K(b) && 5 === b[0]) Ev(a, "break", "ibs");
        else if (K(b) && 6 === b[0]) Ev(a, "continue", "ics");
        else if (K(b) && 15 === b[0])
            for (d = q(b), d.next(), h = d.next().value, c = d.next().value, e = d.next().value, d = d.next().value, g = Uv(a), h && (Rv(h) ? Sv(g.stack, h) : Kv(g.stack, h)), h = !0; h && (!c || Kv(g.stack, c));) h = g.Cg, Vv(g.stack, d), g.hd && (h.pc = !0, g.hd = !1), h = h.pc, e && h && Kv(g.stack, e)
    }

    function Gv(a, b, c, d) {
        b = q(b);
        b.next();
        b = ba(b);
        a = Dv(a, c, d);
        c = a[a.length - 1];
        for (d = 0; d < b.length && c.pc; d += 1) Vv(a, b[d])
    }

    function Wv(a, b, c) {
        b = q(b);
        b.next();
        b.next();
        b = ba(b);
        a = {
            X: c.X,
            l: a,
            event: c.event
        };
        var d = {};
        c = M(c.data, (d.ytmOnFailure = u, d.ytmOnSuccess = u, d));
        d = {};
        c = Dv([], (d.undefined = {
            kind: 0,
            value: void 0
        }, d.require = {
            kind: 0,
            value: G(Bv, qa(Qe)(a))
        }, d.data = {
            kind: 0,
            value: c
        }, d));
        Gv(c, [3].concat(ca(b)))
    }

    function Xv(a, b) {
        return {
            checkPermission: function(c) {
                c = M({
                    permissions: a
                }, c);
                b.checkPermission(c)
            },
            oa: function(c) {
                c = M({
                    permissions: a
                }, c);
                return b.oa(c)
            }
        }
    }

    function Yv(a, b) {
        if (!H(b, "code") || !K(b.code) || !b.code[a]) throw S("mp");
        return b.code[a]
    }

    function Zv(a, b, c, d, e) {
        var f = d.data;
        f = K(f) ? f : Yv(f, b);
        var g = Xv(e.permissions, e.X);
        d = F(function(h, k) {
            var l = q(k),
                m = l.next().value;
            l = l.next().value;
            l = B(l) ? l : nv(a, c, b.variables, l, e);
            h[m] = kv(a, l);
            return h
        }, {}, bc(d.settings || {}));
        Wv(a, f, {
            X: g,
            data: d,
            event: c
        })
    }

    function $v(a, b, c, d, e) {
        L(Yu("t.e", function(f) {
            var g = b.tags[f],
                h = b.permissions[f];
            if (!g || !h) throw S("i.conf." + b.containerVersion + "-" + f);
            var k = {
                X: e,
                permissions: h
            };
            "pro" === g.type ? Zv(a, b, c, g, k) : "pix" === g.type && (f = k.X, h = k.permissions, g = nv(a, c, b.variables, g.data.pixelUrl, k), y(g) && (f.checkPermission({
                permissions: h,
                permissionType: "pixel",
                permissionParams: {
                    url: g
                }
            }), rv(a, g, u, u)))
        }), sl(function(f, g) {
            return f - g
        }, d))
    }

    function aw(a, b, c) {
        var d = b.triggers,
            e = b.variables;
        return {
            dispatchEvent: function(f) {
                var g = F(function(h, k) {
                    Ob(function(l) {
                        return !pv(a, f, l, e)
                    }, k.conditions) || L(function(l) {
                        J(l, h) || h.push(l)
                    }, k.tags);
                    return h
                }, [], d);
                0 === g.length || $v(a, b, f, g, c)
            }
        }
    }

    function bw(a, b) {
        return b.length > a.length ? !1 : a.substring(a.length - b.length) === b
    }

    function cw(a, b, c) {
        b = qh(a, b);
        if (!b.protocol || "https:" !== b.protocol) return !1;
        a = qh(a, c);
        return b.host && a.host && (tj(a.host, "*.") ? bw(b.host, a.host.substring(2)) : b.host === a.host) ? "/" === a.pathname ? !0 : bw(a.pathname, "/*") ? tj(b.pathname, a.pathname.substring(0, a.pathname.length - 2)) : a.pathname === b.pathname : !1
    }

    function dw(a, b, c, d) {
        if (!H(a, "cookies")) return !1;
        var e = a.cookies;
        a = H(e, b) ? e[b] : {
            access: 0
        };
        if (2 === c) return H(e, "ytm.ks.*") || !!(a.access & c);
        if (1 === c) {
            if (!H(e, b) || !d) return !1;
            b = a.access;
            e = a.domain;
            var f = a.path,
                g = a.secure,
                h = a.Ii,
                k = !Ra(d.expires) || !Ra(d["max-age"]);
            if (H(a, "session") && h)
                if (1 === h) {
                    if (k) return !1
                } else if (!k) return !1;
            return !(b & c) || H(a, "domain") && e !== d.domain || H(a, "path") && f !== d.path || H(a, "secure") && (1 === g && !d.secure || 2 === g && d.secure) ? !1 : !0
        }
        return !1
    }

    function ew(a, b) {
        var c = b.permissionType,
            d = b.permissions,
            e = b.permissionParams;
        if ("globals" === c || "localStorage" === c || "dataLayer" === c) {
            var f = e.key;
            e = e.operation;
            H(d, c) ? (d = d[c], c = "dataLayer" === c && H(d, "ytm.ks.*") && d["ytm.ks.*"] & e ? !0 : H(d, f) ? !!(d[f] & e) : !1) : c = !1
        } else "url" === c || "referrer" === c ? (f = e.urlComponent, e = e.variableName, H(d, c) ? (c = d[c], c = "queryVar" === f ? H(c, "queryVars") && e ? J(e, c.queryVars) : !1 : !!c[f]) : c = !1) : "log" === c ? (c = e.logLevel, c = H(d, "log") ? c >= d.log : !1) : "loadScript" === c || "pixel" === c || "iframe" === c ? (f =
            e.url, H(d, c) && H(d[c], "allow") ? (c = d[c], c = Ob(D([a, f], cw), c.allow)) : c = !1) : c = "cookies" === c ? dw(d, e.name, e.operation, e.options) : "readTitle" === c ? H(d, "readTitle") ? d.readTitle : !1 : !1;
        return c
    }

    function fw(a, b) {
        return {
            containerId: b,
            permissionType: a.permissionType,
            permissionParams: a.permissionParams
        }
    }

    function gw(a, b) {
        function c(e) {
            var f = H(d, e.permissionType) && d[e.permissionType];
            if (f) {
                var g = fw(e, b);
                if (Ob(function(h) {
                        try {
                            return !1 === h(g, b)
                        } catch (k) {
                            return !0
                        }
                    }, f)) return !1
            }
            return ew(a, e)
        }
        var d = {};
        return {
            kg: function(e, f) {
                y(e) && A(f) && (H(d, e) || (d[e] = []), d[e].push(f))
            },
            checkPermission: function(e) {
                if (!c(e)) {
                    e = fw(e, b);
                    var f = Error("Permission denied for " + e.permissionType);
                    f.cause = e;
                    md(f)
                }
            },
            oa: c
        }
    }
    var hw = x(function(a) {
            a = U(a).search;
            return Vd(a.substring(1))._ytm_preview
        }),
        iw = W("p.ips", function(a, b) {
            Wh(b, function(c) {
                (I(c, "settings.phchange") || I(c, "settings.phhide")) && Lt(a, "tag_phone", b, c)
            })
        }),
        jw = W("p.suic", function(a, b) {
            return Wh(b, function(c) {
                var d = Sc(a);
                if (!d.C("pic") && !Bm(c) && (c = I(c, "settings.pic"))) {
                    var e = Rh(a, "pic");
                    d.D("pic", 1);
                    return e({
                        N: {
                            Wc: !1,
                            Nc: !0
                        }
                    }, [c]).then(function(f) {
                        y(f.Ga) && (f = xf(a, f.Ga)) && (f = I(f, "ymaf"), y(f) && f && we(a, "_ym_fa", f, 43200))
                    })
                }
            })["catch"](V(a, "pic"))
        }),
        kw = W("p.tv",
            function(a) {
                if (Hl(a)) {
                    var b = O(a);
                    Il(a).then(function(c) {
                        b.D("lgguid", c)
                    }, V(a, "p.tv.p"))
                }
            }),
        lw = W("p.cm", function(a) {
            Sc(a).sa("mcs", W("p.cm.cs", function(b, c, d, e, f) {
                if (fi(a, c)) return Fo(b, c, d, e, f);
                md(S("cmws.cd"))
            })).sa("wsfm", Vg)
        }),
        mw = {},
        nw = x(Ce),
        ow = G(Wa("exec", /counterID=(\d+)/), db("1"));

    function pw(a, b) {
        var c = "" + b,
            d = {
                id: 1,
                ca: "0"
            },
            e = ow(c);
        e ? d.id = e : -1 === La(c, ":") ? (c = Vb(c), d.id = c) : (e = q(c.split(":")), c = e.next().value, e = e.next().value, d.id = Vb(c), d.ca = Oc(e) ? "1" : "0");
        return [fi(a, d), d]
    }
    var qw = pa(function(a, b) {
            var c = nw(a),
                d = q(vb(b)),
                e = d.next().value,
                f = d.next().value,
                g = ba(d);
            if (f) {
                d = q(pw(a, e));
                var h = d.next().value,
                    k = d.next().value;
                d = N(k);
                c[d] || (c[d] = {});
                c = c[d];
                b.Qe || mw[f] && F(function(l, m) {
                    return l || !!m(a, k, g, h)
                }, !1, mw[f]) || ("init" === f ? (b.Qe = !0, h ? (f = {}, Zh(a, "" + e, "dc", (f.key = e, f))) : a["yaCounter" + k.id] = new a.Ya[Nc.fc](M({}, g[0], k))) : h && h[f] && c.ih ? (h[f].apply(h, ca(g)), b.Qe = !0) : (d = c.Mf, d || (d = [], c.Mf = d), d.push(Pe([e, f], g))))
            }
        }),
        rw = W("destruct.e", function(a, b, c) {
            return function() {
                var d =
                    O(a),
                    e = b.id;
                L(function(f, g) {
                    return A(f) && V(a, "dest.fr." + g, f)()
                }, c);
                delete d.C("counters")[N(b)];
                delete a["yaCounter" + e]
            }
        });

    function sw(a, b, c, d) {
        return function() {
            var e = Ha(arguments);
            e = d.apply(null, ca(e));
            return B(e) ? fi(a, b) : e
        }
    }

    function tw(a, b, c, d) {
        return V(a, "cm." + c, d)
    }

    function uw(a, b, c, d, e) {
        if (!c.length) return e;
        c = L(function(f) {
            return D([a, b, d], f)
        }, c);
        return G.apply(null, ca(c))(e)
    }
    var vw = O(window);
    vw.sa("hitParam", {});
    vw.sa("lastReferrer", window.location.href);
    ji.push(function(a, b) {
        var c = {};
        return c.firstPartyParams = yi(a, b), c.firstPartyParamsHashed = Ai(a, b), c
    });
    qf.push("fpp");
    qf.push("fpmh");
    (function() {
        var a = O(window);
        a.sa("getCounters", Gi(window));
        ii.push(Hi);
        li.push(function(b, c) {
            c.counters = a.C("getCounters")
        })
    })();
    Qh["1"] = ef;
    ji.push(Qi);
    Mh["1"] = Gh;
    hh(Mi, -1);
    jh["1"] = [
        [Mi, -1],
        [gf, 1],
        [bh, 2],
        [Vg(), 3],
        [eh, 4]
    ];
    ji.push(aj);
    ji.push(W("p.ar", function(a, b) {
        var c = Rh(a, "a", b),
            d = {};
        return d.hit = function(e, f, g, h, k, l) {
            var m = {};
            m = {
                H: {},
                K: Le((m.pv = 1, m.ar = 1, m))
            };
            f = Sa(f) ? {
                title: f.title,
                uf: f.referer,
                O: f.params,
                $b: f.callback,
                l: f.ctx
            } : {
                title: f,
                uf: g,
                O: h,
                $b: k,
                l: l
            };
            h = Oi(b);
            g = e || U(a).href;
            h.url !== g && (h.ref = h.url, h.url = e);
            e = f.uf || h.ref || a.document.referrer;
            h = {};
            h = $h(a, b, "pv", (h.id = b.id, h.url = g, h.ref = e, h), f.O);
            k = M(m.M || {}, {
                O: f.O,
                title: f.title
            });
            l = {};
            m = c(M(m, {
                M: k,
                H: M(m.H || {}, (l["page-url"] = g, l["page-ref"] = e, l))
            }), b).then(h);
            return Ni(a,
                "p.ar.s", m, f.$b || u, f.l)
        }, d
    }));
    Qh.a = ef;
    jh.a = fh;
    Mh.a = Gh;
    ji.push(dj);
    Qh.g = ef;
    Mh.g = Gh;
    jh.g = fh;
    ji.push(ej);
    ji.push(jj);
    jh.t = fh;
    Qh.t = ef;
    Mh.t = Gh;
    ji.push(W("cl.p", function(a, b) {
        function c(p, r, t, w) {
            w = void 0 === w ? {} : w;
            t ? mj(a, b, {
                url: t,
                ob: !0,
                wc: p,
                Ac: r,
                sender: d,
                Yf: w
            }) : g.warn("clel")
        }
        var d = Rh(a, "2", b),
            e = [],
            f = N(b),
            g = Yh(a, f),
            h = V(a, "s.s.tr", E(Ei(a, f), lj));
        f = {
            l: a,
            fb: b,
            Mg: e,
            sender: d,
            yi: O(a),
            zg: Gf(a, b.id),
            Ai: lg(a),
            Wh: E(E(f, Fi(a)), G(Qe, db("trackLinks")))
        };
        f = V(a, "cl.p.c", E(f, nj));
        f = ud(a).F(a, ["click"], f);
        b.Uf && h(b.Uf);
        var k = V(a, "file.clc", D([!0, !1], c)),
            l = V(a, "e.l.l.clc", D([!1, !0], c));
        e = V(a, "add.f.e.clc", oj(e));
        var m = {};
        return m.file = k, m.extLink = l, m.addFileExtension =
            e, m.trackLinks = h, m.u = f, m
    }));
    jh["2"] = fh;
    Qh["2"] = ef;
    Mh["2"] = Gh;
    Qh.r = df("r");
    Mh.r = ["f", "x", "j", "i"];
    ki.push(W("p.r", function(a, b) {
        var c = wj(a),
            d = Rh(a, "r", b),
            e = V(a, "rts.p");
        return Wh(b, D([function(f, g) {
            var h = {
                    id: g.yg,
                    ca: g.ca
                },
                k = {
                    N: {
                        ba: g.Eh
                    },
                    K: Le(g.pg),
                    H: g.O,
                    M: {
                        Qb: g.Qb
                    },
                    ma: {
                        ra: g.ra
                    }
                };
            g.Ia && (k.Ia = nf(g.Ia));
            h = d(k, h)["catch"](e);
            return f.then(E(h, v))
        }, Q.resolve(), c], F)).then(E(void 0, v))["catch"](e)
    }));
    kh("r", function(a) {
        return {
            R: function(b, c) {
                var d = void 0 === b.K ? Le() : b.K,
                    e = b.M.Qb,
                    f = pj(a),
                    g = d.C("rqnl", 0) + 1;
                d.D("rqnl", g);
                if (d = I(f, T(".", [e, "browserInfo"]))) d.rqnl = g, qj(a);
                c()
            },
            ta: function(b, c) {
                rj(a, b);
                c()
            }
        }
    }, 1);
    hh(sj, 100);
    kh("1", sj, 100);
    ji.push(yj);
    kh("n", gf, 1);
    kh("n", bh, 2);
    kh("n", Vg(), 3);
    kh("n", sj, 100);
    Qh.n = ef;
    Mh.n = Gh;
    Ve({
        He: {
            da: "accurateTrackBounce"
        }
    });
    ji.push(Uj);
    Qh.m = df("cm");
    Mh.m = Kh;
    kh("m", Vg(["u", "v", "vf"]), 1);
    kh("m", sj, 2);
    Ve({
        vg: {
            da: "clickmap"
        }
    });
    ji.push(Vj);
    ji.push(Xj);
    ji.push(jk);
    ji.push(qk);
    ji.push(Ik);
    qf.push("ecommerce");
    Ve({
        od: {
            da: "ecommerce",
            Va: function(a) {
                if (a) return !0 === a ? "dataLayer" : "" + a
            }
        }
    });
    ji.push(Nk);
    qf.push("user_id");
    ji.push(Ok);
    hh(function(a, b) {
        return {
            ta: function(c, d) {
                var e = fi(a, b);
                e = e && e.userParams;
                var f = (c.M || {}).Be;
                e && f && e(f);
                d()
            }
        }
    }, 0);
    pe.push("_ym_debug");
    mi.unshift(Rk);
    ji.push(Sk);
    var ww = {},
        xw = (ww.tp = G(Da, Ki, ib), ww.tpid = G(Da, function(a) {
            a = N(a);
            return Ii[a] && Ii[a].Vh || null
        }), ww);
    M(Tg, xw);
    hh(Tk, 20);
    kh("n", Tk, 20);
    kh("1", Tk, 20);
    mi.unshift(Vk);
    Tg.fp = function(a, b, c) {
        if (c.H && c.H.nohit) return null;
        c = O(a).C;
        if (!c("fpe")) return null;
        b = Uk(b);
        if (b.Og) return null;
        c = c("fht", Infinity);
        a: {
            var d = I(a, "performance.getEntriesByType");
            if (A(d)) {
                if (a = nb(G(v, db("name"), ra("first-contentful-paint")), d.call(a.performance, "paint")), a.length) {
                    a = a[0].startTime;
                    break a
                }
            } else {
                var e = I(a, "chrome.loadTimes");
                d = Qg(a);
                if (A(e) && (e = e.call(a.chrome), e = I(e, "firstPaintTime"), d && e)) {
                    a = 1E3 * e - d;
                    break a
                }
                if (a = I(a, "performance.timing.msFirstPaint")) {
                    a -= d;
                    break a
                }
            }
            a = void 0
        }
        return a &&
            c > a ? (b.Og = a, Math.round(a)) : null
    };
    ji.push(function(a, b) {
        var c = {};
        return c.ecommerceAdd = W("ecm.a", Zk(a, b)), c.ecommerceRemove = W("ecm.r", $k(a, b)), c.ecommerceDetail = W("ecm.d", al(a, b)), c.ecommercePurchase = W("ecm.p", bl(a, b)), c
    });
    (function() {
        var a = {
            bu: Jl,
            pri: Zl
        };
        a.wv = E(2, v);
        a.ds = Wl;
        a.co = function(c) {
            return jb(O(c).C("jn"))
        };
        a.td = am;
        var b = {};
        M(a, (b.iss = G(Ac, ib), b.hdl = G(Bc, ib), b.iia = G(Dc, ib), b.cpf = G(tl, ib), b.ntf = x(function(c) {
            c = I(c, "Notification.permission");
            c = "denied" === c ? !1 : "granted" === c ? !0 : null;
            return Qa(c) ? null : c ? 2 : 1
        }), b.eu = ul("isEU"), b.ns = Qg, b.np = function(c) {
            return Xd(c, 0, 100) ? null : Cl(ke(kc(c), 100))
        }, b));
        a.pani = Ll;
        a.pci = Ml;
        a.si = Nl;
        a.gi = Ol;
        a.pic = qa(se)("_ym_fa");
        a.stlgg = ul("lgguid");
        a.sttdi = Gl;
        a.stti = Fl;
        a.sttifa = El;
        a.bl =
            ul("bl");
        M(Tg, a)
    })();
    (function() {
        var a = {};
        a.oo = ul("oo");
        a.pmc = ul("cmc");
        a.re = G(og, ib);
        a.aw = function(b) {
            b = Je(G(Ra, Ea), [b.document.hidden, b.document.msHidden, b.document.webkitHidden]);
            return Ra(b) ? null : jb(!b)
        };
        a.rcm = rm;
        a.yu = function(b) {
            return (b = ze(b, "").C("yandexuid")) && b.substring(0, 25)
        };
        a.ifc = ul("ifc");
        a.ifb = ul("ifb");
        a.ecs = ul("ecs");
        a.csi = ul("scip");
        a.cdl = ul("cdl");
        a.eco = x(nm, G(Da, N));
        a.dss = ul("dSync");
        a.pis = ul("pis");
        a.ucs = function(b) {
            return (b = ze(b).C("ucs")) && b.substring(0, 25)
        };
        M(wf, a)
    })();
    Mh.er = Ih;
    (function() {
        var a = window;
        try {
            var b = Nh(a, "er"),
                c = um(a, b);
            lf.push(function(d, e, f, g) {
                if (!(.01 >= a.Math.random())) {
                    var h = {},
                        k = {},
                        l = {},
                        m = {},
                        p = {};
                    c((p[d] = (m[Nc.eb] = (l[e] = (k[f] = g ? (h[a.location.href] = g, h) : a.location.href, k), l), m), p))
                }
            })
        } catch (d) {}
    })();
    hi.push(function(a, b) {
        if (I(a, "disableYaCounter" + b.id) || I(a, "Ya.disableMetrica")) {
            var c = N(b);
            delete O(a).C("counters", {})[c];
            md(hf("oo.e"))
        }
    });
    gh.unshift(function(a) {
        return {
            R: function(b, c) {
                O(a).C("oo") || c()
            }
        }
    });
    hh(function(a, b) {
        return {
            R: function(c, d) {
                var e = c.H,
                    f = c.K;
                !vm[b.id] && f.C("pv") && b.exp && !e.nohit && (e.exp = b.exp, vm[b.id] = !0);
                d()
            }
        }
    }, -99);
    ji.push(wm);
    jh.e = fh;
    Qh.e = ef;
    Mh.e = Gh;
    Ve({
        exp: {
            da: "experiments"
        }
    });
    uf.experiments = "ex";
    xm.push(zm);
    Qh.f = ef;
    var yw = {};
    M(Mh, (yw.f = Hh, yw));
    kh("f", Vg(), 1);
    kh("f", Wg, 2);
    kh("f", Tk, 20);
    hi.push(function(a, b) {
        var c = {
                wa: N(b),
                kd: fi(a, b),
                Tf: Ed(a),
                Sd: Ff(a)
            },
            d = c.Tf(Bd);
        if (!c.Sd.Jd) {
            var e = c.Sd.C("ymoo" + c.wa);
            e && 30 > d - e ? (c = c.wa, delete O(a).C("counters", {})[c], md(hf("uws"))) : Wh(b, Am(c))["catch"](V(a, "d.f"))
        }
    });
    var zw = ["x"],
        Aw = {};
    M(Mh, (Aw.s = zw, Aw.S = zw, Aw.u = Ih, Aw));
    var Bw = {};
    M(Qh, (Bw.s = Oe, Bw.S = ef, Bw.u = Oe, Bw));
    kh("s");
    kh("u");
    kh("S", Vg(["v", "hid", "u", "vf", "rn"]), 1);
    ji.push(W("s", function(a, b) {
        return Wh(b, function(c) {
            var d = O(a),
                e = d.C,
                f = E("dSync", d.D);
            N(b);
            if (e("dSync", !1)) f(1);
            else return f(!0), Qm(a, c, {
                fb: b,
                Ob: "s",
                Qd: "ds",
                wb: f,
                Rf: function(g, h, k) {
                    var l = g.Ga;
                    g = g.host;
                    if (I(l, "settings")) return md(hf("ds.e"));
                    h = h(Ad) - k;
                    k = g[1];
                    g = {};
                    l = Le((g.di = l, g.dit = h, g.dip = k, g));
                    h = {};
                    h = (h["page-url"] = U(a).href, h);
                    return Rh(a, "S", gm)({
                        K: l,
                        H: h
                    }, gm).then(E(10, f), V(a, "ds.rs"))
                }
            })
        })
    }));
    Qh["8"] = Oe;
    Ch.br = {
        check: nh,
        id: 0
    };
    Mh["8"] = ["br"];
    ji.push(W("p.us", function(a, b) {
        return Wh(b, function(c) {
            if (I(c, "settings.sbp")) return Qm(a, c, {
                fb: b,
                Ob: "8",
                Qd: "cs"
            })
        })
    }));
    ki.push(Io);
    Ve({
        zb: {
            da: "webvisor",
            Va: kb
        },
        Eg: {
            da: "disableFormAnalytics",
            Va: kb
        }
    });
    kh("4", Vg(Go), 1);
    Qh["4"] = ao;
    Mh["4"] = ["f", "x", "i"];
    ki.push(eq);
    kh("W", Vg(Go), 1);
    bf("wv", function(a, b) {
        return {
            R: function(c, d) {
                c.K.Tb("we", ib(b.zb));
                bo(a, b, c, "rn");
                d()
            }
        }
    }, 1);
    Mh.W = ["f", "x"];
    Qh.W = ao;
    ki.push(Gr);
    ji.push(Hr);
    Ve({
        zb: {
            da: "webvisor"
        }
    });
    Ve({
        Yh: {
            da: "trustedDomains"
        },
        dc: {
            da: "childIframe",
            Va: kb
        }
    });
    ji.push(Tr);
    kh("pi");
    Qh.pi = Oe;
    Mh.pi = Ih;
    bf("w", function(a, b) {
        return {
            R: function(c, d) {
                if (c.K) {
                    var e = Ir(b),
                        f = e.status;
                    "rt" === e.Ob && f && (c.K.D("rt", f), c.ma || (c.ma = {}), c.ma.$e = 1 === f ? Jr(a, b) + "." : "")
                }
                d()
            }
        }
    }, 2);
    ji.push(es);
    ji.push(As);
    Mh["6"] = ["f", "x"];
    Qh["6"] = Oe;
    ji.push(Cs);
    ji.push(hm);
    li.push(function(a, b) {
        b.informer = Es(a)
    });
    hh(Fs, 6);
    kh("1", Fs, 6);
    kh("adb");
    kh("n", Fs, 4);
    Mh.adb = Ih;
    Qh.adb = cf;
    ii.push(Is);
    Mh["5"] = Gh;
    Qh["5"] = ef;
    jh["5"] = nb(G(xb, sb([gf, bh]), Ea), fh);
    ji.push(Js);
    kh("5", Tk, 20);
    hh(Ls, 7);
    kh("n", Ls, 6);
    ki.push(Ms);
    Qh.d = ef;
    kh("d", Vg(["hid", "u", "v", "vf"]), 1);
    Mh.d = Ih;
    kh("n", function(a, b) {
            return {
                ta: function(c, d) {
                    if (!c.M || !c.M.force) {
                        var e = b.id === Nc.fg ? 1 : .002,
                            f = .002;
                        f = void 0 === f ? 1 : f;
                        e = void 0 === e ? 1 : e;
                        var g = vd(a);
                        if (g && A(g.getEntriesByType)) {
                            f = Math.random() > f;
                            var h = Math.random() > e;
                            if (!f || !h) {
                                var k = g.getEntriesByType("resource"),
                                    l = {},
                                    m = {};
                                g = {};
                                var p = qm();
                                e = U(a).href;
                                for (var r = 0; r < k.length; r += 1) {
                                    var t = k[r],
                                        w = q(t.name.replace(om, "").split("?")).next().value,
                                        z = Yj(w),
                                        P = {};
                                    P = (P.dns = Math.round(t.domainLookupEnd - t.domainLookupStart), P.tcp = Math.round(t.connectEnd - t.connectStart),
                                        P.duration = Math.round(t.duration), P.response = Math.round(t.responseEnd - t.requestStart), P);
                                    if ("script" === t.initiatorType && !f) {
                                        var R = {};
                                        m[w] = M(P, (R.name = t.name, R.decodedBodySize = t.decodedBodySize, R.transferSize = Math.round(t.transferSize), R))
                                    }!pm[z] && !p[z] || l[w] || h || (t = {}, l[w] = M(P, (t.pages = e, t)))
                                }
                                cc(l).length && (g.timings8 = l);
                                cc(m).length && (g.scripts = m);
                                cc(g).length && (f = {}, h = {}, Rh(a, "d", b)({
                                    K: Le((f.ar = 1, f.pv = 1, f)),
                                    N: {
                                        ba: yf(a, g) || void 0
                                    },
                                    H: (h["page-url"] = e, h)
                                }, {
                                    id: Nc.ig,
                                    ca: "0"
                                })["catch"](V(a, "r.tim.ng2")))
                            }
                        }
                    }
                    d()
                }
            }
        },
        7);
    Mh.ci = ["x"];
    Qh.ci = Oe;
    ki.push(W("p.sci", function(a, b) {
        return Wh(b, D([a, b], Ns))["catch"](V(a, "ins.cs"))
    }));
    ki.push(rl);
    hh(Ss, 8);
    kh("f", Ss, 3);
    kh("n", Ss, 5);
    kh("h", function(a) {
        return {
            ta: function(b, c) {
                var d = b.zf;
                $g(b) && d && O(a).D("isEU", I(d, "settings.eu"));
                c()
            }
        }
    }, 3);
    ii.push(Er);
    ki.push($s);
    ji.push(ct);
    Ve({
        ei: {
            da: "yaDisableGDPR"
        },
        hi: {
            da: "yaGDPRLang"
        }
    });
    gh.push(function(a, b) {
        return {
            R: D([a, b], Dt)
        }
    });
    pe.push("gdpr");
    pe.push("gdpr_popup");
    qe.push(function(a, b) {
        var c = Wi(a);
        c = qt(c);
        if (nb(sb(pt), c).length) return !0;
        c = b(a, "gdpr");
        return J(c, [it, kt])
    });
    gh.push(function(a) {
        return {
            R: function(b, c) {
                var d = b.ma || {},
                    e;
                (e = I(a, "document.referrer")) ? (e = qh(a, e).host, e = de(e), e = Gt + "." + (e || Ft)) : e = Lc;
                b.ma = M(d, {
                    af: [e]
                });
                c()
            }
        }
    });
    hh(St, 5);
    kh("1", St, 6);
    Mh.c = Ih;
    Qh.c = Oe;
    kh("1", Zt, 7);
    hh(Zt, 7);
    ki.push(W("p.ot", au));
    ki.push(Yd("cta", du, !0));
    kh("n", function(a) {
        var b = O(a);
        return {
            R: function(c, d) {
                var e = c.M || {},
                    f = b.C("cta"),
                    g = b.C("cta.e");
                if (f || g) {
                    e.O || (e.O = {});
                    e.O.__ym || (e.O.__ym = {});
                    var h = {};
                    f ? (f = L(function(k) {
                        var l = I(k, "topic");
                        k = I(k, "version");
                        var m = {};
                        return m.topic = l, m.version = k, m
                    }, f), h.ct = f) : g && (h["ct.e"] = g);
                    M(e.O.__ym, h);
                    c.M = M(c.M || {}, e)
                }
                d()
            }
        }
    }, 7);
    kh("n", Mi, 8);
    ji.push(xu);
    kh("g", function(a, b) {
        return {
            R: function(c, d) {
                var e = c.H;
                if (e && e["page-url"]) {
                    var f = e["page-url"];
                    Bu(f) || Cu(f) ? Wh(b, function(g) {
                        var h = I(g, "settings.goal_values");
                        if (h) {
                            var k = (g = qh(a, f).query) ? Vd(g) : void 0;
                            if (k) {
                                g = c.M || {};
                                g.O || (g.O = {});
                                g.O.__ym || (g.O.__ym = {});
                                var l = Bu(f) ? zu : Au;
                                h = Ju(h);
                                var m = Je(E(k, l), h);
                                if (m) {
                                    h = {};
                                    k = {};
                                    h = (k.cgd = (h.rg = m.id, h), k);
                                    a: {
                                        if (k = a.document.body) {
                                            l = m.price_patterns;
                                            m = Gu(m.id);
                                            if (m.Cb) {
                                                if (!Fj(a, m.Cb.element)) {
                                                    k = Hu(m.Cb);
                                                    break a
                                                }
                                                m.Cb = void 0
                                            }
                                            for (var p = null, r = null, t = 0; t < l.length; t +=
                                                1) {
                                                var w = q(l[t]),
                                                    z = w.next().value;
                                                w = w.next().value;
                                                "p" === z ? (p = a, p = (r = Fu(w)) ? I(p, "document.evaluate") ? p.document.evaluate(r, p.document, null, p.XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue : null : null, r = "x") : zj(a) && (p = Bj(w, k), r = "c");
                                                if (p && r) {
                                                    m.Cb = {
                                                        element: p,
                                                        rd: r
                                                    };
                                                    k = Hu(m.Cb);
                                                    break a
                                                }
                                            }
                                        }
                                        k = void 0
                                    }
                                    k && (h.cgd.gp = zl(Bl(k.Fh)), h.cgd.mg = k.rd);
                                    M(g.O.__ym, h);
                                    c.M = M(c.M || {}, g)
                                }
                            }
                        }
                        d()
                    })["catch"](G(sa(d), V(a, "a.g.v"))) : d()
                } else d()
            }
        }
    }, -2);
    mi.push(W("cdl", function(a) {
        var b = O(a).sa;
        if (a = I(a, "navigator.cookieDeprecationLabel")) try {
            a.getValue().then(E("cdl", b), D(["cdl", "e"], b))
        } catch (c) {
            b("cdl", "d")
        } else b("cdl", "na")
    }));
    Ve({
        Fg: {
            da: "disableYtm",
            Va: kb
        }
    });
    Mh.ytm = Jh;
    ji.push(W("p.ytm", function(a, b) {
        if (!b.Fg) {
            var c = !1,
                d = function() {
                    c = !0
                },
                e = [],
                f = function(h, k) {
                    e.push([h, k])
                };
            Wh(b, function(h) {
                if (!c && I(h, "settings.aytm")) {
                    Zu(a);
                    h = hw(a);
                    var k = Nh(a, "ytm"),
                        l = {};
                    return Oe(a, k)({
                        N: {
                            ea: ["ytm"],
                            cb: !0
                        },
                        H: h ? (l.nonce = h, l) : void 0
                    }, [Nc.La + "//" + Lc + "/ytm-config/" + b.id]).then(function(m) {
                        m = m.Ga;
                        if (!c && Sa(m)) {
                            var p = gw(a, "" + b.id),
                                r = aw(a, m, p).dispatchEvent;
                            f = p.kg;
                            L(function(t) {
                                var w = q(t);
                                t = w.next().value;
                                w = w.next().value;
                                return f(t, w)
                            }, e);
                            yb(e);
                            r(Mu(a, "ytm.init"));
                            d = Vu(a, r, m)
                        }
                    })
                }
            })["catch"](V(a,
                "ytm.s"));
            var g = {};
            return g.u = function() {
                return d()
            }, g.policy = function(h, k) {
                return f(h, k)
            }, g
        }
    }));
    ki.push(iw);
    Mh.pis = Kh;
    Qh.pis = Oe;
    ki.push(W("p.sci", function(a, b) {
        return Wh(b, function(c) {
            var d = I(c, "settings.pis");
            if (d && !Bm(c)) {
                c = O(a);
                var e = c.C;
                c = c.D;
                e = e("pis");
                if (Ra(e)) return e = Rh(a, "pis"), c("pis", "0"), e({
                    N: {
                        ea: ["pis"]
                    }
                }, [d]).then(D(["pis", "1"], c), sa(D(["pis", "a"], c)))
            }
        })["catch"](V(a, "pis"))
    }));
    Mh.pic = Jh;
    Qh.pic = Oe;
    ki.push(jw);
    mi.push(kw);
    ji.push(lw);
    ji.push(function(a, b) {
        var c = nw(a),
            d = N(b),
            e = c[d];
        e || (e = {}, c[d] = e);
        e.ih = !0;
        if (c = e.Mf) d = qw(a), L(d, c)
    });
    ki.unshift(function(a, b) {
        Wh(b, function(c) {
            var d = Be(a),
                e = I(c, "settings.sm"),
                f = Mk(a);
            (d || e || f.id) && Lt(a, "tag_debug", b, c)
        })
    });

    function Cw(a, b, c, d) {
        var e = this;
        return V(window, "c.i", function() {
            function f(z) {
                (z = kk(k, m, "", z)(k, m)) && (A(z.then) ? z.then(g) : g(z));
                return z
            }

            function g(z) {
                z && (A(z) ? p.push(z) : Sa(z) && L(function(P) {
                    var R = q(P);
                    P = R.next().value;
                    R = R.next().value;
                    A(R) && ("u" === P ? p.push(R) : h(R, P))
                }, bc(z)))
            }

            function h(z, P, R) {
                e[P] = uw(k, m, R || r, P, z)
            }
            var k = window;
            (!k || isNaN(a) && !a) && jf();
            var l = Pc(a, b, c, d),
                m = Qc(l);
            Kt(m).Hh = l;
            Ji(m, m.O || {});
            var p = [],
                r = [tw, kk, sw];
            r.unshift(gi);
            var t = L(v, ki);
            l = N(m);
            m.id || md(S("Invalid Metrika id: " + m.id, !0));
            var w = vw.C("counters", {});
            if (w[l]) return t = {}, Zh(k, l, "dc", (t.key = l, t)), w[l];
            w[l] = e;
            vw.D("counters", w);
            vw.sa("counter", e);
            L(function(z) {
                z(k, m)
            }, hi);
            L(f, ii);
            f(bi);
            h(rw(k, m, p), "destruct", [tw, sw]);
            ai(k, D([k, t, f, 1, "a.i"], kq));
            L(f, ji);
            l = {};
            Fe(k, (l.counterKey = N(m), l.name = "counter", l.data = We(m), l))
        })()
    }
    L(qa(Qe)(window), mi);
    if (window.Ya && Cw) {
        var Dw = Nc.fc;
        window.Ya[Dw] = Cw;
        ei(window);
        L(G(ab([window, window.Ya[Dw]]), Qe), li)
    }
    (function(a) {
        var b = I(a, "ym");
        if (b) {
            var c = I(b, "a");
            c || (b.a = [], c = b.a);
            var d = qw(a);
            Xi(a, c, function(e) {
                e.qa.F(d)
            }, !0)
        }
    })(window);
}).call(this);